### Epic: Leave Policy Compliance
#### Story Title: Enforce leave balance and policy rules
- **Story Description**: As a system, I want to validate leave requests against leave balances and organizational policies so that only valid requests are processed.
- **Acceptance Criteria**:
  - Requests exceeding leave balance are rejected with an appropriate error message.
  - Requests violating policies (e.g., minimum notice period, blackout dates) are rejected with specific reasons.
  - Validation occurs during request submission.
- **Priority**: High
- **Story Points**: 5
- **Dependencies**: Leave policy configurations from HR.
- **FE Notes**: Display validation errors on the submission form.
- **BE Notes**: Implement policy validation logic in the leave management service.
- **QA Notes**: Test scenarios for leave balance checks and policy violations.

---