### Epic: Notification System
#### Story Title: Notifications for leave request events
- **Story Description**: As a stakeholder, I want to receive email notifications for leave request submissions, approvals, and rejections so that I stay informed.
- **Acceptance Criteria**:
  - Notifications are sent to employees and managers for submission, approval, and rejection events.
  - Notifications include relevant details (e.g., leave type, dates, status).
  - Notifications are sent via the organization's email system.
- **Priority**: Medium
- **Story Points**: 5
- **Dependencies**: Email service integration.
- **FE Notes**: None.
- **BE Notes**: Implement notification service to handle email triggers for leave events.
- **QA Notes**: Test email content, delivery, and scenarios for all leave events.

---