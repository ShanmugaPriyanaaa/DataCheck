### Epic: Leave Request Submission
#### Story Title: Employee submits a leave request
- **Story Description**: As an employee, I want to submit a leave request with start and end dates, leave type, and a reason so that my manager can review and approve/reject it.
- **Acceptance Criteria**:
  - Employees can select leave type, start date, end date, and provide a reason.
  - The system validates leave balance and policy compliance.
  - The request is saved in the system and marked as "Pending."
  - A notification is sent to the manager.
- **Priority**: High
- **Story Points**: 5
- **Dependencies**: HR system for employee data and leave balances.
- **FE Notes**: Build a form for leave request submission with validation for required fields and date ranges.
- **BE Notes**: Implement API to handle leave request creation and validation against policies.
- **QA Notes**: Test form validations, API responses, and integration with the notification system.

---