# Story Instruction: Enforce leave balance and policy rules

## Epic
Leave Policy Compliance

## Story Description
TBD

## Acceptance Criteria
- TBD

## Priority
TBD

## Story Points
TBD

## Dependencies
- TBD

## Story Coordination
- **Coordinator Agent:** Jira Story Generator Agent

## Primary Delivery Agents
- Security & Compliance Agent

## Supporting Review Agents
- Backend Developer Agent
- QA / Test Engineer Agent

## Delivery Sequence
- 1. Security & Compliance Agent performs focused security and compliance review for the story.
- 2. Supporting review agents validate alignment, risks, architecture impact, data/event impact, and documentation completeness.

## Agent Instructions

### Security & Compliance Agent
- Review this story for authorization, secure handling, and compliance considerations.

### Backend Developer Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### QA / Test Engineer Agent
- Provide supporting analysis, review, or guidance relevant to this story.
