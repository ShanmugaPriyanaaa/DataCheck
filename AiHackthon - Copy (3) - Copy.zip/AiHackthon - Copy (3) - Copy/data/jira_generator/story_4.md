### Epic: Audit Trail Implementation
#### Story Title: Log leave-related actions in the audit trail
- **Story Description**: As an HR representative, I want all leave-related actions to be logged so that I can ensure compliance and track changes.
- **Acceptance Criteria**:
  - Actions such as submission, approval, rejection, and updates are logged with timestamps, user details, and action details.
  - Logs are immutable and stored securely.
  - Logs can be retrieved for up to 5 years.
- **Priority**: High
- **Story Points**: 8
- **Dependencies**: Leave request and notification workflows.
- **FE Notes**: None.
- **BE Notes**: Implement audit service to log actions and ensure immutability.
- **QA Notes**: Test log creation, data accuracy, and retrieval for compliance scenarios.

---