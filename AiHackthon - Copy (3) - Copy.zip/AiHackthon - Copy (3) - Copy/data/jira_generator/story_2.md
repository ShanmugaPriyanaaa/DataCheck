### Epic: Manager Approval Workflow
#### Story Title: Manager approves or rejects a leave request
- **Story Description**: As a manager, I want to review leave requests and approve or reject them so that I can manage team availability.
- **Acceptance Criteria**:
  - Managers can view pending leave requests.
  - Managers can approve or reject requests with optional comments.
  - The system updates the request status and notifies the employee.
  - The action is logged in the audit trail.
- **Priority**: High
- **Story Points**: 8
- **Dependencies**: Leave request data from the submission workflow.
- **FE Notes**: Build a dashboard for managers to view and act on leave requests.
- **BE Notes**: Implement API for updating leave request status and triggering notifications.
- **QA Notes**: Test approval/rejection flows, status updates, and notification triggers.

---