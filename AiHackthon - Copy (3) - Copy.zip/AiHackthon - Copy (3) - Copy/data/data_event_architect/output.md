# Data and Event Architecture Recommendation

## Summary
The Leave Request Management System will manage employee leave requests, approvals, and HR oversight while ensuring compliance, notifications, and auditability. The architecture will include relational and NoSQL databases, event-driven notifications, and an immutable audit trail.

---

## Core Data Entities
1. **Employee**: Represents employees in the organization.
2. **LeaveRequest**: Represents leave applications submitted by employees.
3. **LeaveBalance**: Tracks the available leave balance for employees.
4. **Manager**: Represents managers responsible for approving/rejecting leave requests.
5. **AuditLog**: Logs all actions for compliance and tracking.
6. **Notification**: Tracks notifications sent for leave-related events.

---

## Relationships
1. **Employee to LeaveRequest**: One-to-Many (an employee can submit multiple leave requests).
2. **Manager to LeaveRequest**: One-to-Many (a manager can approve/reject multiple leave requests).
3. **Employee to LeaveBalance**: One-to-One (each employee has a single leave balance record).
4. **LeaveRequest to AuditLog**: One-to-Many (each leave request can have multiple audit log entries).
5. **LeaveRequest to Notification**: One-to-Many (each leave request can trigger multiple notifications).

---

## Suggested Logical Data Structure Notes
- **LeaveRequest**: Tracks the status of leave requests (e.g., pending, approved, rejected).
- **AuditLog**: Immutable table to store all actions with timestamps and user details.
- **LeaveBalance**: Tracks leave types (e.g., vacation, sick leave) and remaining balances.
- **Notification**: Tracks notification events (e.g., submission, approval, rejection).
- **Employee and Manager**: Reference data sourced from the HR system.

---

## ER Diagram
```mermaid
erDiagram
    EMPLOYEE {
        INTEGER EmployeeID PK
        VARCHAR FullName
        VARCHAR Email
        INTEGER ManagerID FK
    }
    MANAGER {
        INTEGER ManagerID PK
        VARCHAR FullName
        VARCHAR Email
    }
    LEAVEBALANCE {
        INTEGER LeaveBalanceID PK
        INTEGER EmployeeID FK
        INTEGER VacationBalance
        INTEGER SickLeaveBalance
        TIMESTAMP LastUpdated
    }
    LEAVEREQUEST {
        INTEGER LeaveRequestID PK
        INTEGER EmployeeID FK
        INTEGER ManagerID FK
        DATE StartDate
        DATE EndDate
        VARCHAR LeaveType
        TEXT Reason
        VARCHAR Status
        TIMESTAMP CreatedAt
        TIMESTAMP UpdatedAt
    }
    AUDITLOG {
        INTEGER AuditLogID PK
        INTEGER LeaveRequestID FK
        VARCHAR Action
        VARCHAR PerformedBy
        TIMESTAMP ActionTimestamp
    }
    NOTIFICATION {
        INTEGER NotificationID PK
        INTEGER LeaveRequestID FK
        VARCHAR EventType
        VARCHAR RecipientEmail
        TIMESTAMP SentAt
    }
    EMPLOYEE ||--o{ LEAVEREQUEST : "submits"
    MANAGER ||--o{ LEAVEREQUEST : "reviews"
    EMPLOYEE ||--o| LEAVEBALANCE : "has"
    LEAVEREQUEST ||--o{ AUDITLOG : "logs"
    LEAVEREQUEST ||--o{ NOTIFICATION : "triggers"
```

---

## Physical Database Model
```sql
CREATE TABLE Employee (
    EmployeeID SERIAL PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE,
    ManagerID INT REFERENCES Manager(ManagerID)
);

CREATE TABLE Manager (
    ManagerID SERIAL PRIMARY KEY,
    FullName VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE LeaveBalance (
    LeaveBalanceID SERIAL PRIMARY KEY,
    EmployeeID INT NOT NULL UNIQUE REFERENCES Employee(EmployeeID),
    VacationBalance INT NOT NULL DEFAULT 0,
    SickLeaveBalance INT NOT NULL DEFAULT 0,
    LastUpdated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE LeaveRequest (
    LeaveRequestID SERIAL PRIMARY KEY,
    EmployeeID INT NOT NULL REFERENCES Employee(EmployeeID),
    ManagerID INT NOT NULL REFERENCES Manager(ManagerID),
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    LeaveType VARCHAR(50) NOT NULL,
    Reason TEXT,
    Status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    CreatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE AuditLog (
    AuditLogID SERIAL PRIMARY KEY,
    LeaveRequestID INT NOT NULL REFERENCES LeaveRequest(LeaveRequestID),
    Action VARCHAR(50) NOT NULL,
    PerformedBy VARCHAR(255) NOT NULL,
    ActionTimestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Notification (
    NotificationID SERIAL PRIMARY KEY,
    LeaveRequestID INT NOT NULL REFERENCES LeaveRequest(LeaveRequestID),
    EventType VARCHAR(50) NOT NULL,
    RecipientEmail VARCHAR(255) NOT NULL,
    SentAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## Normalization Details
- **1NF**: All tables have atomic values and unique rows.
- **2NF**: Non-key attributes are fully dependent on the primary key (e.g., LeaveBalance depends only on EmployeeID).
- **3NF**: No transitive dependencies (e.g., ManagerID is stored in Employee, not LeaveRequest).

No intentional denormalization is applied.

---

## Data Dictionary
| Table Name      | Column Name         | Data Type       | Key Type | Nullable | Default Value          | Column Description                                   |
|------------------|---------------------|-----------------|----------|----------|------------------------|-----------------------------------------------------|
| Employee         | EmployeeID         | SERIAL          | PK       | No       |                        | Unique identifier for employees                    |
| Employee         | FullName           | VARCHAR(255)    | None     | No       |                        | Full name of the employee                          |
| Employee         | Email              | VARCHAR(255)    | None     | No       |                        | Email address of the employee                      |
| Employee         | ManagerID          | INT             | FK       | Yes      |                        | References the manager of the employee             |
| Manager          | ManagerID          | SERIAL          | PK       | No       |                        | Unique identifier for managers                     |
| Manager          | FullName           | VARCHAR(255)    | None     | No       |                        | Full name of the manager                           |
| Manager          | Email              | VARCHAR(255)    | None     | No       |                        | Email address of the manager                       |
| LeaveBalance     | LeaveBalanceID     | SERIAL          | PK       | No       |                        | Unique identifier for leave balance records        |
| LeaveBalance     | EmployeeID         | INT             | FK       | No       |                        | References the employee                            |
| LeaveBalance     | VacationBalance    | INT             | None     | No       | 0                      | Remaining vacation leave balance                   |
| LeaveBalance     | SickLeaveBalance   | INT             | None     | No       | 0                      | Remaining sick leave balance                       |
| LeaveBalance     | LastUpdated        | TIMESTAMP       | None     | No       | CURRENT_TIMESTAMP      | Timestamp of the last update                       |
| LeaveRequest     | LeaveRequestID     | SERIAL          | PK       | No       |                        | Unique identifier for leave requests               |
| LeaveRequest     | EmployeeID         | INT             | FK       | No       |                        | References the employee who submitted the request  |
| LeaveRequest     | ManagerID          | INT             | FK       | No       |                        | References the manager responsible for approval    |
| LeaveRequest     | StartDate          | DATE            | None     | No       |                        | Start date of the leave                            |
| LeaveRequest     | EndDate            | DATE            | None     | No       |                        | End date of the leave                              |
| LeaveRequest     | LeaveType          | VARCHAR(50)     | None     | No       |                        | Type of leave (e.g., vacation, sick)               |
| LeaveRequest     | Reason             | TEXT            | None     | Yes      |                        | Reason for the leave request                       |
| LeaveRequest     | Status             | VARCHAR(20)     | None     | No       | 'Pending'             | Status of the leave request                        |
| LeaveRequest     | CreatedAt          | TIMESTAMP       | None     | No       | CURRENT_TIMESTAMP      | Timestamp of when the request was created          |
| LeaveRequest     | UpdatedAt          | TIMESTAMP       | None     | No       | CURRENT_TIMESTAMP      | Timestamp of the last update                       |
| AuditLog         | AuditLogID         | SERIAL          | PK       | No       |                        | Unique identifier for audit log entries            |
| AuditLog         | LeaveRequestID     | INT             | FK       | No       |                        | References the leave request                       |
| AuditLog         | Action             | VARCHAR(50)     | None     | No       |                        | Action performed (e.g., submission, approval)      |
| AuditLog         | PerformedBy        | VARCHAR(255)    | None     | No       |                        | User who performed the action                      |
| AuditLog         | ActionTimestamp    | TIMESTAMP       | None     | No       | CURRENT_TIMESTAMP      | Timestamp of the action                            |
| Notification     | NotificationID     | SERIAL          | PK       | No       |                        | Unique identifier for notifications                |
| Notification     | LeaveRequestID     | INT             | FK       | No       |                        | References the leave request                       |
| Notification     | EventType          | VARCHAR(50)     | None     | No       |                        | Type of event (e.g., submission, approval)         |
| Notification     | RecipientEmail     | VARCHAR(255)    | None     | No       |                        | Email address of the notification recipient        |
| Notification     | SentAt             | TIMESTAMP       | None     | No       | CURRENT_TIMESTAMP      | Timestamp of when the notification was sent        |

---

## Sample Data Inserts
```sql
INSERT INTO Manager (FullName, Email) VALUES ('Michael Manager', 'michael.manager@example.com');
INSERT INTO Employee (FullName, Email, ManagerID) VALUES ('Emily Employee', 'emily.employee@example.com', 1);
INSERT INTO LeaveBalance (EmployeeID, VacationBalance, SickLeaveBalance) VALUES (1, 15, 10);
INSERT INTO LeaveRequest (EmployeeID, ManagerID, StartDate, EndDate, LeaveType, Reason, Status) 
VALUES (1, 1, '2023-11-01', '2023-11-05', 'Vacation', 'Family trip', 'Pending');
INSERT INTO AuditLog (LeaveRequestID, Action, PerformedBy) VALUES (1, 'Submission', 'Emily Employee');
INSERT INTO Notification (LeaveRequestID, EventType, RecipientEmail) VALUES (1, 'Submission', 'michael.manager@example.com');
```

---

## Data Lifecycle Notes
- **Creation**: Leave requests are created by employees, and leave balances are initialized by HR.
- **Update**: Managers update request statuses; HR updates leave balances.
- **Retrieval**: Employees, managers, and HR retrieve leave data for tracking and decision-making.
- **Archiving**: Old leave requests and audit logs are archived after 5 years.
- **Retention**: Audit logs are retained for compliance purposes.

---

## Event Model
1. **LeaveRequestSubmitted**: Triggered when an employee submits a leave request.
2. **LeaveRequestApproved**: Triggered when a manager approves a leave request.
3. **LeaveRequestRejected**: Triggered when a manager rejects a leave request.
4. **LeaveBalanceUpdated**: Triggered when HR updates leave balances.

---

## Suggested Topics / Queues
1. `leave.request.submitted`
2. `leave.request.approved`
3. `leave.request.rejected`
4. `leave.balance.updated`

---

## Producers and Consumers
- **Producers**:
  - Leave Management Service
  - HR Console
- **Consumers**:
  - Notification Service
  - Audit Service

---

## Reliability Considerations
- **Retry**: Implement retries for failed notifications.
- **Idempotency**: Ensure leave request updates are idempotent.
- **Ordering**: Maintain event ordering for audit logs.
- **Consistency**: Use distributed transactions for leave balance updates.
- **DLQ**: Configure Dead Letter Queues for failed events.
- **Replay**: Support event replay for audit recovery.

---

## Assumptions
- Leave policies are pre-configured.
- Notifications are email-only.
- Audit logs are immutable.

---

## Constraints
- Notifications must use the organization's email system.
- Leave requests cannot span fiscal years without HR approval.

---

## Dependencies
- HR system for employee/manager data.
- Email service for notifications.

---

## Risks
- Compliance risks if policies are not enforced.
- Operational risks from overlapping leave approvals.

---

## Open Questions
1. Should employees be able to cancel or modify leave requests?
2. What is the retention period for audit logs?