import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")

sys.path.insert(0, APP_DIR)

from orchestrator import run_pipeline

feature_text = """
Build a leave request feature where employees can apply for leave, managers can approve or reject requests, HR can track leave balances, notifications should be sent, and an audit trail should be maintained.
"""

result = run_pipeline(
    feature_text=feature_text,
    frontend_codebase_path=r"C:\AiHackthon\frontEndApp",
    backend_codebase_path=r"C:\AiHackthon\backEndApp",
    write_changes=False,
    run_qa_checks=False
)

print("=== PIPELINE COMPLETED ===")
print(result.keys())