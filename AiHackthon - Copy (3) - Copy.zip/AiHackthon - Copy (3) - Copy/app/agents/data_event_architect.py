import os
import sys
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
)

AGENT_NAME = "data_event_architect"
PROMPT_FILE = "data_event_architect.txt"

# Setup search paths for modules
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm


def load_prompt():
    prompt_path = os.path.join(APP_DIR, "prompts", PROMPT_FILE)
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Data and Event Architecture Recommendation",
        "## Summary",
        "## Core Data Entities",
        "## Relationships",
        "## Suggested Logical Data Structure Notes",
        "## ER Diagram",
        "## Physical Database Model",
        "## Normalization Details",
        "## Data Dictionary",
        "## Sample Data Inserts",
        "## Data Lifecycle Notes",
        "## Event Model",
        "## Suggested Topics / Queues",
        "## Producers and Consumers",
        "## Reliability Considerations",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        req_output = read_agent_file("requirement_analyzer", "output", "md")
        parts.append(f"## Requirement Analysis\n{req_output}")
    else:
        try:
            req_output = read_agent_subfile("requirement_analyzer", "output.md")
            parts.append(f"## Requirement Analysis\n{req_output}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        arch_output = read_agent_file("technical_architect", "output", "md")
        parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
    else:
        try:
            arch_output = read_agent_subfile("technical_architect", "output.md")
            parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer or technical_architect."
        )

    return "\n\n".join(parts)


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Data & Event Architecture Agent.\n\n"
        "Generate the required data and event architecture output.\n\n"
        "Important:\n"
        "- Generate the physical SQL DDL schema, normalization details, data dictionary, sample data, and ER Diagram.\n"
        "- Use the exact required output headings.\n"
        "- Keep the output detailed, structured, and suitable for downstream agents.\n"
        "- Include logical entities, relationships, suggested topics/queues, producers/consumers, and reliability considerations.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly (especially physical database model, ER diagram, normalization details, data dictionary, sample inserts)\n"
        "- Keep the output focused on data and event architecture\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return ask_llm(system_prompt, user_input)


def run_data_event_architect(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        input_text = build_default_input()

    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        # Fallback response containing required headers
        output = (
            "# Data and Event Architecture Recommendation\n\n"
            "## Summary\n"
            "Output validation failed, manual review required.\n\n"
            "## Core Data Entities\n"
            "## Relationships\n"
            "## Suggested Logical Data Structure Notes\n"
            "## ER Diagram\n"
            "```mermaid\n"
            "erDiagram\n"
            "    ERROR ||--|| REVIEW : needs\n"
            "```\n\n"
            "## Physical Database Model\n"
            "```sql\n"
            "-- Manual review required\n"
            "```\n\n"
            "## Normalization Details\n"
            "## Data Dictionary\n"
            "## Sample Data Inserts\n"
            "## Data Lifecycle Notes\n"
            "## Event Model\n"
            "## Suggested Topics / Queues\n"
            "## Producers and Consumers\n"
            "## Reliability Considerations\n"
            "## Assumptions\n"
            "## Constraints\n"
            "## Dependencies\n"
            "## Risks\n"
            "## Open Questions\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }