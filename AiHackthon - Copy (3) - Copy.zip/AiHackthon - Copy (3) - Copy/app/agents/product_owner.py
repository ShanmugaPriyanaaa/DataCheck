import os
import sys
from file_utils import write_agent_file, read_agent_file, agent_file_exists, save_agent_artifacts

AGENT_NAME = "product_owner"

# Setup search paths for modules
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm


def load_prompt():
    prompt_path = os.path.join(APP_DIR, "prompts", "product_owner.txt")
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return ask_llm(system_prompt, user_input)


def run_product_owner(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        if agent_file_exists("requirement_analyzer", "output", "md"):
            requirement_output = read_agent_file("requirement_analyzer", "output", "md")
            input_text = f"## Requirement Analysis\n{requirement_output}"
        else:
            raise ValueError("No input provided and requirement_analyzer_output.md not found")

    write_agent_file(AGENT_NAME, "input", input_text, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=input_text)

    output = generate_llm_output(system_prompt, input_text)

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "status": "success",
        "output": output
    }