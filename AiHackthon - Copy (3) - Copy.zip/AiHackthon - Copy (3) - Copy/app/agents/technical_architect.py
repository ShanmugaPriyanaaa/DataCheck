import os
import sys
from datetime import datetime
from file_utils import write_agent_file, save_agent_artifacts

AGENT_NAME = "technical_architect"
PROMPT_FILE = "technical_architect.txt"

# Setup search paths for modules
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm


def load_prompt():
    prompt_path = os.path.join(APP_DIR, "prompts", PROMPT_FILE)
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Technical Architecture Recommendation",
        "## Summary",
        "## Architecture Style",
        "## Core Components",
        "## System Flow",
        "## Mermaid Diagram",
        "## Integration Considerations",
        "## Security and Scalability Notes",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]

    has_sections = all(section in output for section in required_sections)
    has_mermaid = "```mermaid" in output

    return has_sections and has_mermaid


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Technical Architect Agent.\n\n"
        "Generate only the required technical architecture output.\n\n"
        "Important:\n"
        "- Do not generate product planning, sprint planning, MVP planning, roadmap content, release planning, or implementation planning.\n"
        "- Use the exact required output headings.\n"
        "- The Mermaid Diagram section is mandatory.\n"
        "- The Mermaid diagram must be generated dynamically based on the provided feature context.\n"
        "- Do not use hardcoded domain examples unless they are derived from the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Include the '## Mermaid Diagram' section\n"
        "- Include valid Mermaid syntax using ```mermaid\n"
        "- Keep the output architecture-focused\n"
        "- Do not include sprint plans, MVP plans, product planning, development plans, release plans, or next steps\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return ask_llm(system_prompt, user_input)


def run_technical_architect(input_text: str):
    system_prompt = load_prompt()
    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        output = (
            "# Technical Architecture Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Technical Architect format and needs manual review.\n\n"
            "## Architecture Style\n"
            "- Manual review required\n\n"
            "## Core Components\n"
            "- Manual review required\n\n"
            "## System Flow\n"
            "- Manual review required\n\n"
            "## Mermaid Diagram\n"
            "```mermaid\n"
            "flowchart TD\n"
            "    A[Feature Input] --> B[Technical Architect Agent]\n"
            "    B --> C[Architecture Review Required]\n"
            "```\n\n"
            "## Integration Considerations\n"
            "- Manual review required\n\n"
            "## Security and Scalability Notes\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- The model response did not fully comply with the required structure.\n\n"
            "## Constraints\n"
            "- Output validation failed after retry.\n\n"
            "## Dependencies\n"
            "- Prompt adherence\n"
            "- LLM response quality\n\n"
            "## Risks\n"
            "- Downstream outputs may be impacted if this architecture output is used without correction.\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }