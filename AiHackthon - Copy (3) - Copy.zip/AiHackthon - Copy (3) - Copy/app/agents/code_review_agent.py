import os
import sys
from base_agent import run_generic_agent

def run_code_review_agent(input_payload: str):
    # Try to find and read the generated app code
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(os.path.dirname(current_dir))
    app_file_path = os.path.join(project_dir, "data", "generated_app", "app.py")
    
    code_content = ""
    if os.path.exists(app_file_path):
        try:
            with open(app_file_path, "r", encoding="utf-8") as f:
                code_content = f.read()
        except Exception:
            pass
            
    if code_content:
        input_payload += f"\n\n## Generated Application Code for Review\n```python\n{code_content}\n```"
        
    return run_generic_agent("code_review_agent", "code_review_agent.txt", input_payload)