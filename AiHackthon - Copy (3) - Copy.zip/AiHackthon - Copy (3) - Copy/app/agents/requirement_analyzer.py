import os
import sys

AGENT_NAME = "requirement_analyzer"

# Setup search paths for modules
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm
from file_utils import write_agent_file, save_agent_artifacts


def load_prompt():
    prompt_path = os.path.join(APP_DIR, "prompts", "requirement_analyzer.txt")
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return ask_llm(system_prompt, user_input)


def run_requirement_analyzer(feature_text: str):
    system_prompt = load_prompt()

    write_agent_file(AGENT_NAME, "input", feature_text, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=feature_text)

    output = generate_llm_output(system_prompt, feature_text)

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "status": "success",
        "output": output
    }