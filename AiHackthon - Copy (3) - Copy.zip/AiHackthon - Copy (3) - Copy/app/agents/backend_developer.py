import os
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    write_agent_subfile,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
    ensure_agent_dir,
)

AGENT_NAME = "backend_developer"
PROMPT_FILE = "backend_developer.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def load_story_instruction(story_instruction_path: str) -> str:
    if not story_instruction_path:
        return None

    if not os.path.exists(story_instruction_path):
        raise FileNotFoundError(f"Story instruction file not found: {story_instruction_path}")

    with open(story_instruction_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Backend Delivery Recommendation",
        "## Summary",
        "## Detected Backend Context",
        "## Core Backend Responsibilities",
        "## Validation and Business Rules Notes",
        "## Persistence and Data Handling Notes",
        "## Integration and Event Handling Notes",
        "## Error Handling Notes",
        "## Security and Access Notes",
        "## Codebase Impact Analysis",
        "## Backend Implementation Notes",
        "## Unit Test Notes",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        parts.append(f"## Requirement Analysis\n{read_agent_file('requirement_analyzer', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Requirement Analysis\n{read_agent_subfile('requirement_analyzer', 'output.md')}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        parts.append(f"## Technical Architecture Recommendation\n{read_agent_file('technical_architect', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Technical Architecture Recommendation\n{read_agent_subfile('technical_architect', 'output.md')}")
        except Exception:
            pass

    if agent_file_exists("data_event_architect", "output", "md"):
        parts.append(f"## Data and Event Architecture Recommendation\n{read_agent_file('data_event_architect', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Data and Event Architecture Recommendation\n{read_agent_subfile('data_event_architect', 'output.md')}")
        except Exception:
            pass

    if agent_file_exists("jira_generator", "output", "md"):
        parts.append(f"## Jira Delivery Breakdown\n{read_agent_file('jira_generator', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Jira Delivery Breakdown\n{read_agent_subfile('jira_generator', 'output.md')}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer, technical_architect, data_event_architect, or jira_generator."
        )

    return "\n\n".join(parts)


def scan_codebase(codebase_path: str):
    if not codebase_path or not os.path.exists(codebase_path):
        return {
            "exists": False,
            "framework": "Unknown",
            "files": [],
            "notes": ["No valid backend codebase path was provided."]
        }

    collected_files = []
    framework_hints = {
        "Spring Boot": 0,
        "Node.js/Express": 0,
        "Python/FastAPI": 0,
        "Python/Flask": 0,
        ".NET": 0,
        "Unknown": 0,
    }

    for root, dirs, files in os.walk(codebase_path):
        dirs[:] = [d for d in dirs if d not in ["node_modules", ".git", "dist", "build", "__pycache__", "target", "bin", "obj", ".venv", "venv"]]

        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), codebase_path)
            collected_files.append(rel_path)

            lower_path = rel_path.lower().replace("\\", "/")

            if "pom.xml" in lower_path or "application.properties" in lower_path or "application.yml" in lower_path:
                framework_hints["Spring Boot"] += 2

            if lower_path.endswith(".java"):
                framework_hints["Spring Boot"] += 1

            if "package.json" in lower_path or lower_path.endswith(".js") or lower_path.endswith(".ts"):
                framework_hints["Node.js/Express"] += 1

            if "fastapi" in lower_path or lower_path.endswith("main.py"):
                framework_hints["Python/FastAPI"] += 1

            if lower_path.endswith(".py"):
                framework_hints["Python/FastAPI"] += 1
                framework_hints["Python/Flask"] += 1

            if "flask" in lower_path:
                framework_hints["Python/Flask"] += 2

            if lower_path.endswith(".csproj") or lower_path.endswith(".sln") or lower_path.endswith(".cs"):
                framework_hints[".NET"] += 2

    framework = max(framework_hints, key=framework_hints.get)
    if framework_hints[framework] == 0:
        framework = "Unknown"

    return {
        "exists": True,
        "framework": framework,
        "files": collected_files[:200],
        "notes": [f"Detected framework hint: {framework}"]
    }


def build_codebase_context(codebase_scan: dict) -> str:
    if not codebase_scan["exists"]:
        return "No valid backend codebase path was provided."

    file_preview = "\n".join([f"- {f}" for f in codebase_scan["files"][:40]])
    notes_preview = "\n".join([f"- {n}" for n in codebase_scan["notes"]])

    return (
        f"Backend codebase path is available.\n"
        f"Detected framework hint: {codebase_scan['framework']}\n"
        f"Notes:\n{notes_preview}\n"
        f"Sample files:\n{file_preview}"
    )


def build_input(input_text: str, codebase_scan: dict) -> str:
    return (
        "You are acting only as the Backend Developer Agent.\n\n"
        "Generate only the required backend delivery recommendation output.\n\n"
        "Important:\n"
        "- Do not generate infrastructure deployment setup by default.\n"
        "- Use the exact required output headings.\n"
        "- Keep the output backend-focused, implementation-aware, and suitable for downstream agents.\n"
        "- If codebase context is available, include high-level codebase impact notes.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Business Context:\n{input_text}\n\n"
        f"Codebase Context:\n{build_codebase_context(codebase_scan)}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on backend delivery guidance\n"
        "- Include codebase impact analysis and unit test notes\n"
        "- Do not include infrastructure deployment setup by default\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str, codebase_scan: dict) -> str:
    if codebase_scan["exists"]:
        detected_context = (
            f"- Valid codebase path provided\n"
            f"- Likely backend framework: {codebase_scan['framework']}\n"
            f"- Existing file structure was scanned at a high level\n"
            f"- Backend implementation recommendations should align to the detected codebase layout"
        )
        codebase_impact = (
            "- Existing service, handler, controller, processor, or route modules may need updates\n"
            "- Existing repository, persistence, model, or data-access modules may need reuse or extension\n"
            "- Existing validation, authorization, eventing, or integration utilities may be impacted\n"
            "- Existing test modules or test folders should be extended for new backend behavior\n"
            "- Shared configuration, workflow orchestration, or common library layers may need review"
        )
    else:
        detected_context = "- No valid backend codebase path was provided\n- Backend recommendations are based only on upstream SDLC outputs"
        codebase_impact = "- Codebase impact analysis is limited because no backend codebase path was provided"

    return (
        "# Backend Delivery Recommendation\n\n"
        "## Summary\n"
        "A structured backend approach is recommended with clear separation of business processing, validation handling, persistence coordination, integration behavior, and failure management. The backend should preserve consistency, support role-aware business actions, align to the existing codebase where available, and maintain reliable unit test coverage.\n\n"
        "## Detected Backend Context\n"
        f"{detected_context}\n\n"
        "## Core Backend Responsibilities\n"
        "- Process the core business workflow and enforce allowed state transitions\n"
        "- Handle role-based actions and service-side decision logic\n"
        "- Persist and retrieve the primary business records and related state changes\n"
        "- Coordinate notifications, audit records, or downstream updates where applicable\n"
        "- Support supporting views, summaries, or status retrieval required by users or stakeholders\n\n"
        "## Validation and Business Rules Notes\n"
        "- Enforce server-side validation for required inputs and business constraints\n"
        "- Validate that actions are allowed for the requesting role and current record state\n"
        "- Prevent invalid state transitions or conflicting updates\n"
        "- Apply business rules consistently even if frontend validation is bypassed\n"
        "- Ensure rule handling remains traceable for support and audit review where needed\n\n"
        "## Persistence and Data Handling Notes\n"
        "- Preserve consistency of the primary business record and related state updates\n"
        "- Record status changes, history, or audit information where required\n"
        "- Handle concurrent updates carefully to avoid stale or conflicting writes\n"
        "- Ensure supporting or reference data dependencies are resolved consistently\n"
        "- Maintain clear ownership of primary record updates versus downstream side effects\n\n"
        "## Integration and Event Handling Notes\n"
        "- Coordinate with dependent systems or services when business actions require external updates\n"
        "- Emit or handle events for notifications, auditing, or downstream processing where relevant\n"
        "- Keep integration behavior aligned with the data and event architecture guidance\n"
        "- Consider asynchronous handling for non-blocking downstream work where appropriate\n"
        "- Ensure event or integration behavior does not compromise business record consistency\n\n"
        "## Error Handling Notes\n"
        "- Return clear backend failure states for invalid requests, unauthorized actions, or missing dependencies\n"
        "- Distinguish validation failures from processing failures and downstream dependency failures\n"
        "- Consider retry handling for transient downstream or event delivery failures\n"
        "- Ensure important failures are visible for support, monitoring, or operational review\n"
        "- Avoid partial updates where business state changes and downstream actions must remain consistent\n\n"
        "## Security and Access Notes\n"
        "- Enforce role-based authorization for all backend actions\n"
        "- Protect sensitive business and user data in processing and persistence layers\n"
        "- Validate that only allowed users can view, create, update, or act on records\n"
        "- Ensure audit-relevant actions are tracked where required\n"
        "- Avoid trusting frontend-only restrictions for access or business rule enforcement\n\n"
        "## Codebase Impact Analysis\n"
        f"{codebase_impact}\n\n"
        "## Backend Implementation Notes\n"
        "- Reuse or extend existing service, handler, and repository patterns where possible instead of duplicating logic\n"
        "- Align validation handling, state transitions, and persistence behavior with current codebase conventions if available\n"
        "- Add or update workflow-specific service logic, record management behavior, and integration handling as needed\n"
        "- Ensure backend processing supports success, validation failure, dependency failure, and retry-aware paths cleanly\n"
        "- Keep boundaries clear between orchestration, validation, persistence, and downstream side effects\n\n"
        "## Unit Test Notes\n"
        "- Add service-level tests for business workflow behavior and state transitions\n"
        "- Add validation-focused tests for required input rules and invalid action paths\n"
        "- Add tests for role-based authorization behavior where applicable\n"
        "- Add tests for persistence-related edge cases and failure handling paths\n"
        "- Add tests for integration or event-triggering behavior where relevant\n"
        "- Extend existing test suites rather than duplicating equivalent coverage if behavior already exists\n\n"
        "## Assumptions\n"
        "- The feature involves one or more backend-managed business workflows\n"
        "- Role-aware processing and state transitions are relevant to the feature\n"
        "- Some persistence, integration, or event-driven behavior is likely required\n"
        "- Shared service or data-access patterns may already exist in the codebase\n\n"
        "## Constraints\n"
        "- Backend implementation may need to align with enterprise service standards and platform constraints\n"
        "- Data retention, auditability, and security expectations may affect processing design\n"
        "- Existing codebase conventions may constrain service layering or persistence patterns\n\n"
        "## Dependencies\n"
        "- Requirement and business rule clarity\n"
        "- Technical architecture direction\n"
        "- Data and event architecture outputs\n"
        "- Jira delivery breakdown and story scope\n"
        "- Existing backend codebase structure and shared backend utilities if a codebase path is provided\n\n"
        "## Risks\n"
        "- Ambiguous business rules may cause inconsistent backend behavior\n"
        "- Tight coupling with downstream systems may affect maintainability\n"
        "- Event or integration failures may create operational inconsistency if not handled carefully\n"
        "- Poor state handling may create data integrity or concurrency issues\n"
        "- Misalignment with existing backend structure may increase rework if codebase conventions are ignored\n\n"
        "## Open Questions\n"
        "- Which actions must be strictly synchronous versus asynchronous?\n"
        "- What state transitions are allowed or restricted for each role?\n"
        "- Which downstream updates are mandatory for successful completion of the workflow?\n"
        "- Are there transaction, retry, or reconciliation expectations for integration failures?\n"
        "- Which backend test framework and project conventions should be followed in the codebase?\n"
    )


def detect_generation_targets(codebase_scan: dict, codebase_path: str = None):
    framework = codebase_scan["framework"]

    if codebase_scan["exists"] and codebase_path:
        base_target = codebase_path
    else:
        agent_dir = ensure_agent_dir(AGENT_NAME)
        base_target = os.path.join(agent_dir, "generated_code")

    os.makedirs(base_target, exist_ok=True)

    if framework == "Spring Boot":
        service_dir = os.path.join(base_target, "service")
        test_dir = os.path.join(base_target, "test")
        os.makedirs(service_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)
        return {
            "service_file": os.path.join(service_dir, "PrimaryWorkflowService.java"),
            "test_file": os.path.join(test_dir, "PrimaryWorkflowServiceTest.java"),
            "framework": framework,
            "base_target": base_target,
        }

    if framework == "Node.js/Express":
        service_dir = os.path.join(base_target, "services")
        test_dir = os.path.join(base_target, "tests")
        os.makedirs(service_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)
        return {
            "service_file": os.path.join(service_dir, "primaryWorkflowService.js"),
            "test_file": os.path.join(test_dir, "primaryWorkflowService.test.js"),
            "framework": framework,
            "base_target": base_target,
        }

    if framework in ["Python/FastAPI", "Python/Flask", "Unknown"]:
        service_dir = os.path.join(base_target, "services")
        test_dir = os.path.join(base_target, "tests")
        os.makedirs(service_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)
        return {
            "service_file": os.path.join(service_dir, "primary_workflow_service.py"),
            "test_file": os.path.join(test_dir, "test_primary_workflow_service.py"),
            "framework": framework,
            "base_target": base_target,
        }

    if framework == ".NET":
        service_dir = os.path.join(base_target, "Services")
        test_dir = os.path.join(base_target, "Tests")
        os.makedirs(service_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)
        return {
            "service_file": os.path.join(service_dir, "PrimaryWorkflowService.cs"),
            "test_file": os.path.join(test_dir, "PrimaryWorkflowServiceTests.cs"),
            "framework": framework,
            "base_target": base_target,
        }

    service_dir = os.path.join(base_target, "services")
    test_dir = os.path.join(base_target, "tests")
    os.makedirs(service_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)
    return {
        "service_file": os.path.join(service_dir, "primary_workflow_service.py"),
        "test_file": os.path.join(test_dir, "test_primary_workflow_service.py"),
        "framework": "Unknown",
        "base_target": base_target,
    }


def generate_backend_scaffold(framework: str):
    if framework in ["Python/FastAPI", "Python/Flask", "Unknown"]:
        service_code = '''class PrimaryWorkflowService:
    def validate(self, payload: dict):
        errors = {}
        if not payload.get("field_one"):
            errors["field_one"] = "field_one is required"
        if not payload.get("field_two"):
            errors["field_two"] = "field_two is required"
        return errors

    def process(self, payload: dict):
        errors = self.validate(payload)
        if errors:
            return {"status": "validation_error", "errors": errors}

        return {
            "status": "success",
            "message": "Primary workflow processed successfully",
            "data": payload
        }
'''
        test_code = '''from services.primary_workflow_service import PrimaryWorkflowService


def test_validation_fails_for_missing_fields():
    service = PrimaryWorkflowService()
    result = service.process({})
    assert result["status"] == "validation_error"
    assert "field_one" in result["errors"]
    assert "field_two" in result["errors"]


def test_success_for_valid_payload():
    service = PrimaryWorkflowService()
    result = service.process({"field_one": "value1", "field_two": "value2"})
    assert result["status"] == "success"
'''
        return service_code, test_code

    if framework == "Node.js/Express":
        service_code = '''class PrimaryWorkflowService {
  validate(payload) {
    const errors = {};
    if (!payload.field_one) errors.field_one = 'field_one is required';
    if (!payload.field_two) errors.field_two = 'field_two is required';
    return errors;
  }

  process(payload) {
    const errors = this.validate(payload);
    if (Object.keys(errors).length > 0) {
      return { status: 'validation_error', errors };
    }

    return {
      status: 'success',
      message: 'Primary workflow processed successfully',
      data: payload,
    };
  }
}

module.exports = PrimaryWorkflowService;
'''
        test_code = '''const PrimaryWorkflowService = require('../services/primaryWorkflowService');

describe('PrimaryWorkflowService', () => {
  test('validation fails for missing fields', () => {
    const service = new PrimaryWorkflowService();
    const result = service.process({});
    expect(result.status).toBe('validation_error');
    expect(result.errors.field_one).toBeDefined();
    expect(result.errors.field_two).toBeDefined();
  });

  test('success for valid payload', () => {
    const service = new PrimaryWorkflowService();
    const result = service.process({ field_one: 'value1', field_two: 'value2' });
    expect(result.status).toBe('success');
  });
});
'''
        return service_code, test_code

    if framework == "Spring Boot":
        service_code = '''public class PrimaryWorkflowService {

    public String process(String fieldOne, String fieldTwo) {
        if (fieldOne == null || fieldOne.isBlank()) {
            return "validation_error: fieldOne is required";
        }
        if (fieldTwo == null || fieldTwo.isBlank()) {
            return "validation_error: fieldTwo is required";
        }
        return "success";
    }
}
'''
        test_code = '''import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PrimaryWorkflowServiceTest {

    @Test
    void validationFailsWhenFieldsMissing() {
        PrimaryWorkflowService service = new PrimaryWorkflowService();
        assertTrue(service.process("", "").startsWith("validation_error"));
    }

    @Test
    void successWhenValidInputProvided() {
        PrimaryWorkflowService service = new PrimaryWorkflowService();
        assertEquals("success", service.process("value1", "value2"));
    }
}
'''
        return service_code, test_code

    if framework == ".NET":
        service_code = '''public class PrimaryWorkflowService
{
    public string Process(string fieldOne, string fieldTwo)
    {
        if (string.IsNullOrWhiteSpace(fieldOne))
            return "validation_error: fieldOne is required";

        if (string.IsNullOrWhiteSpace(fieldTwo))
            return "validation_error: fieldTwo is required";

        return "success";
    }
}
'''
        test_code = '''using Xunit;

public class PrimaryWorkflowServiceTests
{
    [Fact]
    public void ValidationFailsWhenFieldsMissing()
    {
        var service = new PrimaryWorkflowService();
        var result = service.Process("", "");
        Assert.StartsWith("validation_error", result);
    }

    [Fact]
    public void SuccessWhenValidInputProvided()
    {
        var service = new PrimaryWorkflowService();
        var result = service.Process("value1", "value2");
        Assert.Equal("success", result);
    }
}
'''
        return service_code, test_code

    return "", ""


def write_generated_code(codebase_scan: dict, codebase_path: str = None, write_changes: bool = False):
    targets = detect_generation_targets(codebase_scan, codebase_path)
    service_code, test_code = generate_backend_scaffold(targets["framework"])

    if not write_changes:
        return {
            "write_mode": False,
            "target_base": targets["base_target"],
            "service_file": targets["service_file"],
            "test_file": targets["test_file"],
            "files_written": [],
        }

    os.makedirs(os.path.dirname(targets["service_file"]), exist_ok=True)
    os.makedirs(os.path.dirname(targets["test_file"]), exist_ok=True)

    with open(targets["service_file"], "w", encoding="utf-8") as f:
        f.write(service_code)

    with open(targets["test_file"], "w", encoding="utf-8") as f:
        f.write(test_code)

    return {
        "write_mode": True,
        "target_base": targets["base_target"],
        "service_file": targets["service_file"],
        "test_file": targets["test_file"],
        "files_written": [targets["service_file"], targets["test_file"]],
    }


def save_generation_summary(generation_result: dict):
    summary_lines = [
        "# Backend Code Generation Summary",
        "",
        f"- Write Mode: {generation_result['write_mode']}",
        f"- Target Base: {generation_result['target_base']}",
        f"- Service File: {generation_result['service_file']}",
        f"- Test File: {generation_result['test_file']}",
        "",
        "## Files Written",
    ]

    if generation_result["files_written"]:
        for path in generation_result["files_written"]:
            summary_lines.append(f"- {path}")
    else:
        summary_lines.append("- No files written. Run with write_changes=True to generate files.")

    write_agent_subfile(AGENT_NAME, "generated_code_summary.md", "\n".join(summary_lines))


def run_backend_developer(
    input_text: str = None,
    story_instruction_path: str = None,
    codebase_path: str = None,
    write_changes: bool = False
):
    system_prompt = load_prompt()

    if story_instruction_path:
        input_text = load_story_instruction(story_instruction_path)
    elif not input_text:
        input_text = build_default_input()

    codebase_scan = scan_codebase(codebase_path)
    final_input = build_input(input_text, codebase_scan)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input, codebase_scan)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input, codebase_scan)

    if not validate_output(output):
        output = (
            "# Backend Delivery Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Backend Developer format and needs manual review.\n\n"
            "## Detected Backend Context\n"
            "- Manual review required\n\n"
            "## Core Backend Responsibilities\n"
            "- Manual review required\n\n"
            "## Validation and Business Rules Notes\n"
            "- Manual review required\n\n"
            "## Persistence and Data Handling Notes\n"
            "- Manual review required\n\n"
            "## Integration and Event Handling Notes\n"
            "- Manual review required\n\n"
            "## Error Handling Notes\n"
            "- Manual review required\n\n"
            "## Security and Access Notes\n"
            "- Manual review required\n\n"
            "## Codebase Impact Analysis\n"
            "- Manual review required\n\n"
            "## Backend Implementation Notes\n"
            "- Manual review required\n\n"
            "## Unit Test Notes\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- Output validation failed\n\n"
            "## Constraints\n"
            "- Output validation failed\n\n"
            "## Dependencies\n"
            "- Output validation failed\n\n"
            "## Risks\n"
            "- Output validation failed\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    generation_result = write_generated_code(
        codebase_scan=codebase_scan,
        codebase_path=codebase_path,
        write_changes=write_changes
    )
    save_generation_summary(generation_result)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "story_instruction_path": story_instruction_path,
        "codebase_path": codebase_path,
        "detected_framework": codebase_scan["framework"],
        "write_changes": write_changes,
        "generated_files": generation_result["files_written"],
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }
