import os
import sys
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    write_agent_subfile,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
)

AGENT_NAME = "jira_generator"
PROMPT_FILE = "jira_generator.txt"

# Setup search paths for modules
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm


def load_prompt():
    prompt_path = os.path.join(APP_DIR, "prompts", PROMPT_FILE)
    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Jira Delivery Breakdown",
        "## Summary",
        "## Epics",
        "## User Stories",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        req_output = read_agent_file("requirement_analyzer", "output", "md")
        parts.append(f"## Requirement Analysis\n{req_output}")
    else:
        try:
            req_output = read_agent_subfile("requirement_analyzer", "output.md")
            parts.append(f"## Requirement Analysis\n{req_output}")
        except Exception:
            pass

    if agent_file_exists("product_owner", "output", "md"):
        po_output = read_agent_file("product_owner", "output", "md")
        parts.append(f"## Product Scope Recommendation\n{po_output}")
    else:
        try:
            po_output = read_agent_subfile("product_owner", "output.md")
            parts.append(f"## Product Scope Recommendation\n{po_output}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        arch_output = read_agent_file("technical_architect", "output", "md")
        parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
    else:
        try:
            arch_output = read_agent_subfile("technical_architect", "output.md")
            parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
        except Exception:
            pass

    if agent_file_exists("data_event_architect", "output", "md"):
        data_event_output = read_agent_file("data_event_architect", "output", "md")
        parts.append(f"## Data and Event Architecture Recommendation\n{data_event_output}")
    else:
        try:
            data_event_output = read_agent_subfile("data_event_architect", "output.md")
            parts.append(f"## Data and Event Architecture Recommendation\n{data_event_output}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer, product_owner, technical_architect, or data_event_architect."
        )

    return "\n\n".join(parts)


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Jira Story Generator Agent.\n\n"
        "Generate only the required Jira delivery breakdown output.\n\n"
        "Important:\n"
        "- Do not generate architecture design, low-level implementation, APIs, schemas, or code.\n"
        "- Use the exact required output headings.\n"
        "- Stories must be practical and suitable for Jira.\n"
        "- Use the exact required story markdown format from the system prompt.\n"
        "- Include FE Notes, BE Notes, and QA Notes for each user story.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on Jira-ready epics and user stories\n"
        "- Use the exact story markdown format required in the prompt\n"
        "- Include acceptance criteria, priority, story points, dependencies, FE Notes, BE Notes, and QA Notes\n"
        "- Do not include architecture design, implementation plan, APIs, schemas, or code\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return ask_llm(system_prompt, user_input)


def infer_agent_ownership(story_text: str):
    lower_story = story_text.lower()

    if "documentation" in lower_story or "support notes" in lower_story or "handover" in lower_story:
        return {
            "primary_agents": ["Documentation Agent"],
            "supporting_agents": ["Product Owner Agent"]
        }

    if "monitoring" in lower_story or "alert" in lower_story or "observability" in lower_story:
        return {
            "primary_agents": ["Monitoring & Observability Agent"],
            "supporting_agents": ["Backend Developer Agent", "DevOps / Release Agent"]
        }

    if "security" in lower_story or "compliance" in lower_story or "authorization" in lower_story:
        return {
            "primary_agents": ["Security & Compliance Agent"],
            "supporting_agents": ["Backend Developer Agent", "QA / Test Engineer Agent"]
        }

    primary_agents = []
    supporting_agents = [
        "Requirement Analyzer Agent",
        "Product Owner Agent",
        "Technical Architect Agent",
        "Data & Event Architecture Agent",
        "Security & Compliance Agent",
        "Documentation Agent"
    ]

    if "**FE Notes:**" in story_text and "No frontend changes expected" not in story_text:
        primary_agents.append("Frontend & UX/UI Agent")

    if "**BE Notes:**" in story_text and "No backend changes expected" not in story_text:
        primary_agents.append("Backend Developer Agent")

    if "**QA Notes:**" in story_text:
        primary_agents.append("QA / Test Engineer Agent")

    if "notification" in lower_story or "audit" in lower_story or "event" in lower_story:
        supporting_agents.extend([
            "Monitoring & Observability Agent",
            "DevOps / Release Agent"
        ])

    if "data source" in lower_story or "integration" in lower_story or "persistence" in lower_story:
        supporting_agents.append("Data & Event Architecture Agent")

    if not primary_agents:
        primary_agents = ["Jira Story Generator Agent"]

    primary_agents = list(dict.fromkeys(primary_agents))
    supporting_agents = list(dict.fromkeys(supporting_agents))

    return {
        "primary_agents": primary_agents,
        "supporting_agents": supporting_agents
    }


def extract_story_field(story_text: str, field_name: str):
    lines = story_text.splitlines()

    if field_name == "Story Title":
        for line in lines:
            if line.startswith("#### Story Title:"):
                return line.replace("#### Story Title:", "").strip()
        return "TBD"

    prefix = f"- **{field_name}:**"
    for line in lines:
        if line.strip().startswith(prefix):
            return line.strip().replace(prefix, "").strip()
    return "TBD"


def extract_epic_name(story_text: str):
    for line in story_text.splitlines():
        if line.startswith("### Epic:"):
            return line.replace("### Epic:", "").strip()
    return "Unknown Epic"


def extract_acceptance_criteria(story_text: str):
    lines = story_text.splitlines()
    criteria = []
    capture = False

    for line in lines:
        stripped = line.strip()

        if stripped == "- **Acceptance Criteria:**":
            capture = True
            continue

        if capture:
            if stripped.startswith("- **") or stripped.startswith("#### Story Title:") or stripped.startswith("### Epic:"):
                break
            if stripped.startswith("- "):
                criteria.append(stripped)

    return criteria


def build_delivery_sequence(primary_agents, supporting_agents):
    sequence = []
    step = 1

    if "Frontend & UX/UI Agent" in primary_agents:
        sequence.append(f"{step}. Frontend & UX/UI Agent defines UI behavior, user interaction flow, and validation expectations.")
        step += 1

    if "Backend Developer Agent" in primary_agents:
        sequence.append(f"{step}. Backend Developer Agent defines business processing, persistence, and integration behavior.")
        step += 1

    if "QA / Test Engineer Agent" in primary_agents:
        sequence.append(f"{step}. QA / Test Engineer Agent derives test scenarios and validation coverage from the story and acceptance criteria.")
        step += 1

    if "Documentation Agent" in primary_agents:
        sequence.append(f"{step}. Documentation Agent updates story-level and delivery-level documentation.")
        step += 1

    if "Monitoring & Observability Agent" in primary_agents:
        sequence.append(f"{step}. Monitoring & Observability Agent defines required logs, metrics, and alert considerations.")
        step += 1

    if "Security & Compliance Agent" in primary_agents:
        sequence.append(f"{step}. Security & Compliance Agent performs focused security and compliance review for the story.")
        step += 1

    if supporting_agents:
        sequence.append(f"{step}. Supporting review agents validate alignment, risks, architecture impact, data/event impact, and documentation completeness.")

    return sequence


def build_story_instruction(story_text: str) -> str:
    epic_name = extract_epic_name(story_text)
    title = extract_story_field(story_text, "Story Title")
    description = extract_story_field(story_text, "Story Description")
    priority = extract_story_field(story_text, "Priority")
    story_points = extract_story_field(story_text, "Story Points")
    dependencies = extract_story_field(story_text, "Dependencies")
    fe_notes = extract_story_field(story_text, "FE Notes")
    be_notes = extract_story_field(story_text, "BE Notes")
    qa_notes = extract_story_field(story_text, "QA Notes")
    acceptance_criteria = extract_acceptance_criteria(story_text)

    ownership = infer_agent_ownership(story_text)
    primary_agents = ownership["primary_agents"]
    supporting_agents = ownership["supporting_agents"]
    delivery_sequence = build_delivery_sequence(primary_agents, supporting_agents)

    coordinator_agent = "Jira Story Generator Agent"

    instruction = []
    instruction.append(f"# Story Instruction: {title}\n")
    instruction.append(f"## Epic\n{epic_name}\n")
    instruction.append(f"## Story Description\n{description}\n")

    instruction.append("## Acceptance Criteria")
    if acceptance_criteria:
        instruction.extend(acceptance_criteria)
    else:
        instruction.append("- TBD")
    instruction.append("")

    instruction.append(f"## Priority\n{priority}\n")
    instruction.append(f"## Story Points\n{story_points}\n")
    instruction.append(f"## Dependencies\n- {dependencies}\n")

    instruction.append("## Story Coordination")
    instruction.append(f"- **Coordinator Agent:** {coordinator_agent}")
    instruction.append("")

    instruction.append("## Primary Delivery Agents")
    for agent in primary_agents:
        instruction.append(f"- {agent}")
    instruction.append("")

    instruction.append("## Supporting Review Agents")
    for agent in supporting_agents:
        instruction.append(f"- {agent}")
    instruction.append("")

    instruction.append("## Delivery Sequence")
    for step in delivery_sequence:
        instruction.append(f"- {step}")
    instruction.append("")

    instruction.append("## Agent Instructions\n")

    for agent in primary_agents:
        instruction.append(f"### {agent}")
        if agent == "Frontend & UX/UI Agent":
            instruction.append(f"- Use FE Notes as the main delivery guidance: {fe_notes}")
            instruction.append("- Define screens, user interactions, validations, and usability expectations.")
            instruction.append("- Keep implementation aligned with story acceptance criteria.")
        elif agent == "Backend Developer Agent":
            instruction.append(f"- Use BE Notes as the main delivery guidance: {be_notes}")
            instruction.append("- Implement business workflow handling, validations, processing logic, persistence, and integration behavior as needed.")
            instruction.append("- Keep implementation aligned with story acceptance criteria.")
        elif agent == "QA / Test Engineer Agent":
            instruction.append(f"- Use QA Notes as the main validation guidance: {qa_notes}")
            instruction.append("- Create positive, negative, and edge-case scenarios based on acceptance criteria.")
            instruction.append("- Validate dependencies and regression risk where applicable.")
        elif agent == "Documentation Agent":
            instruction.append("- Update project, support, or handover documentation relevant to this story.")
            instruction.append("- Ensure documentation reflects the final delivered behavior.")
        elif agent == "Monitoring & Observability Agent":
            instruction.append("- Define required logs, metrics, traces, or alert considerations relevant to this story.")
        elif agent == "Security & Compliance Agent":
            instruction.append("- Review this story for authorization, secure handling, and compliance considerations.")
        elif agent == "Jira Story Generator Agent":
            instruction.append("- Refine this story further if more delivery detail is needed.")
            instruction.append("- Coordinate story routing, ownership clarity, and instruction completeness.")
        else:
            instruction.append("- Execute responsibilities relevant to this story based on agent specialization.")
        instruction.append("")

    for agent in supporting_agents:
        instruction.append(f"### {agent}")
        instruction.append("- Provide supporting analysis, review, or guidance relevant to this story.")
        instruction.append("")

    return "\n".join(instruction)


def split_story_blocks(output: str):
    lines = output.splitlines()
    stories = []
    current_epic = None
    current_story_lines = []

    inside_user_stories = False

    for line in lines:
        if line.strip() == "## User Stories":
            inside_user_stories = True
            continue

        if inside_user_stories and line.startswith("## ") and line.strip() != "## User Stories":
            # End of stories section
            if current_story_lines:
                stories.append("\n".join(current_story_lines).strip())
                current_story_lines = []
            break

        if not inside_user_stories:
            continue

        if line.startswith("### Epic:"):
            if current_story_lines:
                stories.append("\n".join(current_story_lines).strip())
                current_story_lines = []
            current_epic = line.strip()
            continue

        if line.startswith("#### Story Title:"):
            if current_story_lines:
                stories.append("\n".join(current_story_lines).strip())
                current_story_lines = []
            if current_epic:
                current_story_lines.append(current_epic)
            current_story_lines.append(line.strip())
            continue

        if current_story_lines:
            current_story_lines.append(line)

    if current_story_lines:
        stories.append("\n".join(current_story_lines).strip())

    return [story for story in stories if "#### Story Title:" in story]


def save_story_files(output: str):
    story_blocks = split_story_blocks(output)

    for index, story_content in enumerate(story_blocks, start=1):
        write_agent_subfile(AGENT_NAME, f"story_{index}.md", story_content)

        instruction_content = build_story_instruction(story_content)
        write_agent_subfile(AGENT_NAME, f"story_{index}_instruction.md", instruction_content)


def run_jira_generator(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        input_text = build_default_input()

    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        output = (
            "# Jira Delivery Breakdown\n\n"
            "## Summary\n"
            "Output validation failed, manual review required.\n\n"
            "## Epics\n"
            "## User Stories\n"
            "## Assumptions\n"
            "## Constraints\n"
            "## Dependencies\n"
            "## Risks\n"
            "## Open Questions\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)
    save_story_files(output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }