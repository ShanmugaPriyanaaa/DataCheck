import os
import sys
import glob

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
AGENTS_DIR = os.path.join(CURRENT_DIR, "agents")

sys.path.insert(0, CURRENT_DIR)
sys.path.insert(0, AGENTS_DIR)

from requirement_analyzer import run_requirement_analyzer
from product_owner import run_product_owner
from technical_architect import run_technical_architect
from data_event_architect import run_data_event_architect
from jira_generator import run_jira_generator
from frontend_ux_agent import run_frontend_ux_agent
from backend_developer import run_backend_developer
from qa_agent import run_qa_agent
from code_review_agent import run_code_review_agent
from security_agent import run_security_agent
from devops_agent import run_devops_agent
from monitoring_agent import run_monitoring_agent
from risk_impact_agent import run_risk_impact_agent
from documentation_agent import run_documentation_agent
from integration_summary_agent import run_integration_summary_agent
from change_impact_agent import run_change_impact_agent
from rca_incident_agent import run_rca_incident_agent


def section(title: str, content: str) -> str:
    return f"\n\n## {title}\n{content}"


def get_story_instruction_files():
    story_dir = os.path.join(os.path.dirname(CURRENT_DIR), "data", "jira_generator")
    pattern = os.path.join(story_dir, "story_*_instruction.md")
    return sorted(glob.glob(pattern))


def run_pipeline(
    feature_text: str,
    frontend_codebase_path: str = r"C:\AiHackthon\frontEndApp",
    backend_codebase_path: str = r"C:\AiHackthon\backEndApp",
    write_changes: bool = True,
    run_qa_checks: bool = False
):
    outputs = {}

    # Phase 1: Upstream planning/design agents
    req = run_requirement_analyzer(feature_text)
    outputs["requirement_analyzer"] = req

    po = run_product_owner(
        section("Feature Input", feature_text) +
        section("Requirement Analysis", req["output"])
    )
    outputs["product_owner"] = po

    arch = run_technical_architect(
        section("Feature Input", feature_text) +
        section("Requirement Analysis", req["output"]) +
        section("Product Prioritization", po["output"])
    )
    outputs["technical_architect"] = arch

    data_event = run_data_event_architect(
        section("Feature Input", feature_text) +
        section("Requirement Analysis", req["output"]) +
        section("Technical Architecture", arch["output"])
    )
    outputs["data_event_architect"] = data_event

    jira = run_jira_generator(
        section("Feature Input", feature_text) +
        section("Requirement Analysis", req["output"]) +
        section("Technical Architecture", arch["output"]) +
        section("Data & Event Architecture", data_event["output"])
    )
    outputs["jira_generator"] = jira

    # Phase 2: Story-based execution
    story_instruction_files = get_story_instruction_files()
    if not story_instruction_files:
        raise ValueError("No story instruction files found in data/jira_generator. Run jira_generator first.")

    story_execution_outputs = []

    for story_file in story_instruction_files:
        frontend = run_frontend_ux_agent(
            story_instruction_path=story_file,
            codebase_path=frontend_codebase_path,
            write_changes=write_changes
        )

        backend = run_backend_developer(
            story_instruction_path=story_file,
            codebase_path=backend_codebase_path,
            write_changes=write_changes
        )

        qa = run_qa_agent(
            story_instruction_path=story_file,
            frontend_codebase_path=frontend_codebase_path,
            backend_codebase_path=backend_codebase_path,
            write_changes=write_changes,
            run_checks=run_qa_checks
        )

        story_execution_outputs.append({
            "story_instruction_path": story_file,
            "frontend": frontend,
            "backend": backend,
            "qa": qa
        })

    outputs["story_execution"] = story_execution_outputs

    # Aggregate FE/BE/QA outputs for downstream agents
    frontend_combined = "\n\n".join(
        [item["frontend"]["output"] for item in story_execution_outputs]
    ) if story_execution_outputs else ""

    backend_combined = "\n\n".join(
        [item["backend"]["output"] for item in story_execution_outputs]
    ) if story_execution_outputs else ""

    qa_combined = "\n\n".join(
        [item["qa"]["output"] for item in story_execution_outputs]
    ) if story_execution_outputs else ""

    code_review = run_code_review_agent(
        section("Frontend Output", frontend_combined) +
        section("Backend Output", backend_combined)
    )
    outputs["code_review_agent"] = code_review

    security = run_security_agent(
        section("Technical Architecture", arch["output"]) +
        section("Data & Event Architecture", data_event["output"]) +
        section("Frontend Output", frontend_combined) +
        section("Backend Output", backend_combined) +
        section("Code Review", code_review["output"])
    )
    outputs["security_agent"] = security

    devops = run_devops_agent(
        section("Technical Architecture", arch["output"]) +
        section("Backend Output", backend_combined) +
        section("Security Notes", security["output"])
    )
    outputs["devops_agent"] = devops

    monitoring = run_monitoring_agent(
        section("Technical Architecture", arch["output"]) +
        section("Data & Event Architecture", data_event["output"]) +
        section("Backend Output", backend_combined) +
        section("DevOps Output", devops["output"])
    )
    outputs["monitoring_agent"] = monitoring

    risk = run_risk_impact_agent(
        section("Requirement Analysis", req["output"]) +
        section("Technical Architecture", arch["output"]) +
        section("Jira Stories", jira["output"]) +
        section("QA Output", qa_combined) +
        section("Security Output", security["output"]) +
        section("DevOps Output", devops["output"])
    )
    outputs["risk_impact_agent"] = risk

    documentation_input = ""
    for key, val in outputs.items():
        if key == "story_execution":
            continue
        if isinstance(val, dict) and "output" in val:
            documentation_input += section(key, val["output"])

    documentation = run_documentation_agent(documentation_input)
    outputs["documentation_agent"] = documentation

    integration_input = ""
    for key, val in outputs.items():
        if key == "story_execution":
            continue
        if isinstance(val, dict) and "output" in val:
            integration_input += section(key, val["output"])

    integration = run_integration_summary_agent(integration_input)
    outputs["integration_summary_agent"] = integration

    change_impact = run_change_impact_agent(
        section("Feature Input", feature_text) +
        section("Technical Architecture", arch["output"]) +
        section("Data & Event Architecture", data_event["output"]) +
        section("Jira Stories", jira["output"]) +
        section("Integration Summary", integration["output"])
    )
    outputs["change_impact_agent"] = change_impact

    rca = run_rca_incident_agent(
        section("Monitoring Output", monitoring["output"]) +
        section("Backend Output", backend_combined) +
        section("QA Output", qa_combined) +
        section("Change Impact Output", change_impact["output"]) +
        section("Integration Summary", integration["output"])
    )
    outputs["rca_incident_agent"] = rca

    return outputs