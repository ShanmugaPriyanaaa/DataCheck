import { test, expect } from "@playwright/test";

test("employee can open leave request page", async ({ page }) => {
  await page.goto("http://localhost:5173");
  await expect(page.getByText("Leave Management")).toBeVisible();
  await expect(page.getByText("Apply Leave")).toBeVisible();
});

test("manager and HR tabs are available", async ({ page }) => {
  await page.goto("http://localhost:5173");

  await page.getByText("Manager Approval").click();
  await expect(page.getByText("Manager Approvals")).toBeVisible();

  await page.getByText("HR Balance").click();
  await expect(page.getByText("HR Leave Balances")).toBeVisible();

  await page.getByText("Audit Trail").click();
  await expect(page.getByText("Audit Trail")).toBeVisible();
});
