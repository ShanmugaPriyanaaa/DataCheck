# QA Sync Pack

This QA pack is synced with:

- `frontEndApp`
- `backEndApp`

## Frontend tests

```bash
cd frontEndApp
npm install
npm test
```

## Backend tests

```bash
cd backEndApp
mvn test
```

## Manual run

Backend:

```bash
cd backEndApp
mvn spring-boot:run
```

Frontend:

```bash
cd frontEndApp
npm run dev
```

Open:

```text
http://localhost:5173
```
