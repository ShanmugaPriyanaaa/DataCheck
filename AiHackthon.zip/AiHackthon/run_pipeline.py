import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_DIR = BASE_DIR / "app"

sys.path.insert(0, str(APP_DIR))

from orchestrator import run_pipeline

feature_text = """
Build a leave request feature where employees can apply for leave,
managers can approve or reject requests,
HR can track leave balances,
notifications should be sent,
and an audit trail should be maintained.
"""

frontend_path = os.getenv("FRONTEND_CODEBASE_PATH", str(BASE_DIR / "frontEndApp"))
backend_path = os.getenv("BACKEND_CODEBASE_PATH", str(BASE_DIR / "backEndApp"))

result = run_pipeline(
    feature_text=feature_text,
    frontend_codebase_path=frontend_path,
    backend_codebase_path=backend_path,
    write_changes=True,
    run_qa_checks=True
)

print("=== PIPELINE COMPLETED ===")
print(result.keys())
print("Frontend path:", frontend_path)
print("Backend path:", backend_path)
