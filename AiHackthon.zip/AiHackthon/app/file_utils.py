import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def ensure_agent_dir(agent_name: str):
    ensure_data_dir()
    agent_dir = os.path.join(DATA_DIR, agent_name)
    os.makedirs(agent_dir, exist_ok=True)
    return agent_dir


def write_agent_file(agent_name: str, file_type: str, content: str, ext: str = "md"):
    ensure_data_dir()
    filename = f"{agent_name}_{file_type}.{ext}"
    file_path = os.path.join(DATA_DIR, filename)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)

    return file_path


def read_agent_file(agent_name: str, file_type: str, ext: str = "md") -> str:
    filename = f"{agent_name}_{file_type}.{ext}"
    file_path = os.path.join(DATA_DIR, filename)

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"{filename} not found in data folder")

    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def agent_file_exists(agent_name: str, file_type: str, ext: str = "md") -> bool:
    filename = f"{agent_name}_{file_type}.{ext}"
    file_path = os.path.join(DATA_DIR, filename)
    return os.path.exists(file_path)


def write_agent_subfile(agent_name: str, filename: str, content: str):
    agent_dir = ensure_agent_dir(agent_name)
    file_path = os.path.join(agent_dir, filename)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)

    return file_path


def read_agent_subfile(agent_name: str, filename: str) -> str:
    agent_dir = ensure_agent_dir(agent_name)
    file_path = os.path.join(agent_dir, filename)

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"{filename} not found in data/{agent_name}")

    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def agent_subfile_exists(agent_name: str, filename: str) -> bool:
    agent_dir = ensure_agent_dir(agent_name)
    file_path = os.path.join(agent_dir, filename)
    return os.path.exists(file_path)


def save_agent_artifacts(agent_name: str, input_text: str = None, output_text: str = None, retry_input: str = None):
    if input_text is not None:
        write_agent_subfile(agent_name, "input.txt", input_text)

    if output_text is not None:
        write_agent_subfile(agent_name, "output.md", output_text)

    if retry_input is not None:
        write_agent_subfile(agent_name, "retry_input.txt", retry_input)