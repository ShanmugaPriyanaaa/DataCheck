import time
import requests

try:
    from config import LITELLM_API_KEY, LITELLM_BASE_URL, MODEL_NAME, VERIFY_SSL
except ImportError:
    from app.config import LITELLM_API_KEY, LITELLM_BASE_URL, MODEL_NAME, VERIFY_SSL


def ask_llm(system_prompt: str, user_input: str) -> str:
    if not LITELLM_API_KEY:
        raise ValueError("LITELLM_API_KEY is missing. Please check your .env file.")

    base_url = LITELLM_BASE_URL.rstrip("/")
    url = f"{base_url}/chat/completions"

    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
    }

    if "api.openai.com" in base_url:
        headers["Authorization"] = f"Bearer {LITELLM_API_KEY}"
        auth_mode = "OpenAI Bearer Token"
    else:
        headers["x-litellm-api-key"] = LITELLM_API_KEY
        auth_mode = "TCS LiteLLM x-litellm-api-key"

    print("LLM URL:", url)
    print("LLM Model:", MODEL_NAME)
    print("LLM Auth Mode:", auth_mode)

    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input},
        ],
        "temperature": 0.3,
    }

    last_error = None

    for attempt in range(1, 4):
        try:
            print(f"LLM call attempt {attempt}/3 ...")

            response = requests.post(
                url,
                headers=headers,
                json=payload,
                verify=VERIFY_SSL,
                timeout=(30, 360),
            )

            if response.status_code != 200:
                raise Exception(
                    f"LLM API failed.\n"
                    f"Status Code: {response.status_code}\n"
                    f"URL: {url}\n"
                    f"Model: {MODEL_NAME}\n"
                    f"Response: {response.text}"
                )

            data = response.json()
            return data["choices"][0]["message"]["content"]

        except requests.exceptions.ReadTimeout as e:
            last_error = e
            print("Read timeout. Retrying...")
            time.sleep(5 * attempt)

        except requests.exceptions.ConnectionError as e:
            last_error = e
            print("Connection error. Retrying...")
            time.sleep(5 * attempt)

    raise Exception(
        "LLM request failed after 3 attempts. "
        "The prompt may be too large or the model response may be taking too long. "
        f"Last error: {last_error}"
    )
