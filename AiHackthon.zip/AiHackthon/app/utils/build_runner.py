import os
import shutil
import subprocess
from pathlib import Path


def to_text(value) -> str:
    """
    Convert stdout/stderr safely to text.
    Fixes:
    - UnicodeDecodeError on Windows cp1252 output
    - NoneType join errors in format_results
    """
    if value is None:
        return ""

    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")

    return str(value)


def resolve_executable(command_name: str) -> str | None:
    """
    Resolve executable cross-platform.

    On Windows, npm and mvn are usually npm.cmd / mvn.cmd.
    Python subprocess with shell=False may fail if only npm/mvn is passed.
    """
    candidates = [command_name]

    if os.name == "nt":
        candidates.extend([
            f"{command_name}.cmd",
            f"{command_name}.bat",
            f"{command_name}.exe",
        ])

    for candidate in candidates:
        resolved = shutil.which(candidate)
        if resolved:
            return resolved

    return None


def run_command(command: list[str], cwd: str, timeout_seconds: int = 900) -> dict:
    if not cwd or not os.path.exists(cwd):
        return {
            "success": False,
            "error_type": "INVALID_WORKING_DIRECTORY",
            "command": " ".join(command or []),
            "cwd": cwd or "",
            "stdout": "",
            "stderr": f"Invalid working directory: {cwd}",
            "returncode": -1,
        }

    if not command:
        return {
            "success": False,
            "error_type": "INVALID_COMMAND",
            "command": "",
            "cwd": cwd,
            "stdout": "",
            "stderr": "Empty command",
            "returncode": -1,
        }

    executable = resolve_executable(command[0])

    if not executable:
        return {
            "success": False,
            "error_type": "TOOL_NOT_FOUND",
            "command": " ".join(command),
            "cwd": cwd,
            "stdout": "",
            "stderr": (
                f"Required tool not found: {command[0]}\n"
                f"Fix outside code:\n"
                f"- If npm is missing, install Node.js LTS and restart VS Code.\n"
                f"- If mvn is missing, install Maven and restart VS Code.\n"
                f"- Verify with: where {command[0]} or {command[0]} -v"
            ),
            "returncode": -1,
        }

    resolved_command = [executable] + command[1:]

    try:
        result = subprocess.run(
            resolved_command,
            cwd=cwd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_seconds,
            shell=False,
        )

        return {
            "success": result.returncode == 0,
            "error_type": None if result.returncode == 0 else "COMMAND_FAILED",
            "command": " ".join(command),
            "resolved_command": " ".join(resolved_command),
            "cwd": cwd,
            "stdout": to_text(result.stdout),
            "stderr": to_text(result.stderr),
            "returncode": result.returncode,
        }

    except subprocess.TimeoutExpired as e:
        return {
            "success": False,
            "error_type": "TIMEOUT",
            "command": " ".join(command),
            "resolved_command": " ".join(resolved_command),
            "cwd": cwd,
            "stdout": to_text(e.stdout),
            "stderr": to_text(e.stderr) or f"Command timed out after {timeout_seconds} seconds",
            "returncode": -1,
        }

    except Exception as e:
        return {
            "success": False,
            "error_type": "EXECUTION_ERROR",
            "command": " ".join(command),
            "resolved_command": " ".join(resolved_command),
            "cwd": cwd,
            "stdout": "",
            "stderr": to_text(e),
            "returncode": -1,
        }


def run_frontend_checks(frontend_path: str) -> list[dict]:
    path = Path(frontend_path)

    if not (path / "package.json").exists():
        return [{
            "success": False,
            "error_type": "PACKAGE_JSON_NOT_FOUND",
            "command": "frontend check",
            "cwd": frontend_path,
            "stdout": "",
            "stderr": "package.json not found in frontend path",
            "returncode": -1,
        }]

    commands = [
        ["npm", "install"],
        ["npm", "test"],
        ["npm", "run", "build"],
    ]

    results = []

    for command in commands:
        result = run_command(command, frontend_path)
        results.append(result)

        if not result.get("success"):
            break

    return results


def run_backend_checks(backend_path: str) -> list[dict]:
    path = Path(backend_path)

    if (path / "pom.xml").exists():
        commands = [
            ["mvn", "test"],
            ["mvn", "package", "-DskipTests"],
        ]
    elif (path / "build.gradle").exists():
        commands = [
            ["gradle", "test"],
            ["gradle", "build"],
        ]
    else:
        return [{
            "success": False,
            "error_type": "BACKEND_BUILD_FILE_NOT_FOUND",
            "command": "backend check",
            "cwd": backend_path,
            "stdout": "",
            "stderr": "No pom.xml or build.gradle found in backend path",
            "returncode": -1,
        }]

    results = []

    for command in commands:
        result = run_command(command, backend_path)
        results.append(result)

        if not result.get("success"):
            break

    return results


def has_failure(results) -> bool:
    if isinstance(results, dict):
        return any(has_failure(value) for value in results.values())

    return any(not result.get("success") for result in results)


def has_environment_failure(results) -> bool:
    """
    True when failure is caused by local tooling or invalid setup.
    These are not code bugs for FE/BE agents to fix.
    """
    if isinstance(results, dict):
        return any(has_environment_failure(value) for value in results.values())

    environment_errors = {
        "TOOL_NOT_FOUND",
        "INVALID_WORKING_DIRECTORY",
        "PACKAGE_JSON_NOT_FOUND",
        "BACKEND_BUILD_FILE_NOT_FOUND",
    }

    return any(result.get("error_type") in environment_errors for result in results)


def format_results(results) -> str:
    if isinstance(results, dict):
        lines = []

        for key, value in results.items():
            lines.append("=" * 100)
            lines.append(str(key).upper())
            lines.append("=" * 100)
            lines.append(format_results(value))

        return "\n".join(str(line) for line in lines)

    lines = []

    for result in results or []:
        lines.append("=" * 100)
        lines.append(f"Command: {to_text(result.get('command'))}")

        resolved_command = result.get("resolved_command")
        if resolved_command:
            lines.append(f"Resolved Command: {to_text(resolved_command)}")

        lines.append(f"CWD: {to_text(result.get('cwd'))}")
        lines.append(f"Success: {to_text(result.get('success'))}")
        lines.append(f"Error Type: {to_text(result.get('error_type'))}")
        lines.append(f"Return Code: {to_text(result.get('returncode'))}")
        lines.append("")
        lines.append("STDOUT:")
        lines.append(to_text(result.get("stdout")))
        lines.append("")
        lines.append("STDERR:")
        lines.append(to_text(result.get("stderr")))

    return "\n".join(str(line) for line in lines)
