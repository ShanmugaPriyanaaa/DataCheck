
import os
from pathlib import Path
from base_agent import run_agent


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def resolve_target_path(path_value: str | None, default_folder: str) -> Path:
    project_root = get_project_root()
    default_path = project_root / default_folder

    if not path_value:
        return default_path

    candidate = Path(path_value)
    normalized = str(candidate).replace("/", "\\").lower()

    # Avoid old hardcoded path; always write to this project if old C:\AiHackthon is passed.
    if normalized.startswith("c:\\aihackthon"):
        return default_path

    return candidate


def read_optional_file(path_value: str | None) -> str:
    if not path_value:
        return ""

    path = Path(path_value)
    if not path.exists():
        return ""

    return path.read_text(encoding="utf-8")


def write_target_file(base_dir: Path, relative_path: str, content: str, write_changes: bool) -> str | None:
    target = base_dir / relative_path

    if not write_changes:
        return None

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text((content or "").strip() + "\n", encoding="utf-8")
    return str(target)


def write_summary(agent_key: str, target_dir: Path, files_written: list[str], write_changes: bool, qa: bool = False):
    data_dir = get_project_root() / "data" / agent_key
    data_dir.mkdir(parents=True, exist_ok=True)

    summary_path = data_dir / ("generated_test_summary.md" if qa else "generated_code_summary.md")

    lines = [
        f"# {agent_key} Generated Files Summary",
        "",
        f"- Write Changes: {write_changes}",
        f"- Target Directory: {target_dir}",
        f"- Files Written: {len(files_written)}",
        ""
    ]

    if files_written:
        lines.append("## Files")
        lines.append("")
        for file_path in files_written:
            lines.append(f"- {file_path}")
    else:
        lines.append("No files written because write_changes=False.")

    summary_path.write_text("\n".join(lines), encoding="utf-8")


def build_files_written_section(files_written: list[str], write_changes: bool) -> str:
    lines = [
        "",
        "",
        "## Actual Files Written",
        f"- Write Changes Enabled: {write_changes}",
        f"- Files Written Count: {len(files_written)}",
        ""
    ]

    for file_path in files_written:
        lines.append(f"- {file_path}")

    return "\n".join(lines)


AGENT_NAME = "backend_developer"
PROMPT_FILE = "backend_developer.txt"

REQUIRED_SECTIONS = [
    "# Backend Implementation Delivery",
    "## Summary",
    "## Detected Backend Context",
    "## Story Understanding",
    "## API / Endpoint Changes",
    "## Backend Components to Create or Update",
    "## Backend Code Changes",
    "## Dependency Changes",
    "## Validation and Business Rules",
    "## Persistence and Data Handling",
    "## Integration and Event Handling",
    "## Error Handling",
    "## Backend Unit Test Implementation",
    "## Build and Test Readiness",
    "## Generated / Modified Files",
    "## Implementation Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
]

PRIMARY_FILES = {'pom.xml': '\n<project xmlns="http://maven.apache.org/POM/4.0.0"\n         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">\n    <modelVersion>4.0.0</modelVersion>\n\n    <groupId>com.example</groupId>\n    <artifactId>leaveapp</artifactId>\n    <version>0.0.1-SNAPSHOT</version>\n    <name>leaveapp</name>\n\n    <parent>\n        <groupId>org.springframework.boot</groupId>\n        <artifactId>spring-boot-starter-parent</artifactId>\n        <version>3.3.5</version>\n        <relativePath/>\n    </parent>\n\n    <properties>\n        <java.version>17</java.version>\n    </properties>\n\n    <dependencies>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-web</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-validation</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-data-jpa</artifactId>\n        </dependency>\n        <dependency>\n            <groupId>com.h2database</groupId>\n            <artifactId>h2</artifactId>\n            <scope>runtime</scope>\n        </dependency>\n        <dependency>\n            <groupId>org.postgresql</groupId>\n            <artifactId>postgresql</artifactId>\n            <scope>runtime</scope>\n        </dependency>\n        <dependency>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-starter-test</artifactId>\n            <scope>test</scope>\n        </dependency>\n    </dependencies>\n\n    <build>\n        <plugins>\n            <plugin>\n                <groupId>org.springframework.boot</groupId>\n                <artifactId>spring-boot-maven-plugin</artifactId>\n            </plugin>\n        </plugins>\n    </build>\n</project>\n', 'src/main/resources/application.properties': '\nspring.application.name=leaveapp\nserver.port=8080\n\nspring.datasource.url=jdbc:h2:mem:leaveapp;MODE=PostgreSQL;DATABASE_TO_UPPER=false\nspring.datasource.driver-class-name=org.h2.Driver\nspring.datasource.username=sa\nspring.datasource.password=\n\nspring.jpa.hibernate.ddl-auto=create-drop\nspring.jpa.show-sql=true\n\nspring.h2.console.enabled=true\nspring.h2.console.path=/h2-console\n', 'src/main/java/com/example/leaveapp/LeaveApplication.java': '\npackage com.example.leaveapp;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class LeaveApplication {\n    public static void main(String[] args) {\n        SpringApplication.run(LeaveApplication.class, args);\n    }\n}\n', 'src/main/java/com/example/leaveapp/model/LeaveStatus.java': '\npackage com.example.leaveapp.model;\n\npublic enum LeaveStatus {\n    PENDING,\n    APPROVED,\n    REJECTED\n}\n', 'src/main/java/com/example/leaveapp/model/LeaveRequest.java': '\npackage com.example.leaveapp.model;\n\nimport jakarta.persistence.*;\nimport java.time.LocalDate;\nimport java.time.LocalDateTime;\n\n@Entity\npublic class LeaveRequest {\n    @Id\n    @GeneratedValue(strategy = GenerationType.IDENTITY)\n    private Long id;\n\n    private Long employeeId;\n    private String leaveType;\n    private LocalDate startDate;\n    private LocalDate endDate;\n    private String reason;\n\n    @Enumerated(EnumType.STRING)\n    private LeaveStatus status = LeaveStatus.PENDING;\n\n    private String managerComments;\n    private LocalDateTime createdAt;\n    private LocalDateTime updatedAt;\n\n    @PrePersist\n    void onCreate() {\n        createdAt = LocalDateTime.now();\n        updatedAt = LocalDateTime.now();\n    }\n\n    @PreUpdate\n    void onUpdate() {\n        updatedAt = LocalDateTime.now();\n    }\n\n    public Long getId() { return id; }\n    public Long getEmployeeId() { return employeeId; }\n    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }\n    public String getLeaveType() { return leaveType; }\n    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }\n    public LocalDate getStartDate() { return startDate; }\n    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }\n    public LocalDate getEndDate() { return endDate; }\n    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }\n    public String getReason() { return reason; }\n    public void setReason(String reason) { this.reason = reason; }\n    public LeaveStatus getStatus() { return status; }\n    public void setStatus(LeaveStatus status) { this.status = status; }\n    public String getManagerComments() { return managerComments; }\n    public void setManagerComments(String managerComments) { this.managerComments = managerComments; }\n    public LocalDateTime getCreatedAt() { return createdAt; }\n    public LocalDateTime getUpdatedAt() { return updatedAt; }\n}\n', 'src/main/java/com/example/leaveapp/model/EmployeeLeaveBalance.java': '\npackage com.example.leaveapp.model;\n\nimport jakarta.persistence.Entity;\nimport jakarta.persistence.Id;\n\n@Entity\npublic class EmployeeLeaveBalance {\n    @Id\n    private Long employeeId;\n    private String employeeName;\n    private int balance;\n\n    public EmployeeLeaveBalance() {}\n\n    public EmployeeLeaveBalance(Long employeeId, String employeeName, int balance) {\n        this.employeeId = employeeId;\n        this.employeeName = employeeName;\n        this.balance = balance;\n    }\n\n    public Long getEmployeeId() { return employeeId; }\n    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }\n    public String getEmployeeName() { return employeeName; }\n    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }\n    public int getBalance() { return balance; }\n    public void setBalance(int balance) { this.balance = balance; }\n}\n', 'src/main/java/com/example/leaveapp/model/AuditTrail.java': '\npackage com.example.leaveapp.model;\n\nimport jakarta.persistence.*;\nimport java.time.LocalDateTime;\n\n@Entity\npublic class AuditTrail {\n    @Id\n    @GeneratedValue(strategy = GenerationType.IDENTITY)\n    private Long id;\n\n    private Long leaveRequestId;\n    private String action;\n    private Long userId;\n    private LocalDateTime timestamp;\n\n    public AuditTrail() {}\n\n    public AuditTrail(Long leaveRequestId, String action, Long userId) {\n        this.leaveRequestId = leaveRequestId;\n        this.action = action;\n        this.userId = userId;\n        this.timestamp = LocalDateTime.now();\n    }\n\n    public Long getId() { return id; }\n    public Long getLeaveRequestId() { return leaveRequestId; }\n    public String getAction() { return action; }\n    public Long getUserId() { return userId; }\n    public LocalDateTime getTimestamp() { return timestamp; }\n}\n', 'src/main/java/com/example/leaveapp/dto/CreateLeaveRequestDto.java': '\npackage com.example.leaveapp.dto;\n\nimport jakarta.validation.constraints.FutureOrPresent;\nimport jakarta.validation.constraints.NotBlank;\nimport jakarta.validation.constraints.NotNull;\nimport java.time.LocalDate;\n\npublic class CreateLeaveRequestDto {\n    @NotNull\n    private Long employeeId;\n\n    @NotBlank\n    private String leaveType;\n\n    @NotNull\n    @FutureOrPresent\n    private LocalDate startDate;\n\n    @NotNull\n    @FutureOrPresent\n    private LocalDate endDate;\n\n    @NotBlank\n    private String reason;\n\n    public Long getEmployeeId() { return employeeId; }\n    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }\n    public String getLeaveType() { return leaveType; }\n    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }\n    public LocalDate getStartDate() { return startDate; }\n    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }\n    public LocalDate getEndDate() { return endDate; }\n    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }\n    public String getReason() { return reason; }\n    public void setReason(String reason) { this.reason = reason; }\n}\n', 'src/main/java/com/example/leaveapp/dto/DecisionDto.java': '\npackage com.example.leaveapp.dto;\n\npublic class DecisionDto {\n    private Long managerId;\n    private String comments;\n\n    public Long getManagerId() { return managerId; }\n    public void setManagerId(Long managerId) { this.managerId = managerId; }\n    public String getComments() { return comments; }\n    public void setComments(String comments) { this.comments = comments; }\n}\n', 'src/main/java/com/example/leaveapp/repository/LeaveRequestRepository.java': '\npackage com.example.leaveapp.repository;\n\nimport com.example.leaveapp.model.LeaveRequest;\nimport com.example.leaveapp.model.LeaveStatus;\nimport org.springframework.data.jpa.repository.JpaRepository;\nimport java.util.List;\n\npublic interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {\n    List<LeaveRequest> findByStatus(LeaveStatus status);\n}\n', 'src/main/java/com/example/leaveapp/repository/EmployeeLeaveBalanceRepository.java': '\npackage com.example.leaveapp.repository;\n\nimport com.example.leaveapp.model.EmployeeLeaveBalance;\nimport org.springframework.data.jpa.repository.JpaRepository;\n\npublic interface EmployeeLeaveBalanceRepository extends JpaRepository<EmployeeLeaveBalance, Long> {\n}\n', 'src/main/java/com/example/leaveapp/repository/AuditTrailRepository.java': '\npackage com.example.leaveapp.repository;\n\nimport com.example.leaveapp.model.AuditTrail;\nimport org.springframework.data.jpa.repository.JpaRepository;\n\npublic interface AuditTrailRepository extends JpaRepository<AuditTrail, Long> {\n}\n', 'src/main/java/com/example/leaveapp/service/NotificationService.java': '\npackage com.example.leaveapp.service;\n\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class NotificationService {\n    public void notifyUser(Long userId, String message) {\n        System.out.println("Notification to user " + userId + ": " + message);\n    }\n}\n', 'src/main/java/com/example/leaveapp/service/AuditTrailService.java': '\npackage com.example.leaveapp.service;\n\nimport com.example.leaveapp.model.AuditTrail;\nimport com.example.leaveapp.repository.AuditTrailRepository;\nimport org.springframework.stereotype.Service;\nimport java.util.List;\n\n@Service\npublic class AuditTrailService {\n    private final AuditTrailRepository repository;\n\n    public AuditTrailService(AuditTrailRepository repository) {\n        this.repository = repository;\n    }\n\n    public void log(Long leaveRequestId, String action, Long userId) {\n        repository.save(new AuditTrail(leaveRequestId, action, userId));\n    }\n\n    public List<AuditTrail> findAll() {\n        return repository.findAll();\n    }\n}\n', 'src/main/java/com/example/leaveapp/service/LeaveRequestService.java': '\npackage com.example.leaveapp.service;\n\nimport com.example.leaveapp.dto.CreateLeaveRequestDto;\nimport com.example.leaveapp.dto.DecisionDto;\nimport com.example.leaveapp.model.LeaveRequest;\nimport com.example.leaveapp.model.LeaveStatus;\nimport com.example.leaveapp.repository.LeaveRequestRepository;\nimport org.springframework.stereotype.Service;\nimport org.springframework.transaction.annotation.Transactional;\nimport java.util.List;\n\n@Service\npublic class LeaveRequestService {\n    private final LeaveRequestRepository repository;\n    private final AuditTrailService auditTrailService;\n    private final NotificationService notificationService;\n\n    public LeaveRequestService(\n            LeaveRequestRepository repository,\n            AuditTrailService auditTrailService,\n            NotificationService notificationService) {\n        this.repository = repository;\n        this.auditTrailService = auditTrailService;\n        this.notificationService = notificationService;\n    }\n\n    @Transactional\n    public LeaveRequest create(CreateLeaveRequestDto dto) {\n        if (dto.getEndDate().isBefore(dto.getStartDate())) {\n            throw new IllegalArgumentException("End date cannot be before start date.");\n        }\n\n        LeaveRequest request = new LeaveRequest();\n        request.setEmployeeId(dto.getEmployeeId());\n        request.setLeaveType(dto.getLeaveType());\n        request.setStartDate(dto.getStartDate());\n        request.setEndDate(dto.getEndDate());\n        request.setReason(dto.getReason());\n        request.setStatus(LeaveStatus.PENDING);\n\n        LeaveRequest saved = repository.save(request);\n        auditTrailService.log(saved.getId(), "SUBMITTED", dto.getEmployeeId());\n        notificationService.notifyUser(dto.getEmployeeId(), "Leave request submitted.");\n        return saved;\n    }\n\n    public List<LeaveRequest> pending() {\n        return repository.findByStatus(LeaveStatus.PENDING);\n    }\n\n    @Transactional\n    public LeaveRequest approve(Long id, DecisionDto dto) {\n        LeaveRequest request = repository.findById(id).orElseThrow();\n        if (request.getStatus() != LeaveStatus.PENDING) {\n            throw new IllegalStateException("Only pending requests can be approved.");\n        }\n\n        request.setStatus(LeaveStatus.APPROVED);\n        request.setManagerComments(dto.getComments());\n\n        LeaveRequest saved = repository.save(request);\n        auditTrailService.log(saved.getId(), "APPROVED", dto.getManagerId());\n        notificationService.notifyUser(saved.getEmployeeId(), "Leave request approved.");\n        return saved;\n    }\n\n    @Transactional\n    public LeaveRequest reject(Long id, DecisionDto dto) {\n        if (dto.getComments() == null || dto.getComments().isBlank()) {\n            throw new IllegalArgumentException("Comments are required for rejection.");\n        }\n\n        LeaveRequest request = repository.findById(id).orElseThrow();\n        if (request.getStatus() != LeaveStatus.PENDING) {\n            throw new IllegalStateException("Only pending requests can be rejected.");\n        }\n\n        request.setStatus(LeaveStatus.REJECTED);\n        request.setManagerComments(dto.getComments());\n\n        LeaveRequest saved = repository.save(request);\n        auditTrailService.log(saved.getId(), "REJECTED", dto.getManagerId());\n        notificationService.notifyUser(saved.getEmployeeId(), "Leave request rejected.");\n        return saved;\n    }\n}\n', 'src/main/java/com/example/leaveapp/controller/LeaveRequestController.java': '\npackage com.example.leaveapp.controller;\n\nimport com.example.leaveapp.dto.CreateLeaveRequestDto;\nimport com.example.leaveapp.dto.DecisionDto;\nimport com.example.leaveapp.model.LeaveRequest;\nimport com.example.leaveapp.service.LeaveRequestService;\nimport jakarta.validation.Valid;\nimport org.springframework.web.bind.annotation.*;\nimport java.util.List;\n\n@RestController\n@RequestMapping("/api/leave-requests")\n@CrossOrigin(origins = "*")\npublic class LeaveRequestController {\n    private final LeaveRequestService service;\n\n    public LeaveRequestController(LeaveRequestService service) {\n        this.service = service;\n    }\n\n    @PostMapping\n    public LeaveRequest create(@Valid @RequestBody CreateLeaveRequestDto dto) {\n        return service.create(dto);\n    }\n\n    @GetMapping("/pending")\n    public List<LeaveRequest> pending() {\n        return service.pending();\n    }\n\n    @PutMapping("/{id}/approve")\n    public LeaveRequest approve(@PathVariable Long id, @RequestBody DecisionDto dto) {\n        return service.approve(id, dto);\n    }\n\n    @PutMapping("/{id}/reject")\n    public LeaveRequest reject(@PathVariable Long id, @RequestBody DecisionDto dto) {\n        return service.reject(id, dto);\n    }\n}\n', 'src/main/java/com/example/leaveapp/controller/LeaveBalanceController.java': '\npackage com.example.leaveapp.controller;\n\nimport com.example.leaveapp.model.EmployeeLeaveBalance;\nimport com.example.leaveapp.repository.EmployeeLeaveBalanceRepository;\nimport org.springframework.web.bind.annotation.*;\nimport java.util.List;\n\n@RestController\n@RequestMapping("/api/leave-balances")\n@CrossOrigin(origins = "*")\npublic class LeaveBalanceController {\n    private final EmployeeLeaveBalanceRepository repository;\n\n    public LeaveBalanceController(EmployeeLeaveBalanceRepository repository) {\n        this.repository = repository;\n    }\n\n    @GetMapping\n    public List<EmployeeLeaveBalance> findAll() {\n        return repository.findAll();\n    }\n}\n', 'src/main/java/com/example/leaveapp/controller/AuditTrailController.java': '\npackage com.example.leaveapp.controller;\n\nimport com.example.leaveapp.model.AuditTrail;\nimport com.example.leaveapp.service.AuditTrailService;\nimport org.springframework.web.bind.annotation.*;\nimport java.util.List;\n\n@RestController\n@RequestMapping("/api/audit-trail")\n@CrossOrigin(origins = "*")\npublic class AuditTrailController {\n    private final AuditTrailService service;\n\n    public AuditTrailController(AuditTrailService service) {\n        this.service = service;\n    }\n\n    @GetMapping\n    public List<AuditTrail> findAll() {\n        return service.findAll();\n    }\n}\n', 'src/main/java/com/example/leaveapp/config/DemoDataLoader.java': '\npackage com.example.leaveapp.config;\n\nimport com.example.leaveapp.model.EmployeeLeaveBalance;\nimport com.example.leaveapp.repository.EmployeeLeaveBalanceRepository;\nimport org.springframework.boot.CommandLineRunner;\nimport org.springframework.stereotype.Component;\n\n@Component\npublic class DemoDataLoader implements CommandLineRunner {\n    private final EmployeeLeaveBalanceRepository repository;\n\n    public DemoDataLoader(EmployeeLeaveBalanceRepository repository) {\n        this.repository = repository;\n    }\n\n    @Override\n    public void run(String... args) {\n        repository.save(new EmployeeLeaveBalance(1L, "Employee One", 12));\n        repository.save(new EmployeeLeaveBalance(2L, "Manager One", 18));\n        repository.save(new EmployeeLeaveBalance(3L, "HR Admin", 24));\n    }\n}\n'}
TEST_FILES = {'src/test/java/com/example/leaveapp/LeaveRequestServiceTest.java': '\npackage com.example.leaveapp;\n\nimport com.example.leaveapp.dto.CreateLeaveRequestDto;\nimport com.example.leaveapp.model.LeaveRequest;\nimport com.example.leaveapp.service.LeaveRequestService;\nimport org.junit.jupiter.api.Test;\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.boot.test.context.SpringBootTest;\nimport java.time.LocalDate;\nimport static org.junit.jupiter.api.Assertions.*;\n\n@SpringBootTest\nclass LeaveRequestServiceTest {\n    @Autowired\n    private LeaveRequestService service;\n\n    @Test\n    void createsLeaveRequest() {\n        CreateLeaveRequestDto dto = new CreateLeaveRequestDto();\n        dto.setEmployeeId(1L);\n        dto.setLeaveType("VACATION");\n        dto.setStartDate(LocalDate.now().plusDays(1));\n        dto.setEndDate(LocalDate.now().plusDays(2));\n        dto.setReason("Family trip");\n\n        LeaveRequest saved = service.create(dto);\n\n        assertNotNull(saved.getId());\n        assertEquals("VACATION", saved.getLeaveType());\n        assertEquals("PENDING", saved.getStatus().name());\n    }\n}\n'}


def generate_backend_code(codebase_path: str | None, write_changes: bool) -> list[str]:
    target = resolve_target_path(codebase_path, "backEndApp")
    files_written = []

    all_files = dict(PRIMARY_FILES)
    all_files.update(TEST_FILES)

    for relative_path, content in all_files.items():
        written = write_target_file(target, relative_path, content, write_changes)
        if written:
            files_written.append(written)

    write_summary("backend_developer", target, files_written, write_changes)
    return files_written


def run_backend_developer(
    input_payload: str = "",
    input_text: str = "",
    story_instruction_path: str | None = None,
    codebase_path: str | None = None,
    write_changes: bool = False
):
    code_input = input_payload or input_text or ""
    story_text = read_optional_file(story_instruction_path)

    full_input = (
        code_input
        + "\n\n## Story Instruction Content\n"
        + story_text
        + "\n\n## Implementation Mode\n"
        + "You are a full backend code writer. Generate implementation delivery and actual code file plan."
    )

    result = run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=full_input,
        required_sections=REQUIRED_SECTIONS,
    )

    files_written = generate_backend_code(codebase_path, write_changes)

    if write_changes and not files_written:
        raise RuntimeError("Backend write_changes=True but no backend files were written.")

    result["files_written"] = files_written
    result["codebase_path"] = str(resolve_target_path(codebase_path, "backEndApp"))
    result["write_changes"] = write_changes
    result["output"] = result.get("output", "") + build_files_written_section(files_written, write_changes)
    return result
