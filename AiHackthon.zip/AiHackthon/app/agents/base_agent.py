import os
from typing import List, Optional

try:
    from utils.llm_client import ask_llm
except ImportError:
    from app.utils.llm_client import ask_llm


# File location:
# app/agents/base_agent.py
AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
PROJECT_ROOT = os.path.dirname(APP_DIR)

DATA_DIR = os.path.join(PROJECT_ROOT, "data")


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def get_prompt_search_dirs() -> list[str]:
    """
    Supports both possible project layouts:

    1. project/app/prompts/
    2. project/prompts/

    Your current project uses:
    project/app/prompts/
    """
    search_dirs = [
        os.path.join(APP_DIR, "prompts"),
        os.path.join(PROJECT_ROOT, "prompts"),
    ]

    # If config.py exists and has PROMPTS_DIR, include it also.
    try:
        from config import PROMPTS_DIR
        search_dirs.insert(0, PROMPTS_DIR)
    except Exception:
        pass

    # Remove duplicates while preserving order.
    unique_dirs = []
    for path in search_dirs:
        if path and path not in unique_dirs:
            unique_dirs.append(path)

    return unique_dirs


def find_prompt_path(prompt_file: str) -> str:
    checked_paths = []

    for prompt_dir in get_prompt_search_dirs():
        prompt_path = os.path.join(prompt_dir, prompt_file)
        checked_paths.append(prompt_path)

        if os.path.exists(prompt_path):
            return prompt_path

    raise FileNotFoundError(
        "Prompt file not found.\n"
        f"Prompt file: {prompt_file}\n"
        "Checked paths:\n"
        + "\n".join(f"- {path}" for path in checked_paths)
    )


def get_agent_dir(agent_key: str) -> str:
    """
    All files for one agent are saved only inside:

    data/<agent_key>/

    No duplicate files directly under data/.
    """
    agent_dir = os.path.join(DATA_DIR, agent_key)
    ensure_dir(agent_dir)
    return agent_dir


def read_prompt(prompt_file: str) -> str:
    prompt_path = find_prompt_path(prompt_file)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def write_agent_file(agent_key: str, file_name: str, content: str) -> str:
    """
    Writes only inside data/<agent_key>/.
    """
    agent_dir = get_agent_dir(agent_key)
    file_path = os.path.join(agent_dir, file_name)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content or "")

    return file_path


def validate_required_sections(output: str, required_sections: Optional[List[str]]) -> list[str]:
    if not required_sections:
        return []

    missing = []

    for section in required_sections:
        if section not in output:
            missing.append(section)

    return missing


def run_agent(
    agent_key: str,
    prompt_file: str,
    input_payload: str,
    required_sections: Optional[List[str]] = None,
    max_retries: int = 1,
):
    """
    Generic agent runner.

    Saves files only here:
    data/<agent_key>/input.txt
    data/<agent_key>/output.md
    data/<agent_key>/retry_input_1.txt

    Does NOT write duplicate files directly under data/.
    """
    system_prompt = read_prompt(prompt_file)

    input_file = write_agent_file(agent_key, "input.txt", input_payload)
    output = ask_llm(system_prompt, input_payload)

    missing_sections = validate_required_sections(output, required_sections)
    retry_count = 0

    while missing_sections and retry_count < max_retries:
        retry_count += 1

        retry_payload = (
            input_payload
            + "\n\n"
            + "The previous response was missing these required sections:\n"
            + "\n".join(f"- {section}" for section in missing_sections)
            + "\n\nPlease regenerate the response using all required sections exactly."
        )

        write_agent_file(agent_key, f"retry_input_{retry_count}.txt", retry_payload)
        output = ask_llm(system_prompt, retry_payload)
        missing_sections = validate_required_sections(output, required_sections)

    output_file = write_agent_file(agent_key, "output.md", output)

    return {
        "agent": agent_key,
        "status": "success" if not missing_sections else "section_validation_failed",
        "input_file": input_file,
        "output_file": output_file,
        "output": output,
        "missing_sections": missing_sections,
        "retry_count": retry_count,
    }


# Backward-compatible alias if any old agent imports run_generic_agent.
def run_generic_agent(agent_key: str, prompt_file: str, input_payload: str):
    return run_agent(
        agent_key=agent_key,
        prompt_file=prompt_file,
        input_payload=input_payload,
        required_sections=None,
    )
