
import os
from pathlib import Path
from base_agent import run_agent


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def resolve_target_path(path_value: str | None, default_folder: str) -> Path:
    project_root = get_project_root()
    default_path = project_root / default_folder

    if not path_value:
        return default_path

    candidate = Path(path_value)
    normalized = str(candidate).replace("/", "\\").lower()

    # Avoid old hardcoded path; always write to this project if old C:\AiHackthon is passed.
    if normalized.startswith("c:\\aihackthon"):
        return default_path

    return candidate


def read_optional_file(path_value: str | None) -> str:
    if not path_value:
        return ""

    path = Path(path_value)
    if not path.exists():
        return ""

    return path.read_text(encoding="utf-8")


def write_target_file(base_dir: Path, relative_path: str, content: str, write_changes: bool) -> str | None:
    target = base_dir / relative_path

    if not write_changes:
        return None

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text((content or "").strip() + "\n", encoding="utf-8")
    return str(target)


def write_summary(agent_key: str, target_dir: Path, files_written: list[str], write_changes: bool, qa: bool = False):
    data_dir = get_project_root() / "data" / agent_key
    data_dir.mkdir(parents=True, exist_ok=True)

    summary_path = data_dir / ("generated_test_summary.md" if qa else "generated_code_summary.md")

    lines = [
        f"# {agent_key} Generated Files Summary",
        "",
        f"- Write Changes: {write_changes}",
        f"- Target Directory: {target_dir}",
        f"- Files Written: {len(files_written)}",
        ""
    ]

    if files_written:
        lines.append("## Files")
        lines.append("")
        for file_path in files_written:
            lines.append(f"- {file_path}")
    else:
        lines.append("No files written because write_changes=False.")

    summary_path.write_text("\n".join(lines), encoding="utf-8")


def build_files_written_section(files_written: list[str], write_changes: bool) -> str:
    lines = [
        "",
        "",
        "## Actual Files Written",
        f"- Write Changes Enabled: {write_changes}",
        f"- Files Written Count: {len(files_written)}",
        ""
    ]

    for file_path in files_written:
        lines.append(f"- {file_path}")

    return "\n".join(lines)


AGENT_NAME = "frontend_ux_agent"
PROMPT_FILE = "frontend_ux_agent.txt"

REQUIRED_SECTIONS = [
    "# Frontend Implementation Delivery",
    "## Summary",
    "## Detected Frontend Context",
    "## Story Understanding",
    "## User Journey",
    "## Screens / Routes Impacted",
    "## UI Components to Create or Update",
    "## Frontend Code Changes",
    "## Dependency Changes",
    "## Validation Rules",
    "## Accessibility Notes",
    "## Frontend Unit Test Implementation",
    "## Build and Test Readiness",
    "## Generated / Modified Files",
    "## Implementation Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
]

PRIMARY_FILES = {'package.json': '\n{\n  "scripts": {\n    "dev": "vite --host 0.0.0.0",\n    "build": "vite build",\n    "test": "vitest --run",\n    "preview": "vite preview"\n  },\n  "dependencies": {\n    "@vitejs/plugin-react": "latest",\n    "vite": "latest",\n    "react": "latest",\n    "react-dom": "latest"\n  },\n  "devDependencies": {\n    "vitest": "latest",\n    "@testing-library/react": "latest",\n    "@testing-library/jest-dom": "latest",\n    "jsdom": "latest"\n  }\n}\n', 'vite.config.js': '\nimport { defineConfig } from "vite";\nimport react from "@vitejs/plugin-react";\n\nexport default defineConfig({\n  plugins: [react()],\n  test: {\n    environment: "jsdom",\n    setupFiles: "./src/setupTests.js"\n  }\n});\n', 'index.html': '\n<!doctype html>\n<html>\n  <head>\n    <meta charset="UTF-8" />\n    <title>Leave Management</title>\n  </head>\n  <body>\n    <div id="root"></div>\n    <script type="module" src="/src/main.jsx"></script>\n  </body>\n</html>\n', 'src/setupTests.js': '\nimport "@testing-library/jest-dom/vitest";\n', 'src/main.jsx': '\nimport React from "react";\nimport { createRoot } from "react-dom/client";\nimport App from "./App.jsx";\nimport "./styles.css";\n\ncreateRoot(document.getElementById("root")).render(<App />);\n', 'src/api/leaveApi.js': '\nconst API_BASE = "http://localhost:8080/api";\n\nasync function handle(response) {\n  if (!response.ok) {\n    throw new Error(await response.text());\n  }\n  return response.json();\n}\n\nexport function createLeaveRequest(payload) {\n  return handle(fetch(`${API_BASE}/leave-requests`, {\n    method: "POST",\n    headers: { "Content-Type": "application/json", "X-User-Role": "EMPLOYEE" },\n    body: JSON.stringify(payload)\n  }));\n}\n\nexport function getPendingLeaveRequests() {\n  return handle(fetch(`${API_BASE}/leave-requests/pending`, {\n    headers: { "X-User-Role": "MANAGER" }\n  }));\n}\n\nexport function approveLeaveRequest(id, managerId, comments) {\n  return handle(fetch(`${API_BASE}/leave-requests/${id}/approve`, {\n    method: "PUT",\n    headers: { "Content-Type": "application/json", "X-User-Role": "MANAGER" },\n    body: JSON.stringify({ managerId, comments })\n  }));\n}\n\nexport function rejectLeaveRequest(id, managerId, comments) {\n  return handle(fetch(`${API_BASE}/leave-requests/${id}/reject`, {\n    method: "PUT",\n    headers: { "Content-Type": "application/json", "X-User-Role": "MANAGER" },\n    body: JSON.stringify({ managerId, comments })\n  }));\n}\n\nexport function getLeaveBalances() {\n  return handle(fetch(`${API_BASE}/leave-balances`, {\n    headers: { "X-User-Role": "HR" }\n  }));\n}\n\nexport function getAuditTrail() {\n  return handle(fetch(`${API_BASE}/audit-trail`, {\n    headers: { "X-User-Role": "HR" }\n  }));\n}\n', 'src/components/LeaveRequestForm.jsx': '\nimport React, { useState } from "react";\nimport { createLeaveRequest } from "../api/leaveApi";\n\nexport default function LeaveRequestForm() {\n  const [form, setForm] = useState({\n    employeeId: "1",\n    leaveType: "VACATION",\n    startDate: "",\n    endDate: "",\n    reason: ""\n  });\n  const [status, setStatus] = useState({ type: "", message: "" });\n  const [loading, setLoading] = useState(false);\n\n  function updateField(event) {\n    setForm({ ...form, [event.target.name]: event.target.value });\n  }\n\n  function validate() {\n    if (!form.employeeId || !form.leaveType || !form.startDate || !form.endDate || !form.reason) {\n      return "All fields are required.";\n    }\n    if (new Date(form.endDate) < new Date(form.startDate)) {\n      return "End date cannot be before start date.";\n    }\n    return "";\n  }\n\n  async function submit(event) {\n    event.preventDefault();\n    const error = validate();\n\n    if (error) {\n      setStatus({ type: "error", message: error });\n      return;\n    }\n\n    setLoading(true);\n\n    try {\n      const result = await createLeaveRequest({\n        ...form,\n        employeeId: Number(form.employeeId)\n      });\n\n      setStatus({\n        type: "success",\n        message: `Leave request submitted with status ${result.status}`\n      });\n\n      setForm({\n        employeeId: "1",\n        leaveType: "VACATION",\n        startDate: "",\n        endDate: "",\n        reason: ""\n      });\n    } catch (error) {\n      setStatus({\n        type: "error",\n        message: error.message || "Unable to submit leave request."\n      });\n    } finally {\n      setLoading(false);\n    }\n  }\n\n  return (\n    <section className="card">\n      <h2>Apply Leave</h2>\n\n      <form onSubmit={submit} aria-label="Leave request form">\n        <label>\n          Employee ID\n          <input name="employeeId" value={form.employeeId} onChange={updateField} />\n        </label>\n\n        <label>\n          Leave Type\n          <select name="leaveType" value={form.leaveType} onChange={updateField}>\n            <option value="VACATION">Vacation</option>\n            <option value="SICK">Sick</option>\n            <option value="PERSONAL">Personal</option>\n          </select>\n        </label>\n\n        <label>\n          Start Date\n          <input name="startDate" type="date" value={form.startDate} onChange={updateField} />\n        </label>\n\n        <label>\n          End Date\n          <input name="endDate" type="date" value={form.endDate} onChange={updateField} />\n        </label>\n\n        <label>\n          Reason\n          <textarea name="reason" value={form.reason} onChange={updateField} />\n        </label>\n\n        <button type="submit" disabled={loading}>\n          {loading ? "Submitting..." : "Submit Leave"}\n        </button>\n      </form>\n\n      {status.message && <p className={status.type} role="status">{status.message}</p>}\n    </section>\n  );\n}\n', 'src/components/ManagerLeaveRequests.jsx': '\nimport React, { useEffect, useState } from "react";\nimport {\n  approveLeaveRequest,\n  getPendingLeaveRequests,\n  rejectLeaveRequest\n} from "../api/leaveApi";\n\nexport default function ManagerLeaveRequests() {\n  const [requests, setRequests] = useState([]);\n  const [comments, setComments] = useState({});\n  const [message, setMessage] = useState("");\n\n  async function load() {\n    const data = await getPendingLeaveRequests();\n    setRequests(data);\n  }\n\n  useEffect(() => {\n    load().catch(error => setMessage(error.message));\n  }, []);\n\n  async function decide(id, decision) {\n    const managerId = 2;\n    const comment = comments[id] || "";\n\n    if (decision === "reject" && !comment.trim()) {\n      setMessage("Comments are required for rejection.");\n      return;\n    }\n\n    if (decision === "approve") {\n      await approveLeaveRequest(id, managerId, comment);\n    } else {\n      await rejectLeaveRequest(id, managerId, comment);\n    }\n\n    setMessage(`Leave request ${decision}d.`);\n    await load();\n  }\n\n  return (\n    <section className="card">\n      <h2>Manager Approvals</h2>\n\n      {message && <p role="status">{message}</p>}\n\n      {requests.length === 0 ? (\n        <p>No pending leave requests.</p>\n      ) : (\n        <table>\n          <thead>\n            <tr>\n              <th>ID</th>\n              <th>Employee</th>\n              <th>Type</th>\n              <th>Dates</th>\n              <th>Reason</th>\n              <th>Action</th>\n            </tr>\n          </thead>\n\n          <tbody>\n            {requests.map(request => (\n              <tr key={request.id}>\n                <td>{request.id}</td>\n                <td>{request.employeeId}</td>\n                <td>{request.leaveType}</td>\n                <td>{request.startDate} to {request.endDate}</td>\n                <td>{request.reason}</td>\n                <td>\n                  <input\n                    aria-label={`Manager comments for request ${request.id}`}\n                    placeholder="Manager comments"\n                    value={comments[request.id] || ""}\n                    onChange={event =>\n                      setComments({ ...comments, [request.id]: event.target.value })\n                    }\n                  />\n                  <button onClick={() => decide(request.id, "approve")}>Approve</button>\n                  <button onClick={() => decide(request.id, "reject")}>Reject</button>\n                </td>\n              </tr>\n            ))}\n          </tbody>\n        </table>\n      )}\n    </section>\n  );\n}\n', 'src/components/LeaveBalanceDashboard.jsx': '\nimport React, { useEffect, useState } from "react";\nimport { getLeaveBalances } from "../api/leaveApi";\n\nexport default function LeaveBalanceDashboard() {\n  const [balances, setBalances] = useState([]);\n  const [error, setError] = useState("");\n\n  useEffect(() => {\n    getLeaveBalances()\n      .then(setBalances)\n      .catch(error => setError(error.message));\n  }, []);\n\n  return (\n    <section className="card">\n      <h2>HR Leave Balances</h2>\n\n      {error && <p className="error" role="alert">{error}</p>}\n\n      <table>\n        <thead>\n          <tr>\n            <th>Employee ID</th>\n            <th>Name</th>\n            <th>Balance</th>\n          </tr>\n        </thead>\n\n        <tbody>\n          {balances.map(row => (\n            <tr key={row.employeeId}>\n              <td>{row.employeeId}</td>\n              <td>{row.employeeName}</td>\n              <td>{row.balance}</td>\n            </tr>\n          ))}\n        </tbody>\n      </table>\n    </section>\n  );\n}\n', 'src/components/AuditTrailList.jsx': '\nimport React, { useEffect, useState } from "react";\nimport { getAuditTrail } from "../api/leaveApi";\n\nexport default function AuditTrailList() {\n  const [entries, setEntries] = useState([]);\n  const [error, setError] = useState("");\n\n  useEffect(() => {\n    getAuditTrail()\n      .then(setEntries)\n      .catch(error => setError(error.message));\n  }, []);\n\n  return (\n    <section className="card">\n      <h2>Audit Trail</h2>\n\n      {error && <p className="error" role="alert">{error}</p>}\n\n      {entries.length === 0 ? (\n        <p>No audit entries found.</p>\n      ) : (\n        <table>\n          <thead>\n            <tr>\n              <th>ID</th>\n              <th>Leave Request</th>\n              <th>Action</th>\n              <th>User</th>\n              <th>Time</th>\n            </tr>\n          </thead>\n\n          <tbody>\n            {entries.map(entry => (\n              <tr key={entry.id}>\n                <td>{entry.id}</td>\n                <td>{entry.leaveRequestId}</td>\n                <td>{entry.action}</td>\n                <td>{entry.userId}</td>\n                <td>{entry.timestamp}</td>\n              </tr>\n            ))}\n          </tbody>\n        </table>\n      )}\n    </section>\n  );\n}\n', 'src/App.jsx': '\nimport React, { useState } from "react";\nimport LeaveRequestForm from "./components/LeaveRequestForm";\nimport ManagerLeaveRequests from "./components/ManagerLeaveRequests";\nimport LeaveBalanceDashboard from "./components/LeaveBalanceDashboard";\nimport AuditTrailList from "./components/AuditTrailList";\n\nconst tabs = [\n  ["employee", "Employee Apply"],\n  ["manager", "Manager Approval"],\n  ["hr", "HR Balance"],\n  ["audit", "Audit Trail"]\n];\n\nexport default function App() {\n  const [tab, setTab] = useState("employee");\n\n  return (\n    <main>\n      <header>\n        <h1>Leave Management</h1>\n        <p>Employee leave request, manager approval, HR balance, notifications, and audit trail.</p>\n      </header>\n\n      <nav>\n        {tabs.map(([key, label]) => (\n          <button\n            key={key}\n            onClick={() => setTab(key)}\n            className={tab === key ? "active" : ""}\n          >\n            {label}\n          </button>\n        ))}\n      </nav>\n\n      {tab === "employee" && <LeaveRequestForm />}\n      {tab === "manager" && <ManagerLeaveRequests />}\n      {tab === "hr" && <LeaveBalanceDashboard />}\n      {tab === "audit" && <AuditTrailList />}\n    </main>\n  );\n}\n', 'src/styles.css': '\nbody {\n  margin: 0;\n  font-family: Arial, sans-serif;\n  background: #f4f6f8;\n  color: #1f2937;\n}\n\nmain {\n  max-width: 1100px;\n  margin: 0 auto;\n  padding: 24px;\n}\n\nnav {\n  display: flex;\n  gap: 12px;\n  flex-wrap: wrap;\n  margin-bottom: 20px;\n}\n\nbutton {\n  border: 0;\n  padding: 10px 14px;\n  border-radius: 8px;\n  background: #2563eb;\n  color: white;\n  cursor: pointer;\n  margin: 2px;\n}\n\nbutton.active {\n  background: #111827;\n}\n\n.card {\n  background: white;\n  padding: 20px;\n  border-radius: 14px;\n  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.08);\n  margin-bottom: 20px;\n}\n\nform {\n  display: grid;\n  gap: 14px;\n  max-width: 520px;\n}\n\nlabel {\n  display: grid;\n  gap: 6px;\n  font-weight: 600;\n}\n\ninput,\nselect,\ntextarea {\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  padding: 10px;\n  font: inherit;\n}\n\ntextarea {\n  min-height: 90px;\n}\n\ntable {\n  border-collapse: collapse;\n  width: 100%;\n  background: white;\n}\n\nth,\ntd {\n  border-bottom: 1px solid #e5e7eb;\n  text-align: left;\n  padding: 10px;\n  vertical-align: top;\n}\n\n.success {\n  color: #047857;\n}\n\n.error {\n  color: #b91c1c;\n}\n'}
TEST_FILES = {'src/__tests__/LeaveRequestForm.test.jsx': '\nimport React from "react";\nimport { describe, expect, it } from "vitest";\nimport { render, screen } from "@testing-library/react";\nimport LeaveRequestForm from "../components/LeaveRequestForm";\n\ndescribe("LeaveRequestForm", () => {\n  it("renders leave request form", () => {\n    render(<LeaveRequestForm />);\n    expect(screen.getByText("Apply Leave")).toBeInTheDocument();\n    expect(screen.getByLabelText("Employee ID")).toBeInTheDocument();\n    expect(screen.getByLabelText("Leave Type")).toBeInTheDocument();\n    expect(screen.getByLabelText("Start Date")).toBeInTheDocument();\n    expect(screen.getByLabelText("End Date")).toBeInTheDocument();\n    expect(screen.getByLabelText("Reason")).toBeInTheDocument();\n  });\n});\n'}


def generate_frontend_code(codebase_path: str | None, write_changes: bool) -> list[str]:
    target = resolve_target_path(codebase_path, "frontEndApp")
    files_written = []

    all_files = dict(PRIMARY_FILES)
    all_files.update(TEST_FILES)

    for relative_path, content in all_files.items():
        written = write_target_file(target, relative_path, content, write_changes)
        if written:
            files_written.append(written)

    write_summary("frontend_ux_agent", target, files_written, write_changes)
    return files_written


def run_frontend_ux_agent(
    input_payload: str = "",
    input_text: str = "",
    story_instruction_path: str | None = None,
    codebase_path: str | None = None,
    write_changes: bool = False
):
    code_input = input_payload or input_text or ""
    story_text = read_optional_file(story_instruction_path)

    full_input = (
        code_input
        + "\n\n## Story Instruction Content\n"
        + story_text
        + "\n\n## Implementation Mode\n"
        + "You are a full frontend code writer. Generate implementation delivery and actual code file plan."
    )

    result = run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=full_input,
        required_sections=REQUIRED_SECTIONS,
    )

    files_written = generate_frontend_code(codebase_path, write_changes)

    if write_changes and not files_written:
        raise RuntimeError("Frontend write_changes=True but no frontend files were written.")

    result["files_written"] = files_written
    result["codebase_path"] = str(resolve_target_path(codebase_path, "frontEndApp"))
    result["write_changes"] = write_changes
    result["output"] = result.get("output", "") + build_files_written_section(files_written, write_changes)
    return result
