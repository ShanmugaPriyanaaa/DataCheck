from base_agent import run_agent

AGENT_NAME = "product_owner"
PROMPT_FILE = "product_owner.txt"

REQUIRED_SECTIONS = [
    "# Product Scope Recommendation",
    "## Summary",
    "## MVP Scope",
    "## Future Scope",
    "## Priority Order",
    "## Sprint Grouping",
    "## Business Value Summary",
    "## Release Recommendation",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions"
]


def run_product_owner(input_payload: str):
    return run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )
