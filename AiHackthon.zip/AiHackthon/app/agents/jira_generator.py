import os
import re
from datetime import datetime
from base_agent import run_agent

AGENT_NAME = "jira_generator"
PROMPT_FILE = "jira_generator.txt"

REQUIRED_SECTIONS = [
    "# Jira Delivery Breakdown",
    "## Summary",
    "## Epics",
    "## User Stories",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
]


def get_project_root() -> str:
    """
    Supports:
    1. project/app/agents/jira_generator.py
    2. project/agents/jira_generator.py
    """
    agents_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(agents_dir)

    if os.path.basename(app_dir).lower() == "app":
        return os.path.dirname(app_dir)

    return app_dir


def get_story_output_dir() -> str:
    story_dir = os.path.join(get_project_root(), "data", AGENT_NAME)
    os.makedirs(story_dir, exist_ok=True)
    return story_dir


def sanitize_filename(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value[:80] or "story"


def extract_section(input_text: str, section_name: str) -> str:
    pattern = rf"## {re.escape(section_name)}\n(.*?)(?=\n\n## |\Z)"
    match = re.search(pattern, input_text or "", flags=re.DOTALL)
    return match.group(1).strip() if match else ""


def extract_confirmed_stack(input_payload: str) -> str:
    stack = extract_section(input_payload, "Confirmed Technology Stack")
    if stack:
        return stack

    arch = extract_section(input_payload, "Technical Architecture")
    if "Recommended Stack for Confirmation:" in arch:
        return arch.split("Recommended Stack for Confirmation:", 1)[1].strip()

    return "No confirmed technology stack found in input. Use architecture output and story context carefully."


def extract_confirmed_scope_preview(input_payload: str) -> str:
    return extract_section(input_payload, "Confirmed Jira Scope Preview")


def extract_user_scope_corrections(input_payload: str) -> str:
    return extract_section(input_payload, "User Scope Corrections Applied")


def has_login_requirement(scope_preview: str, corrections: str, full_input: str = "") -> bool:
    text = "\n".join([scope_preview or "", corrections or "", full_input or ""]).lower()

    return any(token in text for token in [
        "/login",
        "login module",
        "login page",
        "first page",
        "sign in",
        "signin",
        "authentication",
        "role based access",
        "role-based access",
        "auth/login",
        "api/auth",
    ])


def output_has_login_story(output: str) -> bool:
    text = (output or "").lower()

    return any(token in text for token in [
        "story title: login",
        "login module",
        "/login",
        "authcontroller",
        "post /api/auth/login",
        "authentication",
        "role based access",
        "role-based access",
    ])


def indent_stack(stack: str) -> str:
    lines = []

    for line in (stack or "").splitlines():
        if line.strip():
            lines.append(f"  {line}")

    return "\n".join(lines) if lines else "  - Stack not found"


def build_login_story_block(confirmed_stack: str) -> str:
    return f"""
### Epic: Authentication and Role-Based Access

#### Story Title: Login Module as First Page

- **Story ID:** STORY-AUTH-001
- **Description:** As a user, I want the application to open with a login page first, so that employees, managers, and HR users access only the screens allowed for their role.
- **Business Value:** Ensures controlled access, improves security, and routes each user to the correct workflow.
- **Priority:** Highest
- **Story Points:** 5
- **Dependencies:** None

- **Confirmed Technology Stack for This Story:**
{indent_stack(confirmed_stack)}

- **Acceptance Criteria:**
  - AC1: The first screen of the application is `/login`.
  - AC2: Users can login using username and password.
  - AC3: Employee role can access Employee Apply page.
  - AC4: Manager role can access Manager Approval page.
  - AC5: HR role can access HR Balance and Audit Trail pages.
  - AC6: Logout clears the session and returns the user to `/login`.
  - AC7: Unauthorized users cannot access role-restricted pages.

- **Frontend Implementation Instructions:**
  - Screens/routes to create or update:
    - /login - First page of the application.
    - Role-based landing route after login.
  - Components to create or update:
    - LoginPage
    - AuthGuard / role-based navigation logic
    - App routing/navigation update
  - UI behavior:
    - Display username and password fields.
    - Display validation and login failure messages.
    - Store logged-in user details in local state/localStorage for demo.
    - Show only role-allowed tabs after login.
  - Form/input validation:
    - Username is required.
    - Password is required.
  - API integration expected:
    - POST /api/auth/login
    - POST /api/auth/logout
    - GET /api/auth/me
  - Frontend files likely impacted:
    - CREATE: src/components/LoginPage.jsx
    - CREATE: src/api/authApi.js
    - UPDATE: src/App.jsx
    - UPDATE: src/styles.css
  - Frontend dependencies:
    - No new frontend dependency expected.
  - Frontend unit tests:
    - src/__tests__/LoginPage.test.jsx
    - src/__tests__/RoleBasedNavigation.test.jsx

- **Backend Implementation Instructions:**
  - APIs/endpoints to create or update:
    - POST /api/auth/login - Authenticate user.
    - POST /api/auth/logout - Logout user.
    - GET /api/auth/me - Get current user.
  - Request/response expectations:
    - Login request: username, password.
    - Login response: userId, username, displayName, role.
  - Backend components to create or update:
    - Controller: AuthController
    - DTO: LoginRequestDto
    - DTO: LoginResponseDto
    - Service: AuthService if needed
    - Entity/Model: User, Role if persistence is required
  - Business rules:
    - Employee, Manager, and HR roles must be supported.
    - Invalid credentials must return an error.
  - Validation rules:
    - Username and password are required.
  - Persistence/data changes:
    - CREATE/UPDATE: User and Role model if persistent authentication is included.
    - For local demo, in-memory demo users are acceptable.
  - Event/integration changes:
    - UserLoggedIn event optional.
    - UserLoggedOut event optional.
  - Backend files likely impacted:
    - CREATE: src/main/java/com/example/leaveapp/controller/AuthController.java
    - CREATE: src/main/java/com/example/leaveapp/dto/LoginRequestDto.java
    - CREATE: src/main/java/com/example/leaveapp/dto/LoginResponseDto.java
  - Backend dependencies:
    - No new backend dependency expected for demo login.
  - Backend unit tests:
    - src/test/java/com/example/leaveapp/controller/AuthControllerTest.java

- **QA Implementation Instructions:**
  - Functional tests:
    - Verify login page is shown first.
    - Verify employee login shows Employee Apply only.
    - Verify manager login shows Manager Approval only.
    - Verify HR login shows HR Balance and Audit Trail.
    - Verify logout returns to login page.
  - Negative tests:
    - Invalid credentials fail.
    - Empty username/password fails.
  - Edge case tests:
    - Refresh after login keeps user session for demo.
  - API tests:
    - POST /api/auth/login valid and invalid.
    - GET /api/auth/me.
    - POST /api/auth/logout.
  - UI tests:
    - Login form render and role-based navigation.
  - Integration/regression tests:
    - Existing leave workflows still work after login.
  - Test data/mocks:
    - employee/password, manager/password, hr/password.
  - QA files likely impacted:
    - CREATE: qa/playwright/login-role-flow.spec.js
    - UPDATE: qa/postman/leave-management-api.postman_collection.json

- **Code Review Instructions:**
  - Review frontend code for:
    - Role-based navigation, login error handling, logout behavior.
  - Review backend code for:
    - Auth API structure, DTO validation, role handling.
  - Review tests for:
    - Login success, login failure, and role-specific navigation.
  - Check maintainability, naming, duplication, error handling, and performance.

- **Security Instructions:**
  - Authentication/authorization checks:
    - Verify role-based access controls.
  - Input validation/security checks:
    - Validate login input.
  - Data privacy checks:
    - Do not expose password in responses or logs.
  - OWASP risks to consider:
    - Broken Authentication.
    - Broken Access Control.
    - Sensitive Data Exposure.

- **Build and Test Commands:**
  - Frontend:
    - npm install
    - npm test
    - npm run build
  - Backend:
    - mvn test
    - mvn package
  - QA:
    - Playwright test and Postman collection run.

- **Definition of Done:**
  - Login is the first page.
  - Role-based navigation works.
  - Auth APIs are implemented.
  - Frontend tests are added.
  - Backend tests are added.
  - QA tests are added.
  - Build/test commands pass or failures are reported clearly.
  - Code review completed.
  - Security review completed.
  - Acceptance criteria satisfied.
"""


def ensure_scope_alignment(output: str, confirmed_stack: str, scope_preview: str, corrections: str, input_payload: str) -> str:
    """
    Safety net:
    If the confirmed scope or correction mentions login/auth, but the LLM missed it,
    inject Login Module as the first Jira story.
    """
    output = output or ""

    if has_login_requirement(scope_preview, corrections, input_payload) and not output_has_login_story(output):
        login_story = build_login_story_block(confirmed_stack)

        if "## User Stories" in output:
            output = output.replace("## User Stories", "## User Stories\n" + login_story, 1)
        else:
            output += "\n\n## User Stories\n" + login_story

        if "## Assumptions" in output:
            output = output.replace(
                "## Assumptions",
                "## Assumptions\n- Login module was added as first story because it was present in the confirmed scope preview or user corrections.",
                1,
            )
        else:
            output += "\n\n## Assumptions\n- Login module was added as first story because it was present in the confirmed scope preview or user corrections."

    return output


def extract_story_title(story_text: str, story_number: int) -> str:
    match = re.search(r"#### Story Title:\s*(.+)", story_text)
    if match:
        return match.group(1).strip()

    match = re.search(r"- \*\*Story ID:\*\*\s*(.+)", story_text)
    if match:
        return match.group(1).strip()

    return f"Story {story_number:03d}"


def extract_story_id(story_text: str, story_number: int) -> str:
    match = re.search(r"- \*\*Story ID:\*\*\s*(.+)", story_text)
    if match:
        return match.group(1).strip()

    return f"STORY-{story_number:03d}"


def split_story_blocks(output: str) -> list[str]:
    if not output or not output.strip():
        return []

    parts = re.split(r"\n#### Story Title:", output)

    if len(parts) <= 1:
        return [output.strip()]

    common_context = parts[0].strip()
    stories = []

    for block in parts[1:]:
        story_text = "#### Story Title:" + block.strip()
        full_story_text = common_context + "\n\n" + story_text
        stories.append(full_story_text.strip())

    return stories


def clean_old_story_instruction_files(story_dir: str):
    for filename in os.listdir(story_dir):
        if filename.startswith("story_") and filename.endswith("_instruction.md"):
            try:
                os.remove(os.path.join(story_dir, filename))
            except Exception:
                pass


def build_story_instruction_markdown(
    story_number: int,
    story_text: str,
    full_jira_output: str,
    confirmed_stack: str,
    scope_preview: str,
    corrections: str,
) -> str:
    story_id = extract_story_id(story_text, story_number)
    story_title = extract_story_title(story_text, story_number)

    return f"""# Story {story_number:03d} Development Instruction

## Story Metadata
- **Story Number:** {story_number:03d}
- **Story ID:** {story_id}
- **Story Title:** {story_title}
- **Generated At UTC:** {datetime.utcnow().isoformat()}

## Confirmed Technology Stack
{confirmed_stack}

## Confirmed Jira Scope Preview
{scope_preview or "No confirmed scope preview provided."}

## User Scope Corrections Applied
{corrections or "No user scope corrections were provided."}

## Purpose
This markdown file is the execution instruction for the implementation and validation agents.

The orchestrator must pass this file to:
- Frontend Implementation Agent
- Backend Implementation Agent
- QA Implementation Agent
- Code Review Agent
- Security Agent

Each implementation agent must focus only on this story and must satisfy the acceptance criteria listed below.

## Story Content
{story_text}

## Full Jira Context
The story above was generated from the complete Jira delivery breakdown. Downstream agents should use the story content as the main execution scope and use the full Jira context only when additional clarification is needed.

<details>
<summary>Full Jira Delivery Breakdown</summary>

{full_jira_output}

</details>

## Execution Rules for Implementation Agents

### Frontend Agent Responsibility
- Read this story instruction fully.
- Use the confirmed frontend technology, build tool, and test framework.
- Create or update frontend source code required for this story.
- Create or update frontend unit/component tests.
- Add required frontend dependencies if needed.
- Implement screens, routes, UI components, form validation, state handling, role-based navigation, and API integration required for this story.
- Ensure frontend behavior satisfies the acceptance criteria.
- Report generated files, modified files, dependency changes, build/test status, risks, and open questions.

### Backend Agent Responsibility
- Read this story instruction fully.
- Use the confirmed backend technology, database, build tool, API style, and test framework.
- Create or update backend source code required for this story.
- Create or update backend unit tests.
- Add required backend dependencies if needed.
- Implement APIs, controllers, services, repositories, models/entities, DTOs, validators, integrations, events, authentication/authorization if required, and error handling required for this story.
- Ensure backend behavior satisfies the acceptance criteria.
- Report generated files, modified files, dependency changes, build/test status, risks, and open questions.

### QA Agent Responsibility
- Read this story instruction fully.
- Use the confirmed QA automation and testing tools.
- Create or update QA automation required for this story.
- Map every acceptance criterion to test coverage.
- Create or update API tests, UI tests, integration tests, regression tests, mocks, and test data where applicable.
- Report generated test files, modified files, dependency changes, coverage gaps, execution status, risks, and open questions.

### Code Review Agent Responsibility
- Review frontend, backend, and QA changes for this story.
- Check maintainability, readability, duplication, naming, error handling, performance, dependency usage, and test quality.
- Report code smells, refactoring suggestions, quality risks, and required improvements.

### Security Agent Responsibility
- Review frontend, backend, and QA changes for this story.
- Check authentication, authorization, input validation, output encoding, data privacy, error leakage, OWASP risks, dependency risks, and secure coding practices.
- Report security risks and mitigation actions.

## Expected Build/Test Validation
Frontend expected commands:
- npm install
- npm test
- npm run build

Backend expected commands:
- mvn test
- mvn package

QA expected commands:
- npx playwright test
- newman run <collection>

## Definition of Done for This Story
- Frontend code completed or confirmed not required.
- Backend code completed or confirmed not required.
- Required dependencies added or confirmed not required.
- Frontend unit/component tests created or updated.
- Backend unit tests created or updated.
- QA automation tests created or updated.
- Build/test checks pass or failures are clearly reported.
- Code review completed.
- Security review completed.
- Acceptance criteria satisfied or gaps clearly reported.
"""


def create_story_instruction_files(
    output: str,
    confirmed_stack: str,
    scope_preview: str,
    corrections: str,
) -> list[str]:
    story_dir = get_story_output_dir()
    clean_old_story_instruction_files(story_dir)

    story_blocks = split_story_blocks(output)
    generated_files = []

    if not story_blocks:
        return generated_files

    for index, story_text in enumerate(story_blocks, start=1):
        story_title = extract_story_title(story_text, index)
        story_slug = sanitize_filename(story_title)

        file_path = os.path.join(
            story_dir,
            f"story_{index:03d}_{story_slug}_instruction.md"
        )

        story_instruction = build_story_instruction_markdown(
            story_number=index,
            story_text=story_text,
            full_jira_output=output,
            confirmed_stack=confirmed_stack,
            scope_preview=scope_preview,
            corrections=corrections,
        )

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(story_instruction)

        generated_files.append(file_path)

    manifest_path = os.path.join(story_dir, "story_instruction_manifest.md")

    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write("# Story Instruction Manifest\n\n")
        f.write(f"Generated At UTC: {datetime.utcnow().isoformat()}\n\n")
        f.write("## Confirmed Technology Stack\n\n")
        f.write(confirmed_stack.strip() + "\n\n")
        f.write("## Confirmed Jira Scope Preview\n\n")
        f.write((scope_preview or "No confirmed scope preview provided.").strip() + "\n\n")
        f.write("## User Scope Corrections Applied\n\n")
        f.write((corrections or "No user scope corrections were provided.").strip() + "\n\n")
        f.write("## Story Files\n\n")

        for file_path in generated_files:
            f.write(f"- {file_path}\n")

    return generated_files


def save_scope_used(scope_preview: str, corrections: str):
    story_dir = get_story_output_dir()
    scope_file = os.path.join(story_dir, "jira_scope_used.md")

    with open(scope_file, "w", encoding="utf-8") as f:
        f.write("# Jira Scope Used\n\n")
        f.write("## Confirmed Jira Scope Preview\n\n")
        f.write((scope_preview or "No confirmed scope preview provided.").strip() + "\n\n")
        f.write("## User Scope Corrections Applied\n\n")
        f.write((corrections or "No user scope corrections were provided.").strip() + "\n")


def run_jira_generator(input_payload: str):
    result = run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )

    output = result.get("output", "")
    confirmed_stack = extract_confirmed_stack(input_payload)
    scope_preview = extract_confirmed_scope_preview(input_payload)
    corrections = extract_user_scope_corrections(input_payload)

    output = ensure_scope_alignment(
        output=output,
        confirmed_stack=confirmed_stack,
        scope_preview=scope_preview,
        corrections=corrections,
        input_payload=input_payload,
    )

    save_scope_used(scope_preview, corrections)

    if output:
        result["output"] = output
        result["confirmed_technology_stack"] = confirmed_stack
        result["confirmed_jira_scope_preview"] = scope_preview
        result["user_scope_corrections_applied"] = corrections
        result["story_instruction_files"] = create_story_instruction_files(
            output=output,
            confirmed_stack=confirmed_stack,
            scope_preview=scope_preview,
            corrections=corrections,
        )

    return result
