from base_agent import run_agent

AGENT_NAME = "security_agent"
PROMPT_FILE = "security_agent.txt"

REQUIRED_SECTIONS = [
    "# Security Review Recommendation",
    "## Summary",
    "## Security Scope",
    "## Authentication and Authorization Notes",
    "## OWASP and Secure Coding Notes",
    "## Data Privacy Notes",
    "## Compliance Notes",
    "## Mitigation Plan",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions"
]


def run_security_agent(input_payload: str):
    return run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )
