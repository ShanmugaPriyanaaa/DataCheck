from base_agent import run_agent

AGENT_NAME = "requirement_analyzer"
PROMPT_FILE = "requirement_analyzer.txt"

REQUIRED_SECTIONS = [
    "# Requirement Analysis",
    "## Summary",
    "## Functional Requirements",
    "## Non-Functional Requirements",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions"
]


def run_requirement_analyzer(feature_text: str):
    return run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=feature_text,
        required_sections=REQUIRED_SECTIONS,
    )
