
import re
from pathlib import Path
from base_agent import run_agent

AGENT_NAME = "technical_architect"
PROMPT_FILE = "technical_architect.txt"

REQUIRED_SECTIONS = [
    "# Technical Architecture Recommendation",
    "## Summary",
    "## Recommended Technology Stack",
    "## Technology Stack Options Considered",
    "## Technology Selection Rationale",
    "## Architecture Style",
    "## Core Components",
    "## System Flow",
    "## System Context Diagram",
    "## Container Architecture Diagram",
    "## Application Flow Diagram",
    "## Sequence Diagram",
    "## Data Flow Diagram",
    "## Integration Considerations",
    "## Security and Scalability Notes",
    "## Technology Constraints",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
    "## Technology Decision Required",
]


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def get_diagram_dir() -> Path:
    diagram_dir = get_project_root() / "data" / "technical_architect" / "diagrams"
    diagram_dir.mkdir(parents=True, exist_ok=True)
    return diagram_dir


def extract_mermaid_blocks(output: str) -> list[str]:
    return re.findall(r"```mermaid\s*(.*?)```", output or "", flags=re.DOTALL | re.IGNORECASE)


def fallback_diagrams() -> dict[str, str]:
    return {
        "system_context_diagram.mmd": """flowchart LR
    Employee[Employee] --> Frontend[React + Vite Frontend]
    Manager[Manager] --> Frontend
    HR[HR User] --> Frontend
    Frontend --> Backend[Spring Boot REST API]
    Backend --> Database[(PostgreSQL / H2)]
    Backend --> Notification[Notification Service]
    Backend --> Audit[Audit Trail]
""",
        "container_architecture_diagram.mmd": """flowchart TB
    subgraph Frontend[Frontend - React + Vite]
        Pages[Pages]
        Components[Components]
        ApiClient[API Client]
    end

    subgraph Backend[Backend - Spring Boot]
        Controllers[REST Controllers]
        Services[Business Services]
        Repositories[JPA Repositories]
    end

    subgraph Data[Data Layer]
        H2[(H2 Local Demo)]
        Postgres[(PostgreSQL Production)]
    end

    Pages --> Components
    Components --> ApiClient
    ApiClient --> Controllers
    Controllers --> Services
    Services --> Repositories
    Repositories --> H2
    Repositories --> Postgres
""",
        "application_flow_diagram.mmd": """flowchart TD
    Start([Start])
    EmployeeForm[Employee fills leave request]
    FrontendValidation{Frontend validation ok?}
    Submit[Submit request]
    BackendValidation{Backend validation ok?}
    SavePending[Save pending leave request]
    NotifyManager[Notify manager]
    ManagerReview[Manager reviews request]
    Decision{Approve or reject?}
    Approve[Approve leave]
    Reject[Reject leave]
    UpdateBalance[Update leave balance]
    Audit[Write audit trail]
    NotifyEmployee[Notify employee]
    End([End])

    Start --> EmployeeForm --> FrontendValidation
    FrontendValidation -- No --> EmployeeForm
    FrontendValidation -- Yes --> Submit --> BackendValidation
    BackendValidation -- No --> EmployeeForm
    BackendValidation -- Yes --> SavePending --> NotifyManager --> ManagerReview --> Decision
    Decision -- Approve --> Approve --> UpdateBalance --> Audit --> NotifyEmployee --> End
    Decision -- Reject --> Reject --> Audit --> NotifyEmployee --> End
""",
        "sequence_diagram.mmd": """sequenceDiagram
    actor Employee
    participant Frontend as React Frontend
    participant Backend as Spring Boot API
    participant DB as Database
    actor Manager
    participant Audit as Audit Trail
    participant Notification as Notification Service

    Employee->>Frontend: Submit leave request
    Frontend->>Backend: POST /api/leave-requests
    Backend->>DB: Save PENDING request
    Backend->>Audit: Log SUBMITTED
    Backend->>Notification: Notify manager
    Backend-->>Frontend: Return created request
    Manager->>Frontend: Approve or reject request
    Frontend->>Backend: PUT approve/reject
    Backend->>DB: Update status and balance
    Backend->>Audit: Log decision
    Backend->>Notification: Notify employee
    Backend-->>Frontend: Return updated request
""",
        "data_flow_diagram.mmd": """flowchart LR
    Input[Employee Leave Request Input]
    FEValidation[Frontend Validation]
    API[Backend REST API]
    BEValidation[Backend Validation]
    LeaveRequest[(Leave Request Table)]
    LeaveBalance[(Leave Balance Table)]
    AuditTrail[(Audit Trail Table)]
    Notification[Notification Output]
    HRReport[HR Leave Balance View]

    Input --> FEValidation
    FEValidation --> API
    API --> BEValidation
    BEValidation --> LeaveRequest
    LeaveRequest --> LeaveBalance
    LeaveRequest --> AuditTrail
    LeaveRequest --> Notification
    LeaveBalance --> HRReport
    AuditTrail --> HRReport
""",
    }


def save_architecture_diagrams(output: str = "") -> list[str]:
    diagram_dir = get_diagram_dir()
    names = [
        "system_context_diagram.mmd",
        "container_architecture_diagram.mmd",
        "application_flow_diagram.mmd",
        "sequence_diagram.mmd",
        "data_flow_diagram.mmd",
    ]

    blocks = extract_mermaid_blocks(output)
    fallback = fallback_diagrams()
    files_written = []

    for index, name in enumerate(names):
        text = blocks[index].strip() if index < len(blocks) and blocks[index].strip() else fallback[name].strip()
        path = diagram_dir / name
        path.write_text(text + "\n", encoding="utf-8")
        files_written.append(str(path))

    md = diagram_dir / "architecture_diagrams.md"
    lines = ["# Architecture Diagrams", ""]

    for name in names:
        title = name.replace("_", " ").replace(".mmd", "").title()
        text = (diagram_dir / name).read_text(encoding="utf-8").strip()
        lines += [f"## {title}", "", "```mermaid", text, "```", ""]

    md.write_text("\n".join(lines), encoding="utf-8")
    files_written.append(str(md))

    marker = diagram_dir / "_diagram_generation_success.txt"
    marker.write_text("Technical Architect diagrams generated successfully.\n", encoding="utf-8")
    files_written.append(str(marker))

    return files_written


def build_diagram_section(files: list[str]) -> str:
    lines = ["", "", "## Generated Diagram Files", ""]
    for file in files:
        lines.append(f"- {file}")
    return "\n".join(lines)


def run_technical_architect(input_payload: str):
    result = run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )

    output = result.get("output", "") if isinstance(result, dict) else str(result)
    files = save_architecture_diagrams(output)

    if isinstance(result, dict):
        result["diagram_files"] = files
        result["output"] = output + build_diagram_section(files)
        return result

    return {
        "output": output + build_diagram_section(files),
        "diagram_files": files,
    }
