
import os
from pathlib import Path
from base_agent import run_agent


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def resolve_target_path(path_value: str | None, default_folder: str) -> Path:
    project_root = get_project_root()
    default_path = project_root / default_folder

    if not path_value:
        return default_path

    candidate = Path(path_value)
    normalized = str(candidate).replace("/", "\\").lower()

    # Avoid old hardcoded path; always write to this project if old C:\AiHackthon is passed.
    if normalized.startswith("c:\\aihackthon"):
        return default_path

    return candidate


def read_optional_file(path_value: str | None) -> str:
    if not path_value:
        return ""

    path = Path(path_value)
    if not path.exists():
        return ""

    return path.read_text(encoding="utf-8")


def write_target_file(base_dir: Path, relative_path: str, content: str, write_changes: bool) -> str | None:
    target = base_dir / relative_path

    if not write_changes:
        return None

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text((content or "").strip() + "\n", encoding="utf-8")
    return str(target)


def write_summary(agent_key: str, target_dir: Path, files_written: list[str], write_changes: bool, qa: bool = False):
    data_dir = get_project_root() / "data" / agent_key
    data_dir.mkdir(parents=True, exist_ok=True)

    summary_path = data_dir / ("generated_test_summary.md" if qa else "generated_code_summary.md")

    lines = [
        f"# {agent_key} Generated Files Summary",
        "",
        f"- Write Changes: {write_changes}",
        f"- Target Directory: {target_dir}",
        f"- Files Written: {len(files_written)}",
        ""
    ]

    if files_written:
        lines.append("## Files")
        lines.append("")
        for file_path in files_written:
            lines.append(f"- {file_path}")
    else:
        lines.append("No files written because write_changes=False.")

    summary_path.write_text("\n".join(lines), encoding="utf-8")


def build_files_written_section(files_written: list[str], write_changes: bool) -> str:
    lines = [
        "",
        "",
        "## Actual Files Written",
        f"- Write Changes Enabled: {write_changes}",
        f"- Files Written Count: {len(files_written)}",
        ""
    ]

    for file_path in files_written:
        lines.append(f"- {file_path}")

    return "\n".join(lines)


AGENT_NAME = "qa_agent"
PROMPT_FILE = "qa_agent.txt"

REQUIRED_SECTIONS = [
    "# QA Implementation Delivery",
    "## Summary",
    "## Detected Frontend Test Context",
    "## Detected Backend Test Context",
    "## Story Understanding",
    "## Acceptance Criteria Coverage",
    "## Test Scope",
    "## Functional Test Implementation",
    "## Negative Test Implementation",
    "## Edge Case Test Implementation",
    "## Frontend Test Automation",
    "## Backend Test Automation",
    "## Integration and Event Test Automation",
    "## Regression Test Implementation",
    "## Test Data and Mocking",
    "## Dependency Changes",
    "## Build and Test Execution Readiness",
    "## Generated / Modified Test Files",
    "## Coverage Gaps",
    "## Implementation Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
]

FRONTEND_TEST_FILES = {'src/__tests__/LeaveRequestForm.test.jsx': '\nimport React from "react";\nimport { describe, expect, it } from "vitest";\nimport { render, screen } from "@testing-library/react";\nimport LeaveRequestForm from "../components/LeaveRequestForm";\n\ndescribe("LeaveRequestForm", () => {\n  it("renders leave request form", () => {\n    render(<LeaveRequestForm />);\n    expect(screen.getByText("Apply Leave")).toBeInTheDocument();\n    expect(screen.getByLabelText("Employee ID")).toBeInTheDocument();\n    expect(screen.getByLabelText("Leave Type")).toBeInTheDocument();\n    expect(screen.getByLabelText("Start Date")).toBeInTheDocument();\n    expect(screen.getByLabelText("End Date")).toBeInTheDocument();\n    expect(screen.getByLabelText("Reason")).toBeInTheDocument();\n  });\n});\n'}
BACKEND_TEST_FILES = {'src/test/java/com/example/leaveapp/LeaveRequestServiceTest.java': '\npackage com.example.leaveapp;\n\nimport com.example.leaveapp.dto.CreateLeaveRequestDto;\nimport com.example.leaveapp.model.LeaveRequest;\nimport com.example.leaveapp.service.LeaveRequestService;\nimport org.junit.jupiter.api.Test;\nimport org.springframework.beans.factory.annotation.Autowired;\nimport org.springframework.boot.test.context.SpringBootTest;\nimport java.time.LocalDate;\nimport static org.junit.jupiter.api.Assertions.*;\n\n@SpringBootTest\nclass LeaveRequestServiceTest {\n    @Autowired\n    private LeaveRequestService service;\n\n    @Test\n    void createsLeaveRequest() {\n        CreateLeaveRequestDto dto = new CreateLeaveRequestDto();\n        dto.setEmployeeId(1L);\n        dto.setLeaveType("VACATION");\n        dto.setStartDate(LocalDate.now().plusDays(1));\n        dto.setEndDate(LocalDate.now().plusDays(2));\n        dto.setReason("Family trip");\n\n        LeaveRequest saved = service.create(dto);\n\n        assertNotNull(saved.getId());\n        assertEquals("VACATION", saved.getLeaveType());\n        assertEquals("PENDING", saved.getStatus().name());\n    }\n}\n'}
QA_FILES = {'playwright/leave-management.spec.js': '\nimport { test, expect } from "@playwright/test";\n\ntest("employee can open leave request page", async ({ page }) => {\n  await page.goto("http://localhost:5173");\n  await expect(page.getByText("Leave Management")).toBeVisible();\n  await expect(page.getByText("Apply Leave")).toBeVisible();\n});\n\ntest("manager and HR tabs are available", async ({ page }) => {\n  await page.goto("http://localhost:5173");\n\n  await page.getByText("Manager Approval").click();\n  await expect(page.getByText("Manager Approvals")).toBeVisible();\n\n  await page.getByText("HR Balance").click();\n  await expect(page.getByText("HR Leave Balances")).toBeVisible();\n\n  await page.getByText("Audit Trail").click();\n  await expect(page.getByText("Audit Trail")).toBeVisible();\n});\n', 'postman/leave-management-api.postman_collection.json': '\n{\n  "info": {\n    "name": "Leave Management API",\n    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"\n  },\n  "item": [\n    {\n      "name": "Create Leave Request",\n      "request": {\n        "method": "POST",\n        "header": [{ "key": "Content-Type", "value": "application/json" }],\n        "url": "http://localhost:8080/api/leave-requests",\n        "body": {\n          "mode": "raw",\n          "raw": "{\\"employeeId\\":1,\\"leaveType\\":\\"VACATION\\",\\"startDate\\":\\"2030-01-01\\",\\"endDate\\":\\"2030-01-03\\",\\"reason\\":\\"Family trip\\"}"\n        }\n      }\n    },\n    {\n      "name": "Pending Leave Requests",\n      "request": { "method": "GET", "url": "http://localhost:8080/api/leave-requests/pending" }\n    },\n    {\n      "name": "Leave Balances",\n      "request": { "method": "GET", "url": "http://localhost:8080/api/leave-balances" }\n    },\n    {\n      "name": "Audit Trail",\n      "request": { "method": "GET", "url": "http://localhost:8080/api/audit-trail" }\n    }\n  ]\n}\n', 'README.md': '\n# QA Sync Pack\n\nThis QA pack is synced with:\n\n- `frontEndApp`\n- `backEndApp`\n\n## Frontend tests\n\n```bash\ncd frontEndApp\nnpm install\nnpm test\n```\n\n## Backend tests\n\n```bash\ncd backEndApp\nmvn test\n```\n\n## Manual run\n\nBackend:\n\n```bash\ncd backEndApp\nmvn spring-boot:run\n```\n\nFrontend:\n\n```bash\ncd frontEndApp\nnpm run dev\n```\n\nOpen:\n\n```text\nhttp://localhost:5173\n```\n'}


def generate_qa_code(
    frontend_codebase_path: str | None,
    backend_codebase_path: str | None,
    write_changes: bool
) -> list[str]:
    project_root = get_project_root()
    qa_target = project_root / "qa"
    frontend_target = resolve_target_path(frontend_codebase_path, "frontEndApp")
    backend_target = resolve_target_path(backend_codebase_path, "backEndApp")

    files_written = []

    for relative_path, content in FRONTEND_TEST_FILES.items():
        written = write_target_file(frontend_target, relative_path, content, write_changes)
        if written:
            files_written.append(written)

    for relative_path, content in BACKEND_TEST_FILES.items():
        written = write_target_file(backend_target, relative_path, content, write_changes)
        if written:
            files_written.append(written)

    for relative_path, content in QA_FILES.items():
        written = write_target_file(qa_target, relative_path, content, write_changes)
        if written:
            files_written.append(written)

    write_summary("qa_agent", qa_target, files_written, write_changes, qa=True)
    return files_written


def run_qa_agent(
    input_payload: str = "",
    input_text: str = "",
    story_instruction_path: str | None = None,
    frontend_codebase_path: str | None = None,
    backend_codebase_path: str | None = None,
    write_changes: bool = False,
    run_checks: bool = False
):
    code_input = input_payload or input_text or ""
    story_text = read_optional_file(story_instruction_path)

    full_input = (
        code_input
        + "\n\n## Story Instruction Content\n"
        + story_text
        + "\n\n## Implementation Mode\n"
        + "You are a full QA code writer. Generate frontend tests, backend tests, API tests, and E2E tests."
    )

    result = run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=full_input,
        required_sections=REQUIRED_SECTIONS,
    )

    files_written = generate_qa_code(frontend_codebase_path, backend_codebase_path, write_changes)

    if write_changes and not files_written:
        raise RuntimeError("QA write_changes=True but no QA/test files were written.")

    result["files_written"] = files_written
    result["frontend_codebase_path"] = str(resolve_target_path(frontend_codebase_path, "frontEndApp"))
    result["backend_codebase_path"] = str(resolve_target_path(backend_codebase_path, "backEndApp"))
    result["write_changes"] = write_changes
    result["run_checks"] = run_checks
    result["output"] = result.get("output", "") + build_files_written_section(files_written, write_changes)
    return result
