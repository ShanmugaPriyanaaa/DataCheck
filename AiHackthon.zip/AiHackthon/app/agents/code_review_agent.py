from base_agent import run_agent

AGENT_NAME = "code_review_agent"
PROMPT_FILE = "code_review_agent.txt"

REQUIRED_SECTIONS = [
    "# Code Review Recommendation",
    "## Summary",
    "## Review Scope",
    "## Code Quality Findings",
    "## Maintainability Notes",
    "## Performance Notes",
    "## Refactoring Suggestions",
    "## Test Recommendations",
    "## Assumptions",
    "## Constraints",
    "## Risks",
    "## Open Questions"
]


def run_code_review_agent(input_payload: str):
    return run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )
