from base_agent import run_agent

AGENT_NAME = "data_event_architect"
PROMPT_FILE = "data_event_architect.txt"

REQUIRED_SECTIONS = [
    "# Data and Event Architecture Recommendation",
    "## Summary",
    "## Confirmed Technology Stack Alignment",
    "## Database Selection Notes",
    "## Core Data Entities",
    "## Relationships",
    "## ER Diagram",
    "## Physical Database Model",
    "## Data Dictionary",
    "## Sample Data Inserts",
    "## Data Lifecycle Notes",
    "## Event Model",
    "## Suggested Topics / Queues",
    "## Producers and Consumers",
    "## Reliability Considerations",
    "## Implementation Instructions for Backend Agent",
    "## Implementation Instructions for QA Agent",
    "## Assumptions",
    "## Constraints",
    "## Dependencies",
    "## Risks",
    "## Open Questions",
]


def run_data_event_architect(input_payload: str):
    """
    Data & Event Architect Agent.

    Responsibility:
    - Uses the confirmed technology stack from Technical Architect stage.
    - Finalizes database/data model/event model.
    - Generates backend-friendly and QA-friendly implementation instructions.
    """
    return run_agent(
        agent_key=AGENT_NAME,
        prompt_file=PROMPT_FILE,
        input_payload=input_payload,
        required_sections=REQUIRED_SECTIONS,
    )
