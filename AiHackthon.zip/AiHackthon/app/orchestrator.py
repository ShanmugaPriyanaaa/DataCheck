import os
import sys
import glob
import json
import inspect
from pathlib import Path
from datetime import datetime

# =============================================================================
# Path setup
# =============================================================================

CURRENT_DIR = Path(__file__).resolve().parent          # app/
PROJECT_ROOT = CURRENT_DIR.parent                     # project root
AGENTS_DIR = CURRENT_DIR / "agents"

if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

if str(AGENTS_DIR) not in sys.path:
    sys.path.insert(0, str(AGENTS_DIR))

try:
    from config import OUTPUT_DIR
except Exception:
    OUTPUT_DIR = str(PROJECT_ROOT / "data")

# =============================================================================
# Core 10 agent imports
# =============================================================================

from requirement_analyzer import run_requirement_analyzer
from product_owner import run_product_owner
from technical_architect import run_technical_architect
from data_event_architect import run_data_event_architect
from jira_generator import run_jira_generator
from frontend_ux_agent import run_frontend_ux_agent
from backend_developer import run_backend_developer
from qa_agent import run_qa_agent
from code_review_agent import run_code_review_agent
from security_agent import run_security_agent

# =============================================================================
# Build runner import
# =============================================================================

try:
    from utils.build_runner import (
        run_frontend_checks,
        run_backend_checks,
        has_failure,
        format_results,
    )
except Exception:
    run_frontend_checks = None
    run_backend_checks = None
    has_failure = None
    format_results = None


# =============================================================================
# Memory configuration
# =============================================================================

MEMORY_DIR = PROJECT_ROOT / "memory"
MEMORY_FILE = MEMORY_DIR / "file.txt"


# =============================================================================
# Generic helpers
# =============================================================================

def now_utc() -> str:
    return datetime.utcnow().isoformat()


def section(title: str, content: str) -> str:
    return f"\n\n## {title}\n{content or ''}"


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def data_dir(*parts: str) -> Path:
    return Path(OUTPUT_DIR).joinpath(*parts)


def read_text_file(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")


def save_text_file(path: str | Path, content: str) -> str:
    path = Path(path)
    ensure_dir(path.parent)
    path.write_text(content or "", encoding="utf-8")
    return str(path)


def normalize_codebase_path(path_value: str | None, default_folder: str) -> str:
    """
    Makes frontend/backend paths system-independent.

    If no path is passed:
      project_root/frontEndApp or project_root/backEndApp

    If old hardcoded C:\\AiHackthon path is passed:
      also converts to project_root/<folder>
    """
    default_path = PROJECT_ROOT / default_folder

    if not path_value:
        return str(default_path)

    candidate = Path(path_value)
    normalized = str(candidate).replace("/", "\\").lower()

    if normalized.startswith("c:\\aihackthon"):
        return str(default_path)

    return str(candidate)


def preview_output(agent_name: str, output: str, max_chars: int = 1500):
    print("\n" + "-" * 100)
    print(f"{agent_name} completed.")
    print("-" * 100)

    if not output:
        print("No output returned.")
        return

    print(output[:max_chars])

    if len(output) > max_chars:
        print("\n...output truncated in console. Full output saved in data folder.")


def confirm(agent_no: str, agent_name: str) -> bool:
    print("\n" + "=" * 100)
    print(f"Ready to run Agent {agent_no}: {agent_name}")
    print("Type YES to continue. Type anything else to stop.")
    print("=" * 100)

    value = input("Confirm: ").strip().upper()

    if value == "YES":
        print(f"Running Agent {agent_no}: {agent_name}...")
        return True

    print(f"Pipeline stopped before Agent {agent_no}: {agent_name}")
    return False


def call_with_supported_kwargs(func, *args, **kwargs):
    """
    Calls agent functions safely even if function signatures differ slightly.
    """
    signature = inspect.signature(func)
    supported = signature.parameters

    filtered_kwargs = {}

    for key, value in kwargs.items():
        if key in supported:
            filtered_kwargs[key] = value

    if args:
        return func(*args, **filtered_kwargs)

    return func(**filtered_kwargs)


def require_build_runner():
    if (
        run_frontend_checks is None
        or run_backend_checks is None
        or has_failure is None
        or format_results is None
    ):
        raise RuntimeError(
            "run_qa_checks=True but app/utils/build_runner.py could not be imported. "
            "Please confirm build_runner.py exists under app/utils and exposes "
            "run_frontend_checks, run_backend_checks, has_failure, format_results."
        )


# =============================================================================
# Memory helpers
# =============================================================================

def default_memory() -> dict:
    return {
        "version": "2.0-build-runner",
        "created_at": now_utc(),
        "updated_at": now_utc(),
        "pipeline_status": "not_started",
        "last_completed_step": None,
        "current_step": None,
        "last_error": None,
        "feature_text": "",
        "frontend_codebase_path": "",
        "backend_codebase_path": "",
        "write_changes": False,
        "run_qa_checks": False,
        "confirmed_technology_stack": "",
        "confirmed_technology_stack_file": "",
        "story_instruction_files": [],
        "outputs": {},
        "stories": {},
        "build_results": {},
    }


def load_memory() -> dict:
    if not MEMORY_FILE.exists():
        print("\nNo memory file found. Starting pipeline from Agent 1.")
        return default_memory()

    try:
        memory = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
        print("\nMemory file found. Resume mode enabled.")
        print(f"Memory file: {MEMORY_FILE}")
        print(f"Pipeline status: {memory.get('pipeline_status')}")
        print(f"Last completed step: {memory.get('last_completed_step')}")
        return memory
    except Exception as e:
        print("\nMemory file exists but could not be read.")
        print(f"Error: {e}")
        print("Starting fresh with new memory.")
        return default_memory()


def save_memory(memory: dict) -> str:
    ensure_dir(MEMORY_DIR)
    memory["updated_at"] = now_utc()
    MEMORY_FILE.write_text(json.dumps(memory, indent=2), encoding="utf-8")
    return str(MEMORY_FILE)


def mark_step_started(memory: dict, step_key: str):
    memory["pipeline_status"] = "running"
    memory["current_step"] = step_key
    memory["last_error"] = None
    save_memory(memory)


def mark_step_completed(memory: dict, step_key: str, output: str = "", extra: dict | None = None):
    memory["pipeline_status"] = "running"
    memory["last_completed_step"] = step_key
    memory["current_step"] = None
    memory["last_error"] = None

    memory.setdefault("outputs", {})
    memory["outputs"][step_key] = output or ""

    if extra:
        for key, value in extra.items():
            memory[key] = value

    save_memory(memory)
    print(f"\nMemory updated after completion: {step_key}")
    print(f"Memory file: {MEMORY_FILE}")


def mark_story_agent_completed(
    memory: dict,
    story_file: str,
    agent_key: str,
    output: str,
    files_written: list[str] | None = None,
):
    memory.setdefault("stories", {})
    story_key = os.path.basename(story_file)

    if story_key not in memory["stories"]:
        memory["stories"][story_key] = {
            "story_file": story_file,
            "completed_agents": {},
            "files_written": {},
            "updated_at": now_utc(),
        }

    memory["stories"][story_key]["completed_agents"][agent_key] = output or ""
    memory["stories"][story_key].setdefault("files_written", {})
    memory["stories"][story_key]["files_written"][agent_key] = files_written or []
    memory["stories"][story_key]["updated_at"] = now_utc()

    memory["last_completed_step"] = f"{story_key}:{agent_key}"
    memory["current_step"] = None
    memory["last_error"] = None

    save_memory(memory)

    print(f"\nMemory updated after story agent completion: {story_key} -> {agent_key}")
    print(f"Memory file: {MEMORY_FILE}")


def mark_build_result(memory: dict, story_file: str, stage: str, results: list[dict]):
    story_key = os.path.basename(story_file)
    memory.setdefault("build_results", {})
    memory["build_results"].setdefault(story_key, {})
    memory["build_results"][story_key][stage] = results
    save_memory(memory)


def mark_error(memory: dict, step_key: str, error: Exception):
    memory["pipeline_status"] = "failed"
    memory["current_step"] = step_key
    memory["last_error"] = {
        "step": step_key,
        "error_type": type(error).__name__,
        "error_message": str(error),
        "time": now_utc(),
    }
    save_memory(memory)


def has_output(memory: dict, step_key: str) -> bool:
    return bool(memory.get("outputs", {}).get(step_key))


def get_output(memory: dict, step_key: str) -> str:
    return memory.get("outputs", {}).get(step_key, "")


def story_agent_done(memory: dict, story_file: str, agent_key: str) -> bool:
    story_key = os.path.basename(story_file)
    return bool(
        memory.get("stories", {})
        .get(story_key, {})
        .get("completed_agents", {})
        .get(agent_key)
    )


def get_story_agent_output(memory: dict, story_file: str, agent_key: str) -> str:
    story_key = os.path.basename(story_file)
    return (
        memory.get("stories", {})
        .get(story_key, {})
        .get("completed_agents", {})
        .get(agent_key, "")
    )


def get_story_agent_files(memory: dict, story_file: str, agent_key: str) -> list[str]:
    story_key = os.path.basename(story_file)
    return (
        memory.get("stories", {})
        .get(story_key, {})
        .get("files_written", {})
        .get(agent_key, [])
    )


def collect_file_contents(file_paths: list[str], max_chars_per_file: int = 4000) -> str:
    """
    Reads generated source/test files and passes actual code into Code Review and Security agents.

    This gives review agents stronger context than just file paths.
    Large files are truncated to max_chars_per_file to avoid oversized LLM prompts.
    """
    sections = []

    for file_path in file_paths or []:
        path = Path(file_path)

        if not path.exists() or not path.is_file():
            continue

        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            content = f"Could not read file: {e}"

        sections.append(
            f"\n\n### File: {file_path}\n"
            f"```text\n"
            f"{content[:max_chars_per_file]}\n"
            f"```"
        )

    return "\n".join(sections)


# =============================================================================
# Technology stack helpers
# =============================================================================

def get_default_stack_selection() -> dict:
    return {
        "Frontend": "React + Vite",
        "Backend": "Java 17 + Spring Boot",
        "Database": "PostgreSQL",
        "Local/Demo Database": "H2",
        "API Style": "REST",
        "Frontend Build Tool": "npm",
        "Backend Build Tool": "Maven",
        "Frontend Testing": "Vitest + React Testing Library",
        "Backend Testing": "JUnit 5 + Mockito",
        "QA Automation": "Playwright + Postman/Newman",
    }


def get_technology_options() -> dict:
    return {
        "Frontend": {
            "default": "React + Vite",
            "options": [
                "React + Vite",
                "React + Next.js",
                "Angular",
                "Vue + Vite",
            ],
        },
        "Backend": {
            "default": "Java 17 + Spring Boot",
            "options": [
                "Java 17 + Spring Boot",
                "Node.js + Express",
                "Python + FastAPI",
                ".NET 8 + ASP.NET Core",
            ],
        },
        "Database": {
            "default": "PostgreSQL",
            "options": [
                "PostgreSQL",
                "MySQL",
                "MongoDB",
                "SQL Server",
            ],
        },
        "Local/Demo Database": {
            "default": "H2",
            "options": [
                "H2",
                "SQLite",
                "Docker PostgreSQL",
                "Docker MySQL",
            ],
        },
        "API Style": {
            "default": "REST",
            "options": [
                "REST",
                "GraphQL",
                "gRPC",
            ],
        },
        "Frontend Build Tool": {
            "default": "npm",
            "options": [
                "npm",
                "pnpm",
                "yarn",
            ],
        },
        "Backend Build Tool": {
            "default": "Maven",
            "options": [
                "Maven",
                "Gradle",
            ],
        },
        "Frontend Testing": {
            "default": "Vitest + React Testing Library",
            "options": [
                "Vitest + React Testing Library",
                "Jest + React Testing Library",
                "Cypress Component Testing",
            ],
        },
        "Backend Testing": {
            "default": "JUnit 5 + Mockito",
            "options": [
                "JUnit 5 + Mockito",
                "JUnit 5 + Testcontainers",
                "pytest",
                "xUnit + Moq",
            ],
        },
        "QA Automation": {
            "default": "Playwright + Postman/Newman",
            "options": [
                "Playwright + Postman/Newman",
                "Cypress + Postman/Newman",
                "Selenium + Postman/Newman",
            ],
        },
    }


def known_real_technology_tokens() -> set[str]:
    """
    Local real-tech validation list.

    This does not call internet. It prevents accidental values like 'confirm',
    'abc', or empty input from becoming the confirmed stack.
    """
    return {
        "react",
        "vite",
        "next.js",
        "nextjs",
        "angular",
        "vue",
        "java",
        "java 17",
        "spring boot",
        "node.js",
        "nodejs",
        "express",
        "python",
        "fastapi",
        ".net",
        ".net 8",
        "asp.net core",
        "postgresql",
        "postgres",
        "mysql",
        "mongodb",
        "mongo",
        "sql server",
        "h2",
        "sqlite",
        "docker postgresql",
        "docker mysql",
        "rest",
        "graphql",
        "grpc",
        "npm",
        "pnpm",
        "yarn",
        "maven",
        "gradle",
        "vitest",
        "react testing library",
        "jest",
        "cypress",
        "selenium",
        "playwright",
        "postman",
        "newman",
        "junit",
        "junit 5",
        "mockito",
        "testcontainers",
        "pytest",
        "xunit",
        "moq",
    }


def normalize_tech_text(value: str) -> str:
    return " ".join((value or "").strip().lower().replace("+", " + ").replace("/", " / ").split())


def is_known_real_technology(value: str, allowed_options: list[str]) -> bool:
    normalized = normalize_tech_text(value)

    if not normalized:
        return False

    for option in allowed_options:
        if normalize_tech_text(option) == normalized:
            return True

    tokens = known_real_technology_tokens()

    # Split combo stacks like "Java 17 + Spring Boot" or "Playwright + Postman/Newman"
    parts = (
        normalized
        .replace("/", "+")
        .replace(",", "+")
        .replace("&", "+")
        .split("+")
    )

    cleaned_parts = [part.strip() for part in parts if part.strip()]

    if not cleaned_parts:
        return False

    return all(part in tokens for part in cleaned_parts)


def choose_technology(category: str, config: dict) -> str:
    default_value = config["default"]
    options = config["options"]

    while True:
        print("\n" + "-" * 100)
        print(f"{category}")
        print("-" * 100)
        print(f"Recommended default: {default_value}")
        print("")
        print("Suggestions:")

        for index, option in enumerate(options, start=1):
            default_marker = "  [DEFAULT]" if option == default_value else ""
            print(f"{index}. {option}{default_marker}")

        print("")
        print("Choose one:")
        print("- Press ENTER for default")
        print("- Type option number, example: 1")
        print("- Type exact technology name, example: React + Vite")
        print("- Type CUSTOM:<technology> only if you are sure it is real and installed/supported")
        print("")

        user_value = input(f"{category}: ").strip()

        if not user_value:
            return default_value

        if user_value.isdigit():
            selected_index = int(user_value)
            if 1 <= selected_index <= len(options):
                return options[selected_index - 1]

            print(f"Invalid option number: {user_value}")
            continue

        if user_value.upper() in {"YES", "Y", "DEFAULT"}:
            return default_value

        if user_value.upper() in {"CONFIRM", "OK"}:
            print("Please do not type CONFIRM/OK as technology. Press ENTER for default or select option number.")
            continue

        if user_value.upper().startswith("CUSTOM:"):
            custom_value = user_value.split(":", 1)[1].strip()
            if not custom_value:
                print("CUSTOM value is empty. Try again.")
                continue

            print(f"Custom technology accepted for {category}: {custom_value}")
            return custom_value

        if is_known_real_technology(user_value, options):
            return user_value

        print("")
        print(f"'{user_value}' is not recognized as a known real technology for {category}.")
        print("Select from suggestions or type CUSTOM:<technology> if you are sure.")


def format_stack_selection(stack: dict) -> str:
    lines = []

    for key, value in stack.items():
        lines.append(f"{key}: {value}")

    return "\n".join(lines)


def get_default_recommended_stack() -> str:
    return format_stack_selection(get_default_stack_selection())


def save_confirmed_technology_stack(selected_stack: str) -> str:
    tech_dir = data_dir("technical_architect")
    ensure_dir(tech_dir)

    file_path = tech_dir / "confirmed_technology_stack.md"

    content = (
        "# Confirmed Technology Stack\n\n"
        f"Confirmed At UTC: {now_utc()}\n\n"
        f"{selected_stack.strip()}\n"
    )

    save_text_file(file_path, content)
    return str(file_path)


def ask_user_to_confirm_or_enter_stack(memory: dict) -> tuple[str, str]:
    existing_stack = memory.get("confirmed_technology_stack", "")

    if existing_stack:
        print("\nConfirmed technology stack already exists in memory. Skipping stack selection.")
        print(existing_stack)
        return existing_stack, memory.get("confirmed_technology_stack_file", "")

    print("\n" + "=" * 100)
    print("TECHNOLOGY STACK SELECTION")
    print("=" * 100)
    print("Technical Architect has completed the architecture recommendation.")
    print("Now choose the implementation stack one by one.")
    print("")
    print("Rules:")
    print("- Press ENTER to accept recommended default for each category.")
    print("- Type option number to select a suggestion.")
    print("- Type exact technology name if it is known.")
    print("- Type CUSTOM:<technology> only for a real custom technology.")
    print("- Do NOT type 'confirm' as a technology value.")
    print("=" * 100)

    mode = input("Start stack selection? Type YES to continue, ENTER for default stack, NO to stop: ").strip()

    if mode.upper() == "NO":
        return "", ""

    if mode == "":
        selected_stack = get_default_recommended_stack()
        confirmed_stack_file = save_confirmed_technology_stack(selected_stack)
        memory["confirmed_technology_stack"] = selected_stack
        memory["confirmed_technology_stack_file"] = confirmed_stack_file
        save_memory(memory)

        print("\nDefault technology stack selected:")
        print(selected_stack)
        print("\nConfirmed technology stack saved at:")
        print(confirmed_stack_file)

        return selected_stack, confirmed_stack_file

    if mode.upper() not in {"YES", "Y"}:
        print("Invalid input. Use YES, ENTER, or NO.")
        return "", ""

    stack_config = get_technology_options()
    selected = {}

    for category, config in stack_config.items():
        selected[category] = choose_technology(category, config)

    selected_stack = format_stack_selection(selected)

    print("\n" + "=" * 100)
    print("FINAL SELECTED TECHNOLOGY STACK")
    print("=" * 100)
    print(selected_stack)
    print("=" * 100)

    final_confirm = input("Confirm this stack? Type YES to save, anything else to stop: ").strip().upper()

    if final_confirm != "YES":
        print("Technology stack not confirmed. Pipeline stopped.")
        return "", ""

    confirmed_stack_file = save_confirmed_technology_stack(selected_stack)

    memory["confirmed_technology_stack"] = selected_stack
    memory["confirmed_technology_stack_file"] = confirmed_stack_file
    save_memory(memory)

    print("\nConfirmed technology stack saved at:")
    print(confirmed_stack_file)

    return selected_stack, confirmed_stack_file




# =============================================================================
# Jira scope preview and correction helpers
# =============================================================================

def build_jira_scope_preview_text(
    feature_text: str,
    req_output: str,
    po_output: str,
    arch_output: str,
    selected_stack: str,
    data_event_output: str,
) -> str:
    """
    Creates a terminal-friendly preview before Jira story generation.

    This is intentionally deterministic so the user can validate scope before
    Jira stories are created.
    """
    correction_text = ""
    try:
        # Pull correction text from memory if available through outer closure is not possible here,
        # so this preview relies on updated PO/Arch/Data outputs after correction.
        correction_text = ""
    except Exception:
        correction_text = ""

    combined = "\n".join([
        feature_text or "",
        req_output or "",
        po_output or "",
        arch_output or "",
        selected_stack or "",
        data_event_output or "",
        correction_text,
    ]).lower()

    has_login = any(term in combined for term in ["login", "authentication", "auth", "sign in", "signin"])
    has_leave = "leave" in combined
    has_manager = "manager" in combined or "approve" in combined or "reject" in combined
    has_hr = "hr" in combined or "leave balance" in combined
    has_audit = "audit" in combined
    has_notification = "notification" in combined or "notify" in combined

    ui_pages = []
    backend_apis = []
    entities = []
    events = []

    if has_login:
        ui_pages.extend([
            "/login - Login page as first screen",
            "/logout - Logout action / session clear",
        ])
        backend_apis.extend([
            "POST /api/auth/login - Authenticate user",
            "POST /api/auth/logout - Logout user",
            "GET /api/auth/me - Get logged-in user profile",
        ])
        entities.extend([
            "User",
            "Role",
            "UserSession / RefreshToken if required",
        ])
        events.extend([
            "UserLoggedIn",
            "UserLoggedOut",
        ])

    if has_leave:
        ui_pages.append("/leave-request - Employee leave request form")
        backend_apis.append("POST /api/leave-requests - Create leave request")
        entities.append("LeaveRequest")
        events.append("LeaveRequestSubmitted")

    if has_manager:
        ui_pages.append("/manager/leave-requests - Manager approval/rejection screen")
        backend_apis.extend([
            "GET /api/leave-requests/pending - Get pending requests",
            "PUT /api/leave-requests/{id}/approve - Approve leave request",
            "PUT /api/leave-requests/{id}/reject - Reject leave request",
        ])
        events.extend([
            "LeaveRequestApproved",
            "LeaveRequestRejected",
        ])

    if has_hr:
        ui_pages.append("/hr/leave-balances - HR leave balance tracking page")
        backend_apis.append("GET /api/leave-balances - Get employee leave balances")
        entities.append("EmployeeLeaveBalance")
        events.append("LeaveBalanceUpdated")

    if has_notification:
        ui_pages.append("/notifications - Notification view / notification status")
        backend_apis.append("GET /api/notifications - Get notifications")
        entities.append("NotificationLog")
        events.append("NotificationSent")

    if has_audit:
        ui_pages.append("/hr/audit-trail - HR audit trail review page")
        backend_apis.append("GET /api/audit-trail - Get audit logs")
        entities.append("AuditTrail")
        events.append("AuditTrailRecorded")

    if not ui_pages:
        ui_pages = [
            "/ - Main application landing page",
            "/dashboard - User dashboard",
        ]

    if not backend_apis:
        backend_apis = [
            "GET /api/health - Health check",
        ]

    if not entities:
        entities = [
            "ApplicationUser",
            "AuditTrail",
        ]

    if not events:
        events = [
            "No event-driven implementation required for MVP; synchronous REST flow is enough.",
        ]

    # preserve order and remove duplicates
    ui_pages = list(dict.fromkeys(ui_pages))
    backend_apis = list(dict.fromkeys(backend_apis))
    entities = list(dict.fromkeys(entities))
    events = list(dict.fromkeys(events))

    lines = []
    lines.append("# Jira Scope Preview")
    lines.append("")
    lines.append("Review this before Jira stories are generated.")
    lines.append("")
    lines.append("## Frontend UI Pages / Routes")
    for page in ui_pages:
        lines.append(f"- {page}")

    lines.append("")
    lines.append("## Backend APIs")
    for api in backend_apis:
        lines.append(f"- {api}")

    lines.append("")
    lines.append("## Database / Data Model")
    for entity in entities:
        lines.append(f"- {entity}")

    lines.append("")
    lines.append("## Events / Notifications / Audit")
    for event in events:
        lines.append(f"- {event}")

    lines.append("")
    lines.append("## Confirm")
    lines.append("Type YES if the above UI pages, backend APIs, database, and events are correct.")
    lines.append("Type NO if something is missing/wrong.")

    return "\n".join(lines)


def save_jira_scope_preview(preview_text: str, iteration: int) -> str:
    preview_dir = data_dir("jira_generator", "scope_preview")
    ensure_dir(preview_dir)
    path = preview_dir / f"scope_preview_iteration_{iteration}.md"
    save_text_file(path, preview_text)
    return str(path)


def ask_for_jira_scope_confirmation(
    memory: dict,
    feature_text: str,
    req_output: str,
    po_output: str,
    arch_output: str,
    selected_stack: str,
    data_event_output: str,
) -> tuple[bool, str]:
    iteration = 1

    while True:
        preview_text = build_jira_scope_preview_text(
            feature_text=feature_text,
            req_output=req_output,
            po_output=po_output,
            arch_output=arch_output,
            selected_stack=selected_stack,
            data_event_output=data_event_output,
        )

        preview_file = save_jira_scope_preview(preview_text, iteration)

        print("\n" + "=" * 100)
        print("JIRA GENERATOR ANALYSIS PREVIEW: UI / API / DATA / EVENT SCOPE")
        print("=" * 100)
        print(preview_text)
        print("=" * 100)
        print(f"Scope preview saved at: {preview_file}")
        print("")
        answer = input("Is this correct? Type YES to run Jira Generator, NO to update architecture/data design: ").strip().upper()

        if answer == "YES":
            memory["jira_scope_confirmed"] = True
            memory["jira_scope_preview_file"] = preview_file
            save_memory(memory)
            return True, preview_file

        if answer != "NO":
            print("Invalid input. Type YES or NO.")
            continue

        update_request = input(
            "What update is needed? Example: 'Login module should be the first page with role based access': "
        ).strip()

        if not update_request:
            print("No update entered. Asking confirmation again.")
            continue

        correction_file = data_dir("jira_generator", "scope_preview", f"user_scope_correction_{iteration}.md")
        save_text_file(correction_file, update_request)

        memory.setdefault("jira_scope_corrections", [])
        memory["jira_scope_corrections"].append({
            "iteration": iteration,
            "correction": update_request,
            "file": str(correction_file),
            "time": now_utc(),
        })
        save_memory(memory)

        print("\nUser requested product/scope/design update:")
        print(update_request)
        print("")
        print("Re-running Product Owner, Technical Architect, and Data/Event Architect with this correction...")

        # ------------------------------------------------------------------
        # Re-run Product Owner with correction.
        # This is needed when user adds/changes product scope, such as:
        # "Login module should be the first page."
        # ------------------------------------------------------------------
        po_correction_input = (
            section("Original Feature Input", feature_text)
            + section("Requirement Analysis", req_output)
            + section("Previous Product Scope", po_output)
            + section("User Requested Product/Scope Update", update_request)
            + section(
                "Update Instruction",
                "Revise the product scope, MVP scope, future scope, priority order, sprint grouping, "
                "business value, release recommendation, assumptions, dependencies, risks, and open questions "
                "based on the user correction. If the user adds a login module, include it in MVP scope "
                "and put it before the main business flow."
            )
        )

        mark_step_started(memory, f"product_owner_scope_update_{iteration}")
        po_update = run_product_owner(po_correction_input)
        po_output = po_update.get("output", "") if isinstance(po_update, dict) else str(po_update)
        preview_output(f"Product Owner Scope Update {iteration}", po_output)
        mark_step_completed(memory, f"product_owner_scope_update_{iteration}", po_output)

        # ------------------------------------------------------------------
        # Re-run Technical Architect with corrected product scope.
        # ------------------------------------------------------------------
        arch_correction_input = (
            section("Original Feature Input", feature_text)
            + section("Requirement Analysis", req_output)
            + section("Updated Product Scope", po_output)
            + section("Previous Technical Architecture", arch_output)
            + section("Confirmed Technology Stack", selected_stack)
            + section("User Requested Architecture Update", update_request)
            + section(
                "Update Instruction",
                "Revise the technical architecture, application flow, UI route assumptions, backend API assumptions, "
                "security/authentication design, system diagrams, sequence diagrams, data flow diagrams, and "
                "technology notes based on the user correction. If login is requested, make login the first page "
                "and include authentication APIs, user/role model, and role-based access flow."
            )
        )

        mark_step_started(memory, f"technical_architect_scope_update_{iteration}")
        arch_update = run_technical_architect(arch_correction_input)
        arch_output = arch_update.get("output", "") if isinstance(arch_update, dict) else str(arch_update)
        preview_output(f"Technical Architect Scope Update {iteration}", arch_output)
        mark_step_completed(memory, f"technical_architect_scope_update_{iteration}", arch_output)

        # ------------------------------------------------------------------
        # Re-run Data/Event Architect with corrected architecture.
        # ------------------------------------------------------------------
        data_event_correction_input = (
            section("Original Feature Input", feature_text)
            + section("Requirement Analysis", req_output)
            + section("Updated Product Scope", po_output)
            + section("Updated Technical Architecture", arch_output)
            + section("Confirmed Technology Stack", selected_stack)
            + section("User Requested Data/Event Update", update_request)
            + section(
                "Update Instruction",
                "Revise the data model, relationships, database design, events, notification model, audit model, "
                "authentication/session/user/role model if required, and backend/QA implementation guidance "
                "based on the user correction."
            )
        )

        mark_step_started(memory, f"data_event_architect_scope_update_{iteration}")
        data_event_update = run_data_event_architect(data_event_correction_input)
        data_event_output = data_event_update.get("output", "") if isinstance(data_event_update, dict) else str(data_event_update)
        preview_output(f"Data/Event Architect Scope Update {iteration}", data_event_output)
        mark_step_completed(memory, f"data_event_architect_scope_update_{iteration}", data_event_output)

        # Store latest active outputs under the normal keys,
        # so Jira Generator uses the corrected Product Owner, Architecture, and Data/Event outputs.
        memory.setdefault("outputs", {})
        memory["outputs"]["product_owner"] = po_output
        memory["outputs"]["technical_architect"] = arch_output
        memory["outputs"]["data_event_architect"] = data_event_output
        memory["jira_scope_confirmed"] = False
        save_memory(memory)

        iteration += 1

# =============================================================================
# Story helpers
# =============================================================================

def get_story_instruction_files(memory: dict, jira_result: dict | None = None) -> list[str]:
    if memory.get("story_instruction_files"):
        return sorted(memory["story_instruction_files"])

    if jira_result:
        story_files = jira_result.get("story_instruction_files")
        if story_files:
            return sorted(story_files)

    search_roots = [
        data_dir("jira_generator"),
        PROJECT_ROOT / "data" / "jira_generator",
        PROJECT_ROOT / "outputs" / "jira_generator",
    ]

    candidates = []

    for root in search_roots:
        candidates.extend(glob.glob(str(Path(root) / "story_*_instruction.md")))
        candidates.extend(glob.glob(str(Path(root) / "**" / "story_*_instruction.md"), recursive=True))

    return sorted(set(candidates))


def build_story_agent_input(
    story_file: str,
    feature_text: str,
    req_output: str,
    po_output: str,
    arch_output: str,
    selected_stack: str,
    data_event_output: str,
    jira_output: str,
) -> str:
    story_text = ""

    if os.path.exists(story_file):
        story_text = read_text_file(story_file)

    return (
        section("Feature Input", feature_text)
        + section("Requirement Analysis", req_output)
        + section("Product Prioritization", po_output)
        + section("Technical Architecture", arch_output)
        + section("Confirmed Technology Stack", selected_stack)
        + section("Data & Event Architecture", data_event_output)
        + section("Jira Delivery Breakdown", jira_output)
        + section("Story Instruction File Path", story_file)
        + section("Story Instruction Content", story_text)
    )


# =============================================================================
# Build and fix helpers
# =============================================================================

def print_check_results(title: str, results: list[dict]):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)

    if not results:
        print("No results returned.")
        return

    print(format_results(results))


def run_frontend_validation_or_fix(
    memory: dict,
    story_file: str,
    story_context: str,
    frontend_codebase_path: str,
    write_changes: bool,
    max_fix_attempts: int = 1,
):
    require_build_runner()

    results = run_frontend_checks(frontend_codebase_path)
    mark_build_result(memory, story_file, "frontend_initial_check", results)
    print_check_results("Frontend Build/Test Results", results)

    if not has_failure(results):
        return results

    for attempt in range(1, max_fix_attempts + 1):
        error_log = format_results(results)

        fix_input = (
            story_context
            + section("Frontend Build/Test Error Log", error_log)
            + section(
                "Fix Instruction",
                "Fix the frontend code based on the above error. "
                "Update actual files because write_changes=True. "
                "Return implementation summary with files fixed.",
            )
        )

        print("\nFrontend failed. Calling Frontend Agent for fix attempt", attempt)

        fix_result = call_with_supported_kwargs(
            run_frontend_ux_agent,
            input_payload=fix_input,
            input_text=fix_input,
            codebase_path=frontend_codebase_path,
            write_changes=write_changes,
        )

        fix_output = fix_result.get("output", "") if isinstance(fix_result, dict) else str(fix_result)
        fix_files = fix_result.get("files_written", []) if isinstance(fix_result, dict) else []

        preview_output(f"Frontend Fix Attempt {attempt}", fix_output)
        mark_story_agent_completed(
            memory,
            story_file,
            f"frontend_ux_agent_fix_{attempt}",
            fix_output,
            fix_files,
        )

        results = run_frontend_checks(frontend_codebase_path)
        mark_build_result(memory, story_file, f"frontend_fix_{attempt}_check", results)
        print_check_results(f"Frontend Build/Test Results After Fix Attempt {attempt}", results)

        if not has_failure(results):
            return results

    raise RuntimeError(
        "Frontend still failing after fix attempts:\n"
        + format_results(results)
    )


def run_backend_validation_or_fix(
    memory: dict,
    story_file: str,
    story_context: str,
    backend_codebase_path: str,
    write_changes: bool,
    max_fix_attempts: int = 1,
):
    require_build_runner()

    results = run_backend_checks(backend_codebase_path)
    mark_build_result(memory, story_file, "backend_initial_check", results)
    print_check_results("Backend Build/Test Results", results)

    if not has_failure(results):
        return results

    for attempt in range(1, max_fix_attempts + 1):
        error_log = format_results(results)

        fix_input = (
            story_context
            + section("Backend Build/Test Error Log", error_log)
            + section(
                "Fix Instruction",
                "Fix the backend code based on the above error. "
                "Update actual files because write_changes=True. "
                "Return implementation summary with files fixed.",
            )
        )

        print("\nBackend failed. Calling Backend Agent for fix attempt", attempt)

        fix_result = call_with_supported_kwargs(
            run_backend_developer,
            input_payload=fix_input,
            input_text=fix_input,
            codebase_path=backend_codebase_path,
            write_changes=write_changes,
        )

        fix_output = fix_result.get("output", "") if isinstance(fix_result, dict) else str(fix_result)
        fix_files = fix_result.get("files_written", []) if isinstance(fix_result, dict) else []

        preview_output(f"Backend Fix Attempt {attempt}", fix_output)
        mark_story_agent_completed(
            memory,
            story_file,
            f"backend_developer_fix_{attempt}",
            fix_output,
            fix_files,
        )

        results = run_backend_checks(backend_codebase_path)
        mark_build_result(memory, story_file, f"backend_fix_{attempt}_check", results)
        print_check_results(f"Backend Build/Test Results After Fix Attempt {attempt}", results)

        if not has_failure(results):
            return results

    raise RuntimeError(
        "Backend still failing after fix attempts:\n"
        + format_results(results)
    )


def run_qa_validation_or_fix(
    memory: dict,
    story_file: str,
    qa_context: str,
    frontend_codebase_path: str,
    backend_codebase_path: str,
    write_changes: bool,
    max_fix_attempts: int = 1,
):
    require_build_runner()

    frontend_results = run_frontend_checks(frontend_codebase_path)
    backend_results = run_backend_checks(backend_codebase_path)

    combined = {
        "frontend": frontend_results,
        "backend": backend_results,
    }

    mark_build_result(memory, story_file, "qa_post_check", combined)

    print_check_results("QA Post Frontend Build/Test Results", frontend_results)
    print_check_results("QA Post Backend Build/Test Results", backend_results)

    if not has_failure(frontend_results) and not has_failure(backend_results):
        return combined

    for attempt in range(1, max_fix_attempts + 1):
        qa_error_log = (
            section("Frontend Check Results", format_results(frontend_results))
            + section("Backend Check Results", format_results(backend_results))
        )

        fix_input = (
            qa_context
            + qa_error_log
            + section(
                "QA Fix Instruction",
                "Fix QA test files and test setup based on the above failures. "
                "If the issue is clearly frontend or backend code, document it clearly.",
            )
        )

        print("\nQA validation failed. Calling QA Agent for fix attempt", attempt)

        fix_result = call_with_supported_kwargs(
            run_qa_agent,
            input_payload=fix_input,
            input_text=fix_input,
            frontend_codebase_path=frontend_codebase_path,
            backend_codebase_path=backend_codebase_path,
            write_changes=write_changes,
            run_checks=True,
        )

        fix_output = fix_result.get("output", "") if isinstance(fix_result, dict) else str(fix_result)
        fix_files = fix_result.get("files_written", []) if isinstance(fix_result, dict) else []

        preview_output(f"QA Fix Attempt {attempt}", fix_output)
        mark_story_agent_completed(
            memory,
            story_file,
            f"qa_agent_fix_{attempt}",
            fix_output,
            fix_files,
        )

        frontend_results = run_frontend_checks(frontend_codebase_path)
        backend_results = run_backend_checks(backend_codebase_path)

        combined = {
            "frontend": frontend_results,
            "backend": backend_results,
        }

        mark_build_result(memory, story_file, f"qa_fix_{attempt}_post_check", combined)

        if not has_failure(frontend_results) and not has_failure(backend_results):
            return combined

    raise RuntimeError(
        "QA validation still failing after fix attempts:\n"
        + section("Frontend Results", format_results(frontend_results))
        + section("Backend Results", format_results(backend_results))
    )


# =============================================================================
# Final output helpers
# =============================================================================

def print_application_urls(frontend_codebase_path: str, backend_codebase_path: str):
    print("\n" + "=" * 100)
    print("AI SDLC PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 100)
    print("")
    print("Generated Frontend:")
    print(frontend_codebase_path)
    print("")
    print("Generated Backend:")
    print(backend_codebase_path)
    print("")
    print("Generated QA:")
    print(str(PROJECT_ROOT / "qa"))
    print("")
    print("Application URLs:")
    print("Frontend URL      : http://localhost:5173")
    print("Backend Base URL  : http://localhost:8080")
    print("H2 Console        : http://localhost:8080/h2-console")
    print("")
    print("Backend APIs:")
    print("- POST http://localhost:8080/api/leave-requests")
    print("- GET  http://localhost:8080/api/leave-requests/pending")
    print("- PUT  http://localhost:8080/api/leave-requests/{id}/approve")
    print("- PUT  http://localhost:8080/api/leave-requests/{id}/reject")
    print("- GET  http://localhost:8080/api/leave-balances")
    print("- GET  http://localhost:8080/api/audit-trail")
    print("")
    print("Start Commands:")
    print("Frontend:")
    print("cd frontEndApp")
    print("npm install")
    print("npm run dev")
    print("")
    print("Backend:")
    print("cd backEndApp")
    print("mvn spring-boot:run")
    print("=" * 100)


# =============================================================================
# Main pipeline
# =============================================================================

def run_pipeline(
    feature_text: str,
    frontend_codebase_path: str | None = None,
    backend_codebase_path: str | None = None,
    write_changes: bool = False,
    run_qa_checks: bool = False,
):
    """
    Memory-enabled 10-agent SDLC pipeline with build runner.

    Behavior:
    - If memory/file.txt is missing, starts from Agent 1.
    - After every successful agent completion, memory/file.txt is updated.
    - If run_qa_checks=True, orchestrator executes frontend/backend build/test commands.
    - If build/test fails, orchestrator calls the correct agent again to fix code and reruns validation.
    """

    frontend_codebase_path = normalize_codebase_path(frontend_codebase_path, "frontEndApp")
    backend_codebase_path = normalize_codebase_path(backend_codebase_path, "backEndApp")

    if run_qa_checks:
        require_build_runner()

    memory = load_memory()

    if not memory.get("feature_text"):
        memory["feature_text"] = feature_text

    memory["frontend_codebase_path"] = frontend_codebase_path
    memory["backend_codebase_path"] = backend_codebase_path
    memory["write_changes"] = write_changes
    memory["run_qa_checks"] = run_qa_checks
    save_memory(memory)

    feature_text = memory.get("feature_text") or feature_text

    try:
        # ---------------------------------------------------------------------
        # Agent 1: Requirement Analyzer
        # ---------------------------------------------------------------------
        if has_output(memory, "requirement_analyzer"):
            print("\nSkipping Agent 1: Requirement Analyzer. Already completed in memory.")
            req_output = get_output(memory, "requirement_analyzer")
        else:
            if not confirm("1", "Requirement Analyzer Agent"):
                return memory

            mark_step_started(memory, "requirement_analyzer")
            req = run_requirement_analyzer(feature_text)
            req_output = req.get("output", "")
            preview_output("Requirement Analyzer Agent", req_output)
            mark_step_completed(memory, "requirement_analyzer", req_output)

        # ---------------------------------------------------------------------
        # Agent 2: Product Owner
        # ---------------------------------------------------------------------
        if has_output(memory, "product_owner"):
            print("\nSkipping Agent 2: Product Owner. Already completed in memory.")
            po_output = get_output(memory, "product_owner")
        else:
            if not confirm("2", "Product Owner Agent"):
                return memory

            po_input = (
                section("Feature Input", feature_text)
                + section("Requirement Analysis", req_output)
            )

            mark_step_started(memory, "product_owner")
            po = run_product_owner(po_input)
            po_output = po.get("output", "")
            preview_output("Product Owner Agent", po_output)
            mark_step_completed(memory, "product_owner", po_output)

        # ---------------------------------------------------------------------
        # Agent 3: Technical Architect
        # ---------------------------------------------------------------------
        if has_output(memory, "technical_architect"):
            print("\nSkipping Agent 3: Technical Architect. Already completed in memory.")
            arch_output = get_output(memory, "technical_architect")
        else:
            if not confirm("3", "Technical Architect Agent"):
                return memory

            arch_input = (
                section("Feature Input", feature_text)
                + section("Requirement Analysis", req_output)
                + section("Product Prioritization", po_output)
            )

            mark_step_started(memory, "technical_architect")
            arch = run_technical_architect(arch_input)
            arch_output = arch.get("output", "")
            preview_output("Technical Architect Agent", arch_output)
            mark_step_completed(memory, "technical_architect", arch_output)

        # ---------------------------------------------------------------------
        # Technology stack confirmation
        # ---------------------------------------------------------------------
        selected_stack, confirmed_stack_file = ask_user_to_confirm_or_enter_stack(memory)

        if not selected_stack:
            print("Technology stack was not confirmed. Pipeline stopped.")
            return memory

        # ---------------------------------------------------------------------
        # Agent 4: Data & Event Architect
        # ---------------------------------------------------------------------
        if has_output(memory, "data_event_architect"):
            print("\nSkipping Agent 4: Data & Event Architect. Already completed in memory.")
            data_event_output = get_output(memory, "data_event_architect")
        else:
            if not confirm("4", "Data & Event Architect Agent"):
                return memory

            data_event_input = (
                section("Feature Input", feature_text)
                + section("Requirement Analysis", req_output)
                + section("Product Prioritization", po_output)
                + section("Technical Architecture", arch_output)
                + section("Confirmed Technology Stack", selected_stack)
            )

            mark_step_started(memory, "data_event_architect")
            data_event = run_data_event_architect(data_event_input)
            data_event_output = data_event.get("output", "")
            preview_output("Data & Event Architect Agent", data_event_output)
            mark_step_completed(memory, "data_event_architect", data_event_output)

        # ---------------------------------------------------------------------
        # Jira scope preview confirmation before story generation
        # ---------------------------------------------------------------------
        if not memory.get("jira_scope_confirmed") or not has_output(memory, "jira_generator"):
            confirmed_scope, scope_preview_file = ask_for_jira_scope_confirmation(
                memory=memory,
                feature_text=feature_text,
                req_output=req_output,
                po_output=po_output,
                arch_output=arch_output,
                selected_stack=selected_stack,
                data_event_output=data_event_output,
            )

            if not confirmed_scope:
                print("Jira scope was not confirmed. Pipeline stopped before Jira Generator.")
                return memory

            # Reload potentially updated architecture/data outputs after user corrections.
            arch_output = get_output(memory, "technical_architect")
            data_event_output = get_output(memory, "data_event_architect")

        # ---------------------------------------------------------------------
        # Agent 5: Jira Story Generator
        # ---------------------------------------------------------------------
        if has_output(memory, "jira_generator") and memory.get("story_instruction_files"):
            print("\nSkipping Agent 5: Jira Story Generator. Already completed in memory.")
            jira_output = get_output(memory, "jira_generator")
            story_instruction_files = get_story_instruction_files(memory)
        else:
            if not confirm("5", "Jira Story Generator Agent"):
                return memory

            scope_preview_text = ""
            scope_preview_file = memory.get("jira_scope_preview_file", "")
            if scope_preview_file and os.path.exists(scope_preview_file):
                scope_preview_text = read_text_file(scope_preview_file)

            corrections_text = ""
            for correction in memory.get("jira_scope_corrections", []):
                corrections_text += f"\n- Iteration {correction.get('iteration')}: {correction.get('correction')}"

            jira_input = (
                section("Feature Input", feature_text)
                + section("Requirement Analysis", req_output)
                + section("Product Prioritization", po_output)
                + section("Technical Architecture", arch_output)
                + section("Confirmed Technology Stack", selected_stack)
                + section("Data & Event Architecture", data_event_output)
                + section("Confirmed Jira Scope Preview", scope_preview_text)
                + section("User Scope Corrections Applied", corrections_text)
            )

            mark_step_started(memory, "jira_generator")
            jira = run_jira_generator(jira_input)
            jira_output = jira.get("output", "")
            story_instruction_files = get_story_instruction_files(memory, jira)

            if not story_instruction_files:
                story_instruction_files = get_story_instruction_files(memory)

            if not story_instruction_files:
                raise ValueError(
                    "No story instruction files found. "
                    "Jira Generator should create story_*_instruction.md files."
                )

            preview_output("Jira Story Generator Agent", jira_output)
            mark_step_completed(
                memory,
                "jira_generator",
                jira_output,
                extra={"story_instruction_files": story_instruction_files},
            )

        print("\n" + "=" * 100)
        print(f"Story instruction files: {len(story_instruction_files)}")
        for file_path in story_instruction_files:
            print(f"- {file_path}")
        print("=" * 100)

        # ---------------------------------------------------------------------
        # Agent 6-10: Story-by-story FE / BE / QA / Review / Security
        # ---------------------------------------------------------------------
        if not confirm("6-10", "Story-by-story Implementation, QA, Review and Security Agents"):
            return memory

        for story_index, story_file in enumerate(story_instruction_files, start=1):
            print("\n" + "=" * 100)
            print(f"Story {story_index}/{len(story_instruction_files)}")
            print(story_file)
            print("=" * 100)

            story_context = build_story_agent_input(
                story_file=story_file,
                feature_text=feature_text,
                req_output=req_output,
                po_output=po_output,
                arch_output=arch_output,
                selected_stack=selected_stack,
                data_event_output=data_event_output,
                jira_output=jira_output,
            )

            # -----------------------------------------------------------------
            # Agent 6: Frontend
            # -----------------------------------------------------------------
            if story_agent_done(memory, story_file, "frontend_ux_agent"):
                print("Skipping Frontend Agent for this story. Already completed in memory.")
                frontend_output = get_story_agent_output(memory, story_file, "frontend_ux_agent")
                frontend_files = get_story_agent_files(memory, story_file, "frontend_ux_agent")
            else:
                mark_step_started(memory, f"{os.path.basename(story_file)}:frontend_ux_agent")

                frontend = call_with_supported_kwargs(
                    run_frontend_ux_agent,
                    input_payload=story_context,
                    input_text=story_context,
                    story_instruction_path=story_file,
                    codebase_path=frontend_codebase_path,
                    write_changes=write_changes,
                )

                frontend_output = frontend.get("output", "") if isinstance(frontend, dict) else str(frontend)
                frontend_files = frontend.get("files_written", []) if isinstance(frontend, dict) else []

                preview_output(f"Frontend Agent - Story {story_index}", frontend_output)
                mark_story_agent_completed(
                    memory,
                    story_file,
                    "frontend_ux_agent",
                    frontend_output,
                    frontend_files,
                )

            if run_qa_checks:
                run_frontend_validation_or_fix(
                    memory=memory,
                    story_file=story_file,
                    story_context=story_context + section("Frontend Output", frontend_output),
                    frontend_codebase_path=frontend_codebase_path,
                    write_changes=write_changes,
                )

            # -----------------------------------------------------------------
            # Agent 7: Backend
            # -----------------------------------------------------------------
            if story_agent_done(memory, story_file, "backend_developer"):
                print("Skipping Backend Agent for this story. Already completed in memory.")
                backend_output = get_story_agent_output(memory, story_file, "backend_developer")
                backend_files = get_story_agent_files(memory, story_file, "backend_developer")
            else:
                mark_step_started(memory, f"{os.path.basename(story_file)}:backend_developer")

                backend = call_with_supported_kwargs(
                    run_backend_developer,
                    input_payload=story_context,
                    input_text=story_context,
                    story_instruction_path=story_file,
                    codebase_path=backend_codebase_path,
                    write_changes=write_changes,
                )

                backend_output = backend.get("output", "") if isinstance(backend, dict) else str(backend)
                backend_files = backend.get("files_written", []) if isinstance(backend, dict) else []

                preview_output(f"Backend Agent - Story {story_index}", backend_output)
                mark_story_agent_completed(
                    memory,
                    story_file,
                    "backend_developer",
                    backend_output,
                    backend_files,
                )

            if run_qa_checks:
                run_backend_validation_or_fix(
                    memory=memory,
                    story_file=story_file,
                    story_context=story_context + section("Backend Output", backend_output),
                    backend_codebase_path=backend_codebase_path,
                    write_changes=write_changes,
                )

            # -----------------------------------------------------------------
            # Agent 8: QA
            # -----------------------------------------------------------------
            qa_context = (
                story_context
                + section("Frontend Implementation Output", frontend_output)
                + section("Backend Implementation Output", backend_output)
            )

            if story_agent_done(memory, story_file, "qa_agent"):
                print("Skipping QA Agent for this story. Already completed in memory.")
                qa_output = get_story_agent_output(memory, story_file, "qa_agent")
                qa_files = get_story_agent_files(memory, story_file, "qa_agent")
            else:
                mark_step_started(memory, f"{os.path.basename(story_file)}:qa_agent")

                qa = call_with_supported_kwargs(
                    run_qa_agent,
                    input_payload=qa_context,
                    input_text=qa_context,
                    story_instruction_path=story_file,
                    frontend_codebase_path=frontend_codebase_path,
                    backend_codebase_path=backend_codebase_path,
                    write_changes=write_changes,
                    run_checks=run_qa_checks,
                )

                qa_output = qa.get("output", "") if isinstance(qa, dict) else str(qa)
                qa_files = qa.get("files_written", []) if isinstance(qa, dict) else []

                preview_output(f"QA Agent - Story {story_index}", qa_output)
                mark_story_agent_completed(
                    memory,
                    story_file,
                    "qa_agent",
                    qa_output,
                    qa_files,
                )

            if run_qa_checks:
                run_qa_validation_or_fix(
                    memory=memory,
                    story_file=story_file,
                    qa_context=qa_context + section("QA Output", qa_output),
                    frontend_codebase_path=frontend_codebase_path,
                    backend_codebase_path=backend_codebase_path,
                    write_changes=write_changes,
                )

            # -----------------------------------------------------------------
            # Agent 9: Code Review
            # -----------------------------------------------------------------
            actual_code_content = (
                section("Frontend Actual Code Content", collect_file_contents(frontend_files))
                + section("Backend Actual Code Content", collect_file_contents(backend_files))
                + section("QA Actual Test Content", collect_file_contents(qa_files))
            )

            review_context = (
                story_context
                + section("Frontend Implementation Output", frontend_output)
                + section("Backend Implementation Output", backend_output)
                + section("QA Implementation Output", qa_output)
                + section("Frontend Files Written", "\n".join(frontend_files))
                + section("Backend Files Written", "\n".join(backend_files))
                + section("QA Files Written", "\n".join(qa_files))
                + actual_code_content
            )

            if story_agent_done(memory, story_file, "code_review_agent"):
                print("Skipping Code Review Agent for this story. Already completed in memory.")
                review_output = get_story_agent_output(memory, story_file, "code_review_agent")
            else:
                mark_step_started(memory, f"{os.path.basename(story_file)}:code_review_agent")
                review = run_code_review_agent(review_context)
                review_output = review.get("output", "") if isinstance(review, dict) else str(review)

                preview_output(f"Code Review Agent - Story {story_index}", review_output)
                mark_story_agent_completed(memory, story_file, "code_review_agent", review_output, [])

            # -----------------------------------------------------------------
            # Agent 10: Security
            # -----------------------------------------------------------------
            security_context = (
                review_context
                + section("Code Review Output", review_output)
                + section("Confirmed Technology Stack", selected_stack)
                + section("Data & Event Architecture", data_event_output)
            )

            if story_agent_done(memory, story_file, "security_agent"):
                print("Skipping Security Agent for this story. Already completed in memory.")
                security_output = get_story_agent_output(memory, story_file, "security_agent")
            else:
                mark_step_started(memory, f"{os.path.basename(story_file)}:security_agent")
                security = run_security_agent(security_context)
                security_output = security.get("output", "") if isinstance(security, dict) else str(security)

                preview_output(f"Security Agent - Story {story_index}", security_output)
                mark_story_agent_completed(memory, story_file, "security_agent", security_output, [])

        # ---------------------------------------------------------------------
        # Final full validation
        # ---------------------------------------------------------------------
        if run_qa_checks:
            print("\nRunning final full application validation...")

            final_frontend_results = run_frontend_checks(frontend_codebase_path)
            final_backend_results = run_backend_checks(backend_codebase_path)

            memory.setdefault("build_results", {})
            memory["build_results"]["final_frontend"] = final_frontend_results
            memory["build_results"]["final_backend"] = final_backend_results
            save_memory(memory)

            print_check_results("Final Frontend Build/Test Results", final_frontend_results)
            print_check_results("Final Backend Build/Test Results", final_backend_results)

            if has_failure(final_frontend_results) or has_failure(final_backend_results):
                raise RuntimeError(
                    "Final application validation failed:\n"
                    + section("Frontend Results", format_results(final_frontend_results))
                    + section("Backend Results", format_results(final_backend_results))
                )

        memory["pipeline_status"] = "completed"
        memory["current_step"] = None
        memory["last_completed_step"] = "pipeline_completed"
        save_memory(memory)

        print_application_urls(frontend_codebase_path, backend_codebase_path)

        return memory

    except Exception as e:
        print("\n" + "=" * 100)
        print("Pipeline failed. Progress has been saved in memory/file.txt.")
        print("Fix the error and run python run_pipeline.py again.")
        print("=" * 100)
        print(str(e))

        mark_error(memory, memory.get("current_step") or "unknown_step", e)
        raise
