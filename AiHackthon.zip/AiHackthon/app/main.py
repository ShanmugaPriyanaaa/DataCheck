import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

import streamlit as st
from orchestrator import run_pipeline

st.set_page_config(page_title="AI SDLC Multi-Agent Platform", layout="wide")

st.title("AI SDLC Multi-Agent Platform")
st.caption("17-agent enterprise SDLC workflow")

feature_text = st.text_area(
    "Enter Feature / Issue / Change Request",
    height=220,
    placeholder="Example: Build a leave management feature where employees apply for leave, managers approve/reject, HR tracks balance, notifications are sent, and an audit trail is maintained."
)

if st.button("Run Full 17-Agent Pipeline"):
    if not feature_text.strip():
        st.warning("Please enter a feature or issue description.")
    else:
        with st.spinner("Running agents..."):
            outputs = run_pipeline(feature_text)

        st.success("Pipeline completed.")

        tabs = st.tabs([name.replace("_", " ").title() for name in outputs.keys()])

        for i, (agent_name, result) in enumerate(outputs.items()):
            with tabs[i]:
                st.subheader(result["agent"].replace("_", " ").title())
                st.markdown(result["output"])