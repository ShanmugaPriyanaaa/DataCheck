import os
import requests
from dotenv import load_dotenv

load_dotenv()

base_url = os.getenv("LITELLM_BASE_URL", "").rstrip("/")
api_key = os.getenv("LITELLM_API_KEY", "")
model = os.getenv("MODEL_NAME", "gpt-4o-mini")
verify_ssl = os.getenv("VERIFY_SSL", "true").lower() == "true"

if not base_url:
    raise ValueError("LITELLM_BASE_URL is missing in .env")

if not api_key:
    raise ValueError("LITELLM_API_KEY is missing in .env")

url = f"{base_url}/chat/completions"

headers = {
    "accept": "application/json",
    "Content-Type": "application/json",
}

if "api.openai.com" in base_url:
    headers["Authorization"] = f"Bearer {api_key}"
else:
    headers["x-litellm-api-key"] = api_key

payload = {
    "model": model,
    "messages": [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Reply with exactly: connection successful"}
    ],
    "temperature": 0
}

print("Testing:", url)
print("Model:", model)
print("Auth Mode:", "OpenAI Bearer Token" if "api.openai.com" in base_url else "TCS LiteLLM x-litellm-api-key")
print("API Key Loaded:", "YES" if api_key else "NO")
print("API Key Prefix:", api_key[:7])

response = requests.post(
    url,
    headers=headers,
    json=payload,
    verify=verify_ssl,
    timeout=120
)

print("Status:", response.status_code)
print(response.text)

if response.status_code != 200:
    raise Exception("LLM connection test failed.")

data = response.json()
print("\nParsed Response:")
print(data["choices"][0]["message"]["content"])