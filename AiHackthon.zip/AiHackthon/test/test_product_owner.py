import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from product_owner import run_product_owner
from file_utils import read_agent_file, agent_file_exists

sample_input = """
## Feature Input
Build a leave request feature where employees can apply for leave, managers can approve or reject the request, and HR can track leave balances. The system should send notifications and maintain an audit trail.

## Requirement Analysis
# Feature Name
Leave Request Management

## Summary
A leave request capability is needed to allow employees to submit leave requests, managers to review and approve or reject them, and HR to oversee balances and compliance.

## Functional Requirements
- Employees can submit leave requests.
- Managers can approve or reject leave requests.
- HR can view and track leave balances.
- The system should send notifications.
- The system should maintain an audit trail.
"""

try:
    result = run_product_owner(sample_input)

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("product_owner", "output", "md"):
        print("\n=== SAVED FILE CONTENT ===")
        print(read_agent_file("product_owner", "output", "md"))

except Exception as e:
    print("Error while testing product owner:")
    print(str(e))