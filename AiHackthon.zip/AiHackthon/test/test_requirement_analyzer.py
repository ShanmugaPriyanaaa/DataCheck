import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from requirement_analyzer import run_requirement_analyzer
from file_utils import read_agent_file, agent_file_exists

sample_input = """
Build a leave request feature where employees can apply for leave, managers can approve or reject the request, and HR can track leave balances. The system should send notifications and maintain an audit trail.
"""

try:
    result = run_requirement_analyzer(sample_input)

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("requirement_analyzer", "output", "md"):
        print("\n=== SAVED FILE CONTENT ===")
        print(read_agent_file("requirement_analyzer", "output", "md"))

except Exception as e:
    print("Error while testing requirement analyzer:")
    print(str(e))