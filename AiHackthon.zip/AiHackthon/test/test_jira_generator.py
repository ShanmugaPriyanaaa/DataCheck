import os
import sys
import glob

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")
DATA_DIR = os.path.join(BASE_DIR, "data")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from jira_generator import run_jira_generator

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

requirement_path = os.path.join(DATA_DIR, "requirement_analyzer", "output.md")
product_owner_path = os.path.join(DATA_DIR, "product_owner", "output.md")
technical_architect_path = os.path.join(DATA_DIR, "technical_architect", "output.md")
data_event_path = os.path.join(DATA_DIR, "data_event_architect", "output.md")

parts = []

if os.path.exists(requirement_path):
    parts.append("## Requirement Analysis\n" + read_file(requirement_path))

if os.path.exists(product_owner_path):
    parts.append("## Product Scope Recommendation\n" + read_file(product_owner_path))

if os.path.exists(technical_architect_path):
    parts.append("## Technical Architecture Recommendation\n" + read_file(technical_architect_path))

if os.path.exists(data_event_path):
    parts.append("## Data and Event Architecture Recommendation\n" + read_file(data_event_path))

if not parts:
    raise ValueError("No upstream files found for Jira Generator input")

combined_input = "\n\n".join(parts)

result = run_jira_generator(combined_input)

print("=== JIRA GENERATOR OUTPUT ===")
print(result["output"])

story_dir = os.path.join(DATA_DIR, "jira_generator")
story_files = sorted(glob.glob(os.path.join(story_dir, "story_*.md")))
instruction_files = sorted(glob.glob(os.path.join(story_dir, "story_*_instruction.md")))

print("\n=== STORY FILES ===")
for file in story_files:
    print(file)

print("\n=== STORY INSTRUCTION FILES ===")
for file in instruction_files:
    print(file)