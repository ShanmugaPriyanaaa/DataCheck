import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from data_event_architect import run_data_event_architect
from file_utils import read_agent_file, agent_file_exists, read_agent_subfile, agent_subfile_exists

try:
    result = run_data_event_architect()

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("data_event_architect", "output", "md"):
        print("\n=== TOP-LEVEL SAVED OUTPUT ===")
        print(read_agent_file("data_event_architect", "output", "md"))

    if agent_subfile_exists("data_event_architect", "output.md"):
        print("\n=== FOLDER SAVED OUTPUT ===")
        print(read_agent_subfile("data_event_architect", "output.md"))

except Exception as e:
    print("Error while testing data event architect:")
    print(str(e))