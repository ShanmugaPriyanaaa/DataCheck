import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from backend_developer import run_backend_developer
from file_utils import read_agent_file, agent_file_exists, read_agent_subfile, agent_subfile_exists

# Option 1: No real backend repo path; code scaffolds will be generated in data/backend_developer/generated_code/
BACKEND_CODEBASE_PATH = r"C:\AiHackthon\backEndApp"

# Option 2: Point to a real backend repo and set write_changes=True
# BACKEND_CODEBASE_PATH = r"C:\AiHackthon\my-backend-app"

WRITE_CHANGES = True

try:
    result = run_backend_developer(
        codebase_path=BACKEND_CODEBASE_PATH,
        write_changes=WRITE_CHANGES
    )

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("backend_developer", "output", "md"):
        print("\n=== TOP-LEVEL SAVED OUTPUT ===")
        print(read_agent_file("backend_developer", "output", "md"))

    if agent_subfile_exists("backend_developer", "output.md"):
        print("\n=== FOLDER SAVED OUTPUT ===")
        print(read_agent_subfile("backend_developer", "output.md"))

    if agent_subfile_exists("backend_developer", "generated_code_summary.md"):
        print("\n=== GENERATED CODE SUMMARY ===")
        print(read_agent_subfile("backend_developer", "generated_code_summary.md"))

except Exception as e:
    print("Error while testing backend developer agent:")
    print(str(e))