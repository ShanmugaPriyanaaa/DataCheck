import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from frontend_ux_agent import run_frontend_ux_agent
from file_utils import read_agent_file, agent_file_exists, read_agent_subfile, agent_subfile_exists

# Option 1: No real frontend repo path; code scaffolds will be generated in data/frontend_ux_agent/generated_code/
FRONTEND_CODEBASE_PATH = None

# Option 2: Point to a real frontend repo and set write_changes=True
# FRONTEND_CODEBASE_PATH = r"C:\AiHackthon\my-frontend-app"

WRITE_CHANGES = True

try:
    result = run_frontend_ux_agent(
        codebase_path=FRONTEND_CODEBASE_PATH,
        write_changes=WRITE_CHANGES
    )

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("frontend_ux_agent", "output", "md"):
        print("\n=== TOP-LEVEL SAVED OUTPUT ===")
        print(read_agent_file("frontend_ux_agent", "output", "md"))

    if agent_subfile_exists("frontend_ux_agent", "output.md"):
        print("\n=== FOLDER SAVED OUTPUT ===")
        print(read_agent_subfile("frontend_ux_agent", "output.md"))

    if agent_subfile_exists("frontend_ux_agent", "generated_code_summary.md"):
        print("\n=== GENERATED CODE SUMMARY ===")
        print(read_agent_subfile("frontend_ux_agent", "generated_code_summary.md"))

except Exception as e:
    print("Error while testing frontend ux agent:")
    print(str(e))