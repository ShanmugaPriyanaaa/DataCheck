import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from qa_agent import run_qa_agent
from file_utils import read_agent_file, agent_file_exists, read_agent_subfile, agent_subfile_exists

FRONTEND_CODEBASE_PATH = r"C:\AiHackthon\frontEndApp"
BACKEND_CODEBASE_PATH = r"C:\AiHackthon\backEndApp"

WRITE_CHANGES = True
RUN_CHECKS = False  # change to True when your environments and commands are ready

try:
    result = run_qa_agent(
        frontend_codebase_path=FRONTEND_CODEBASE_PATH,
        backend_codebase_path=BACKEND_CODEBASE_PATH,
        write_changes=WRITE_CHANGES,
        run_checks=RUN_CHECKS
    )

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("qa_agent", "output", "md"):
        print("\n=== TOP-LEVEL SAVED OUTPUT ===")
        print(read_agent_file("qa_agent", "output", "md"))

    if agent_subfile_exists("qa_agent", "output.md"):
        print("\n=== FOLDER SAVED OUTPUT ===")
        print(read_agent_subfile("qa_agent", "output.md"))

    if agent_subfile_exists("qa_agent", "generated_test_summary.md"):
        print("\n=== GENERATED TEST SUMMARY ===")
        print(read_agent_subfile("qa_agent", "generated_test_summary.md"))

    if agent_subfile_exists("qa_agent", "build_test_results.md"):
        print("\n=== BUILD / TEST RESULTS ===")
        print(read_agent_subfile("qa_agent", "build_test_results.md"))

except Exception as e:
    print("Error while testing qa agent:")
    print(str(e))