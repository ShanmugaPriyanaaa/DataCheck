import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from technical_architect import run_technical_architect
from file_utils import read_agent_file, agent_file_exists

sample_input = """
## Feature Input
Build a leave request feature where employees can apply for leave, managers can approve or reject the request, and HR can track leave balances. The system should send notifications and maintain an audit trail.

## Requirement Analysis
# Feature Name
Leave Request Management

## Summary
A leave request capability is needed to allow employees to submit leave requests, managers to review and approve or reject them, and HR to oversee balances and compliance. The feature should improve efficiency, transparency, and traceability in leave handling.

## Functional Requirements
- Employees can submit leave requests.
- Managers can approve or reject leave requests.
- HR can view and track leave balances.
- The system should send notifications for request submission and decision updates.
- The system should maintain an audit trail of leave actions.

## Non-Functional Requirements
- The feature should be secure and role-based.
- Actions should be auditable.
- The system should be reliable for routine HR operations.

## Assumptions
- Different user roles already exist in the system.
- Leave balances are already maintained or available from an existing HR source.

## Constraints
- Access must be role-based.
- Audit trail must be preserved.

## Dependencies
- Employee, manager, and HR roles
- Notification capability
- Leave balance data source

## Risks
- Incorrect balance calculation may affect trust.
- Missing notifications may cause operational confusion.

## Business Case
This feature reduces manual HR effort, improves approval efficiency, and increases transparency for employees and managers.

## Open Questions
- What leave types are supported?
- Can managers delegate approvals?
- Should HR be able to override approvals?

## Product Scope Recommendation
# Product Scope Recommendation

## Summary
A phased delivery approach is recommended for the leave request feature, starting with a focused MVP that supports request submission, approval decisions, leave balance visibility, notifications, and auditability.

## MVP Scope
- Employees can submit leave requests
- Managers can approve or reject leave requests
- HR can view leave balances
- Notifications for request submission and decision updates
- Audit trail for key leave request actions

## Future Scope
- Leave cancellation and modification workflows
- Delegated approvals
- HR override handling
- Advanced leave policy validation
- Analytics and reporting dashboards

## Priority Order
- Leave request submission and tracking first
- Manager approval/rejection next
- HR leave balance visibility next
- Notifications next
- Audit trail next

## Sprint Grouping
- Sprint 1: Core request creation
- Sprint 2: Approval flow and leave balance visibility
- Sprint 3: Notifications and auditability

## Business Value Summary
The MVP provides immediate value by replacing manual leave handling with a structured, trackable, and role-aware process.

## Release Recommendation
A phased MVP-first release is recommended.

## Assumptions
- Existing roles and leave balance data can be leveraged.

## Constraints
- Scope should remain focused on essential leave workflow capabilities for MVP.

## Dependencies
- HR policy input
- User role definitions
- Leave balance data availability
- Notification capability

## Risks
- Scope expansion may delay MVP delivery.

## Open Questions
- What is the target timeline for MVP release?
- Are delegated approvals required in MVP or later?
"""

try:
    result = run_technical_architect(sample_input)

    print("=== FULL RESULT ===")
    print(result)

    print("\n=== OUTPUT ===")
    print(result.get("output", "No output returned"))

    if agent_file_exists("technical_architect", "output", "md"):
        print("\n=== SAVED FILE CONTENT ===")
        print(read_agent_file("technical_architect", "output", "md"))

except Exception as e:
    print("Error while testing technical architect:")
    print(str(e))