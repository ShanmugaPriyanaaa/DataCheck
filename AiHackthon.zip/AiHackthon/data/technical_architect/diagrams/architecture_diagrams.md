# Architecture Diagrams

## System Context Diagram

```mermaid
flowchart LR
    Employee[Employee] --> Frontend[Frontend]
    Manager[Manager] --> Frontend
    HR[HR] --> Frontend
    Frontend --> Backend[Backend API]
    Backend --> Database[(Database)]
    Frontend --> AuthService[Authentication Service]
```

## Container Architecture Diagram

```mermaid
flowchart TB
    subgraph Frontend[Frontend]
        UI[UI Pages]
        APIClient[API Client]
        AuthClient[Authentication Client]
    end
    subgraph Backend[Backend]
        Controller[Controller Layer]
        Service[Service Layer]
        Repository[Repository Layer]
        Auth[Authentication Layer]
    end
    APIClient --> Controller
    AuthClient --> Auth
    Controller --> Service
    Service --> Repository
```

## Application Flow Diagram

```mermaid
flowchart TD
    Start([Start]) --> Login[User Login]
    Login --> Validate{Valid Credentials?}
    Validate -- Yes --> Submit[Submit Leave Request]
    Validate -- No --> Error[Show Error]
    Submit --> ValidateRequest{Valid Request?}
    ValidateRequest -- Yes --> Save[Save Data]
    ValidateRequest -- No --> ErrorRequest[Show Request Error]
```

## Sequence Diagram

```mermaid
sequenceDiagram
    actor User
    participant Frontend
    participant AuthService
    participant Backend
    participant Database
    User->>Frontend: Enter credentials
    Frontend->>AuthService: Authenticate user
    AuthService-->>Frontend: Return token
    User->>Frontend: Submit leave request
    Frontend->>Backend: API request
    Backend->>Database: Persist data
    Backend-->>Frontend: Response
```

## Data Flow Diagram

```mermaid
flowchart LR
    Input[Input Data] --> FEValidation[Frontend Validation]
    FEValidation --> Auth[Authentication Service]
    Auth --> API[Backend API]
    API --> BEValidation[Backend Validation]
    BEValidation --> DB[(Database)]
    DB --> Audit[(Audit Trail)]
```
