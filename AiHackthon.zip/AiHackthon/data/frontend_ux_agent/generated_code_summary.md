# frontend_ux_agent Generated Files Summary

- Write Changes: True
- Target Directory: C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp
- Files Written: 13

## Files

- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\package.json
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\vite.config.js
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\index.html
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\setupTests.js
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\main.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\api\leaveApi.js
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\components\LeaveRequestForm.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\components\ManagerLeaveRequests.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\components\LeaveBalanceDashboard.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\components\AuditTrailList.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\App.jsx
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\styles.css
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\frontEndApp\src\__tests__\LeaveRequestForm.test.jsx