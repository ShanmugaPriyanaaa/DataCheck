# Backend Implementation Delivery

## Summary
This implementation focuses on creating an audit trail for leave requests, approvals, and rejections in the leave management system. The backend will provide an API endpoint to retrieve audit logs, ensuring compliance and review processes are supported.

## Detected Backend Context
- **Framework**: Spring Boot
- **Folder Structure**: Standard Maven structure with `src/main/java` for source code and `src/test/java` for tests.
- **Build Tool**: Maven
- **Test Framework**: JUnit 5 + Mockito
- **Persistence Setup**: PostgreSQL for production and H2 for local/demo testing.

## Story Understanding
The goal is to maintain an audit trail of all actions related to leave requests. The backend is responsible for logging these actions and providing an API for HR to access the audit logs. Acceptance criteria include logging all actions, allowing HR access to logs, and ensuring audit entries contain relevant information.

## API / Endpoint Changes
- **HTTP Method**: GET
- **Path**: `/api/audit-trail`
- **Request Body**: None
- **Response Body**: 
  ```json
  [
    {
      "id": 1,
      "leave_request_id": 1,
      "action": "submitted",
      "performed_by": "John Doe",
      "timestamp": "2023-12-01T10:00:00Z"
    },
    ...
  ]
  ```
- **Status Codes**:
  - 200 OK: Successfully retrieved audit logs.
  - 403 Forbidden: Unauthorized access attempt.
- **Validation Behavior**: Ensure that only authorized HR personnel can access this endpoint.

## Backend Components to Create or Update
- **Controller**: `AuditTrailController` - Handles requests related to audit logs.
- **Service**: `AuditTrailService` - Contains business logic for retrieving audit logs.
- **Repository**: `AuditTrailRepository` - Data access layer for audit logs.
- **Entity**: `AuditTrail` - Represents the audit log entries.

## Backend Code Changes
### New Files to Create
1. **AuditTrail Entity**:
   ```java
   package com.example.leaveapp.model;

   import javax.persistence.*;
   import java.time.LocalDateTime;

   @Entity
   @Table(name = "audit_trail")
   public class AuditTrail {
       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
       private Long id;

       @Column(name = "leave_request_id")
       private Long leaveRequestId;

       @Column(name = "action")
       private String action;

       @Column(name = "performed_by")
       private String performedBy;

       @Column(name = "timestamp")
       private LocalDateTime timestamp;

       // Getters and setters
   }
   ```

2. **AuditTrail Repository**:
   ```java
   package com.example.leaveapp.repository;

   import com.example.leaveapp.model.AuditTrail;
   import org.springframework.data.jpa.repository.JpaRepository;
   import org.springframework.stereotype.Repository;

   @Repository
   public interface AuditTrailRepository extends JpaRepository<AuditTrail, Long> {
   }
   ```

3. **AuditTrail Service**:
   ```java
   package com.example.leaveapp.service;

   import com.example.leaveapp.model.AuditTrail;
   import com.example.leaveapp.repository.AuditTrailRepository;
   import org.springframework.beans.factory.annotation.Autowired;
   import org.springframework.stereotype.Service;

   import java.util.List;

   @Service
   public class AuditTrailService {
       @Autowired
       private AuditTrailRepository auditTrailRepository;

       public List<AuditTrail> getAllAuditLogs() {
           return auditTrailRepository.findAll();
       }
   }
   ```

4. **AuditTrail Controller**:
   ```java
   package com.example.leaveapp.controller;

   import com.example.leaveapp.model.AuditTrail;
   import com.example.leaveapp.service.AuditTrailService;
   import org.springframework.beans.factory.annotation.Autowired;
   import org.springframework.http.ResponseEntity;
   import org.springframework.security.access.prepost.PreAuthorize;
   import org.springframework.web.bind.annotation.GetMapping;
   import org.springframework.web.bind.annotation.RequestMapping;
   import org.springframework.web.bind.annotation.RestController;

   import java.util.List;

   @RestController
   @RequestMapping("/api/audit-trail")
   public class AuditTrailController {
       @Autowired
       private AuditTrailService auditTrailService;

       @GetMapping
       @PreAuthorize("hasRole('HR')")
       public ResponseEntity<List<AuditTrail>> getAuditLogs() {
           List<AuditTrail> logs = auditTrailService.getAllAuditLogs();
           return ResponseEntity.ok(logs);
       }
   }
   ```

### Existing Files to Modify
- **LeaveRequestController**: Update to log actions in the audit trail when leave requests are submitted, approved, or rejected.

### Business Logic
- Log every action (submission, approval, rejection) in the `AuditTrail` table.

### Validation Logic
- Ensure that only HR personnel can access the audit logs.

### Persistence Logic
- Use JPA to interact with the `audit_trail` table in the PostgreSQL database.

### Error Handling
- Handle unauthorized access attempts with appropriate HTTP status codes.

### Logging/Audit Behavior
- Log all relevant actions in the audit trail.

## Dependency Changes
No new backend dependencies required.

## Validation and Business Rules
- All actions on leave requests must be logged in the audit trail.
- Only HR personnel can access audit logs.

## Persistence and Data Handling
- Create the `audit_trail` table in the PostgreSQL database with the following schema:
```sql
CREATE TABLE audit_trail (
    id SERIAL PRIMARY KEY,
    leave_request_id INT REFERENCES leave_request(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL,
    performed_by VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Integration and Event Handling
No integration or event changes required.

## Error Handling
- Return 403 Forbidden for unauthorized access to the audit logs.

## Backend Unit Test Implementation
- **AuditTrailControllerTest**: Test the retrieval of audit logs and access control.
- **AuditTrailServiceTest**: Test the service logic for retrieving audit logs.

## Build and Test Readiness
Expected backend commands:
- `mvn clean install`
- `mvn test`

Success means all tests pass without errors.

## Generated / Modified Files
- CREATE: `src/main/java/com/example/leaveapp/model/AuditTrail.java` - Audit trail entity.
- CREATE: `src/main/java/com/example/leaveapp/repository/AuditTrailRepository.java` - Repository for audit logs.
- CREATE: `src/main/java/com/example/leaveapp/service/AuditTrailService.java` - Service for audit logs.
- CREATE: `src/main/java/com/example/leaveapp/controller/AuditTrailController.java` - Controller for audit logs.
- UPDATE: `src/main/java/com/example/leaveapp/controller/LeaveRequestController.java` - Log actions in the audit trail.

## Implementation Assumptions
- HR personnel have access to audit logs.
- All actions on leave requests are logged.

## Constraints
- Must comply with existing HR management system framework.
- Must adhere to data protection regulations (e.g., GDPR).

## Dependencies
- Integration with the existing HR management system for user data.
- Notification services for alerts.

## Risks
- Misunderstanding of the leave approval hierarchy may lead to unauthorized actions.
- Inadequate logging may result in compliance issues.

## Open Questions
- What specific leave types should be included in the feature?
- What detailed information is required from employees when submitting a leave request?
- What criteria will managers use to approve or reject leave requests?
- How will leave balances be calculated and updated in the system?
- What are the preferred notification methods for employees?