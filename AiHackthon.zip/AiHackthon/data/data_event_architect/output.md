# Data and Event Architecture Recommendation

## Summary
The data and event architecture for the leave request feature will support employee leave submissions, manager approvals, HR tracking of leave balances, and notifications for status changes. An audit trail will be maintained for compliance, and the architecture will ensure secure user identification in the UI.

## Confirmed Technology Stack Alignment
- **Backend technology**: Java 17 + Spring Boot
- **Database technology**: PostgreSQL
- **Local/demo database**: H2
- **API style**: REST
- **Event/messaging technology**: No event-driven implementation required for MVP
- **Testing tools relevant to data validation**: JUnit 5 + Mockito for backend testing, Vitest + React Testing Library for frontend testing, Playwright + Postman/Newman for QA automation

## Database Selection Notes
PostgreSQL is selected for its robust capabilities in handling structured data and complex queries, which are essential for managing leave requests and balances. H2 will be used for local/demo testing, ensuring compatibility with PostgreSQL syntax. The database will require migrations to establish the schema, and constraints will be implemented to maintain data integrity.

## Core Data Entities
1. **Employee**
   - **Purpose**: Represents users who can submit leave requests.
   - **Important attributes**: id, name, email, role, leave_balance
   - **Ownership/source of truth**: HR system
   - **Persisted or derived**: Persisted

2. **LeaveRequest**
   - **Purpose**: Represents a leave request submitted by an employee.
   - **Important attributes**: id, employee_id, leave_type, start_date, end_date, reason, status, created_at, updated_at
   - **Ownership/source of truth**: Leave management system
   - **Persisted or derived**: Persisted

3. **Manager**
   - **Purpose**: Represents users who can approve or reject leave requests.
   - **Important attributes**: id, name, email
   - **Ownership/source of truth**: HR system
   - **Persisted or derived**: Persisted

4. **AuditTrail**
   - **Purpose**: Logs actions taken on leave requests for compliance.
   - **Important attributes**: id, leave_request_id, action, performed_by, timestamp
   - **Ownership/source of truth**: Leave management system
   - **Persisted or derived**: Persisted

## Relationships
- **Employee to LeaveRequest**: One-to-many (one employee can have multiple leave requests)
- **Manager to LeaveRequest**: One-to-many (one manager can approve/reject multiple leave requests)
- **LeaveRequest to AuditTrail**: One-to-many (one leave request can have multiple audit entries)

## ER Diagram
```mermaid
erDiagram
    EMPLOYEE ||--o{ LEAVEREQUEST : submits
    MANAGER ||--o{ LEAVEREQUEST : approves
    LEAVEREQUEST ||--o{ AUDITTRAIL : logs
```

## Physical Database Model
```sql
CREATE TABLE employee (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(50) NOT NULL,
    leave_balance INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE leave_request (
    id SERIAL PRIMARY KEY,
    employee_id INT REFERENCES employee(id) ON DELETE CASCADE,
    leave_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE manager (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE audit_trail (
    id SERIAL PRIMARY KEY,
    leave_request_id INT REFERENCES leave_request(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL,
    performed_by VARCHAR(100) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Data Dictionary
| Table          | Column             | Type           | Required | Description                                      |
|----------------|--------------------|----------------|----------|--------------------------------------------------|
| employee       | id                 | SERIAL         | Yes      | Unique identifier for the employee               |
| employee       | name               | VARCHAR(100)   | Yes      | Employee's full name                             |
| employee       | email              | VARCHAR(100)   | Yes      | Employee's email address                         |
| employee       | role               | VARCHAR(50)    | Yes      | Role of the employee (e.g., Employee, Manager)  |
| employee       | leave_balance      | INT            | No       | Current leave balance of the employee            |
| leave_request   | id                 | SERIAL         | Yes      | Unique identifier for the leave request          |
| leave_request   | employee_id        | INT            | Yes      | Foreign key referencing employee                  |
| leave_request   | leave_type         | VARCHAR(50)    | Yes      | Type of leave requested (e.g., vacation, sick)  |
| leave_request   | start_date         | DATE           | Yes      | Start date of the leave                          |
| leave_request   | end_date           | DATE           | Yes      | End date of the leave                            |
| leave_request   | reason             | TEXT           | Yes      | Reason for the leave request                      |
| leave_request   | status             | VARCHAR(20)    | No       | Current status of the leave request               |
| audit_trail    | id                 | SERIAL         | Yes      | Unique identifier for the audit entry            |
| audit_trail    | leave_request_id   | INT            | Yes      | Foreign key referencing leave request             |
| audit_trail    | action             | VARCHAR(50)    | Yes      | Action taken (e.g., submitted, approved)        |
| audit_trail    | performed_by       | VARCHAR(100)   | Yes      | Name of the user who performed the action        |
| audit_trail    | timestamp          | TIMESTAMP      | No       | Timestamp of when the action was performed       |

## Sample Data Inserts
```sql
INSERT INTO employee (name, email, role, leave_balance) VALUES
('John Doe', 'john.doe@example.com', 'Employee', 10),
('Jane Smith', 'jane.smith@example.com', 'Manager', 15);

INSERT INTO leave_request (employee_id, leave_type, start_date, end_date, reason, status) VALUES
(1, 'Vacation', '2023-12-01', '2023-12-10', 'Family trip', 'PENDING'),
(1, 'Sick Leave', '2023-11-15', '2023-11-17', 'Flu', 'PENDING');

INSERT INTO manager (name, email) VALUES
('Jane Smith', 'jane.smith@example.com');

INSERT INTO audit_trail (leave_request_id, action, performed_by) VALUES
(1, 'submitted', 'John Doe'),
(1, 'approved', 'Jane Smith');
```

## Data Lifecycle Notes
- **Creation**: Employees submit leave requests which are stored in the database.
- **Update**: Leave requests can be updated by managers upon approval or rejection.
- **Read**: HR can query leave requests and balances.
- **Delete/Archive**: Leave requests may be archived after a certain period for compliance.
- **Retention**: Audit logs are retained indefinitely for compliance.
- **Audit**: All actions on leave requests are logged in the audit trail.
- **Cleanup**: Regular maintenance of the database will be performed to ensure data integrity.

## Event Model
No event-driven implementation required for MVP. Future options could include:
- **LeaveRequestSubmitted**: Triggered when a leave request is submitted.
- **LeaveRequestApproved**: Triggered when a leave request is approved.
- **LeaveRequestRejected**: Triggered when a leave request is rejected.

## Suggested Topics / Queues
No topics/queues required for MVP.

## Producers and Consumers
No event-driven flow is needed; the system will operate synchronously with REST API calls.

## Reliability Considerations
- **Retry**: Implement retry mechanisms for failed API calls.
- **DLQ**: Not applicable as no event-driven architecture is in place.
- **Idempotency**: Ensure that repeated submissions of the same leave request do not create duplicates.
- **Ordering**: Not applicable as events are not used.
- **Duplicate handling**: Validate leave requests to prevent duplicates.
- **Transaction consistency**: Use database transactions to ensure data integrity during updates.
- **Auditability**: Maintain an audit trail for all leave request actions.
- **Reconciliation**: Periodic audits of leave balances against requests.

## Implementation Instructions for Backend Agent
1. **Entity/model classes to create**:
   - Employee
   - LeaveRequest
   - Manager
   - AuditTrail

2. **Repository/DAO classes**:
   - EmployeeRepository
   - LeaveRequestRepository
   - ManagerRepository
   - AuditTrailRepository

3. **DTOs**:
   - LeaveRequestDTO (for submission)
   - LeaveResponseDTO (for responses)

4. **Migration file or schema file**: Use the provided SQL DDL to create the database schema.

5. **Validation constraints**: Use annotations in entity classes (e.g., @NotNull, @Size).

6. **Transaction boundaries**: Use @Transactional on service methods that modify data.

7. **Event publisher/consumer implementation if needed**: Not required for MVP.

8. **Suggested file paths**:
   - `src/main/java/com/example/leaveapp/model`
   - `src/main/java/com/example/leaveapp/repository`
   - `src/main/java/com/example/leaveapp/service`
   - `src/main/java/com/example/leaveapp/dto`

## Implementation Instructions for QA Agent
1. **Database validation tests**: Verify that the database schema matches the DDL.
2. **Repository tests**: Test CRUD operations on repositories.
3. **API data persistence tests**: Validate that leave requests are correctly saved and retrieved.
4. **Event tests if required**: Not applicable for MVP.
5. **Test data setup**: Use sample data inserts for testing.
6. **Cleanup approach**: Use transactions to rollback test data after tests.
7. **Local/demo database test approach**: Run tests against the H2 database.

## Assumptions
1. Employees have defined leave balances that can be tracked.
2. Managers have the authority to approve or reject leave requests.
3. The organization has established policies regarding leave types and durations.
4. Users will have unique credentials for accessing the system.

## Constraints
1. Development must align with the existing HR management system framework.
2. Compliance with data protection regulations (e.g., GDPR) is mandatory.
3. The feature must be delivered within the next quarter.

## Dependencies
1. Integration with the existing HR management system for user data and leave balance information.
2. Notification services (e.g., email or SMS) need to be integrated for alerts.
3. Approval from the HR department is required for leave request policies.

## Risks
1. Misunderstanding of the leave approval hierarchy may lead to unauthorized actions.
2. Potential failure of the notification system could cause confusion regarding leave statuses.
3. Inadequate logging may result in compliance issues if the audit trail is not maintained properly.
4. Security vulnerabilities in the login module could expose sensitive user information.

## Open Questions
1. What specific leave types should be included in the feature?
2. What detailed information is required from employees when submitting a leave request?
3. What criteria will managers use to approve or reject leave requests?
4. How will leave balances be calculated and updated in the system?
5. What are the preferred notification methods for employees?