# Story Instruction Manifest

Generated At UTC: 2026-07-03T03:01:18.583260

## Confirmed Technology Stack

Frontend: React + Vite
Backend: Java 17 + Spring Boot
Database: PostgreSQL
Local/Demo Database: H2
API Style: REST
Frontend Build Tool: npm
Backend Build Tool: Maven
Frontend Testing: Vitest + React Testing Library
Backend Testing: JUnit 5 + Mockito
QA Automation: Playwright + Postman/Newman

## Story Files

- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\data\jira_generator\story_001_employee_leave_request_submission_instruction.md
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\data\jira_generator\story_002_manager_approval_rejection_of_leave_requests_instruction.md
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\data\jira_generator\story_003_hr_leave_balance_tracking_instruction.md
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\data\jira_generator\story_004_notification_system_instruction.md
- C:\Users\priya\OneDrive\Desktop\agents\AiHackthon\data\jira_generator\story_005_audit_trail_maintenance_instruction.md
