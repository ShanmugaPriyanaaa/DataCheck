import requests

try:
    from config import LITELLM_API_KEY, LITELLM_BASE_URL, MODEL_NAME, VERIFY_SSL
except ImportError:
    from app.config import LITELLM_API_KEY, LITELLM_BASE_URL, MODEL_NAME, VERIFY_SSL


def ask_llm(system_prompt: str, user_input: str) -> str:
    if not LITELLM_API_KEY:
        raise ValueError(
            "LITELLM_API_KEY is missing. Please check your .env file."
        )

    base_url = LITELLM_BASE_URL.rstrip("/")
    url = f"{base_url}/chat/completions"

    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
    }

    # Personal OpenAI API
    if "api.openai.com" in base_url:
        headers["Authorization"] = f"Bearer {LITELLM_API_KEY}"

    # TCS LiteLLM / GenAI Lab
    else:
        headers["x-litellm-api-key"] = LITELLM_API_KEY

    payload = {
        "model": MODEL_NAME,
        "messages": [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_input
            }
        ],
        "temperature": 0.3
    }

    response = requests.post(
        url,
        headers=headers,
        json=payload,
        verify=VERIFY_SSL,
        timeout=120
    )

    if response.status_code != 200:
        raise Exception(
            f"LLM API failed.\n"
            f"Status Code: {response.status_code}\n"
            f"URL: {url}\n"
            f"Model: {MODEL_NAME}\n"
            f"Response: {response.text}"
        )

    data = response.json()
    return data["choices"][0]["message"]["content"]