# import os
# from dotenv import load_dotenv

# load_dotenv()

# LITELLM_API_KEY = os.getenv("LITELLM_API_KEY", "")
# LITELLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "https://genailab.tcs.in/litellm")
# MODEL_NAME = os.getenv("MODEL_NAME", "genailab-maas-gpt-4o")
# VERIFY_SSL = os.getenv("VERIFY_SSL", "true").lower() == "true"

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# PROMPTS_DIR = os.path.join(BASE_DIR, "prompts")
# OUTPUT_DIR = os.path.join(os.path.dirname(BASE_DIR), "outputs")


import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# =============================================================================
# Universal project-root safe config
# =============================================================================
# This config works from either:
#   project_root/config.py
#   project_root/app/config.py
#
# It always resolves PROJECT_ROOT as the AiHackthon project folder.
# Generated files will not go to the parent "agents" folder.
# =============================================================================

CURRENT_FILE = Path(__file__).resolve()
CURRENT_DIR = CURRENT_FILE.parent

if CURRENT_DIR.name.lower() == "app":
    APP_DIR = CURRENT_DIR
    PROJECT_ROOT = APP_DIR.parent
else:
    PROJECT_ROOT = CURRENT_DIR
    APP_DIR = PROJECT_ROOT / "app"

PROMPTS_DIR = str(APP_DIR / "prompts")

DATA_DIR = str(PROJECT_ROOT / "data")
OUTPUT_DIR = str(PROJECT_ROOT / "outputs")
MEMORY_DIR = str(PROJECT_ROOT / "memory")

FRONTEND_CODEBASE_PATH = os.getenv(
    "FRONTEND_CODEBASE_PATH",
    str(PROJECT_ROOT / "frontEndApp")
)

BACKEND_CODEBASE_PATH = os.getenv(
    "BACKEND_CODEBASE_PATH",
    str(PROJECT_ROOT / "backEndApp")
)

QA_CODEBASE_PATH = os.getenv(
    "QA_CODEBASE_PATH",
    str(PROJECT_ROOT / "qa")
)

# =============================================================================
# LLM configuration
# =============================================================================

LITELLM_API_KEY = os.getenv("LITELLM_API_KEY", "")
LITELLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "https://api.openai.com/v1")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
VERIFY_SSL = os.getenv("VERIFY_SSL", "true").lower() == "true"
MOCK_LLM = os.getenv("MOCK_LLM", "false").lower() == "true"


def ensure_project_folders():
    for folder in [
        DATA_DIR,
        OUTPUT_DIR,
        MEMORY_DIR,
        FRONTEND_CODEBASE_PATH,
        BACKEND_CODEBASE_PATH,
        QA_CODEBASE_PATH,
    ]:
        Path(folder).mkdir(parents=True, exist_ok=True)


ensure_project_folders()
