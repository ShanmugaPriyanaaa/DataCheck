import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PrimaryWorkflowForm from '../components/PrimaryWorkflowForm';

describe('PrimaryWorkflowForm', () => {
  test('renders form fields and submit button', () => {
    render(<PrimaryWorkflowForm />);
    expect(screen.getByLabelText('Field One')).toBeInTheDocument();
    expect(screen.getByLabelText('Field Two')).toBeInTheDocument();
    expect(screen.getByText('Submit')).toBeInTheDocument();
  });

  test('shows validation errors on empty submit', () => {
    render(<PrimaryWorkflowForm />);
    fireEvent.click(screen.getByText('Submit'));
    expect(screen.getByText('Field One is required')).toBeInTheDocument();
    expect(screen.getByText('Field Two is required')).toBeInTheDocument();
  });

  test('submits successfully with valid input', () => {
    render(<PrimaryWorkflowForm />);
    fireEvent.change(screen.getByLabelText('Field One'), { target: { value: 'value1' } });
    fireEvent.change(screen.getByLabelText('Field Two'), { target: { value: 'value2' } });
    fireEvent.click(screen.getByText('Submit'));
    expect(screen.getByText('Submitted successfully')).toBeInTheDocument();
  });
});
