import React, { useState } from 'react';

export default function PrimaryWorkflowForm() {
  const [formData, setFormData] = useState({
    fieldOne: '',
    fieldTwo: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const nextErrors = {};
    if (!formData.fieldOne) nextErrors.fieldOne = 'Field One is required';
    if (!formData.fieldTwo) nextErrors.fieldTwo = 'Field Two is required';
    return nextErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      setStatus('error');
      return;
    }

    setStatus('submitted');
  };

  return (
    <form onSubmit={handleSubmit} aria-label="primary-workflow-form">
      <div>
        <label htmlFor="fieldOne">Field One</label>
        <input
          id="fieldOne"
          name="fieldOne"
          value={formData.fieldOne}
          onChange={handleChange}
        />
        {errors.fieldOne && <span role="alert">{errors.fieldOne}</span>}
      </div>

      <div>
        <label htmlFor="fieldTwo">Field Two</label>
        <input
          id="fieldTwo"
          name="fieldTwo"
          value={formData.fieldTwo}
          onChange={handleChange}
        />
        {errors.fieldTwo && <span role="alert">{errors.fieldTwo}</span>}
      </div>

      <button type="submit">Submit</button>

      {status === 'submitted' && <p>Submitted successfully</p>}
    </form>
  );
}
