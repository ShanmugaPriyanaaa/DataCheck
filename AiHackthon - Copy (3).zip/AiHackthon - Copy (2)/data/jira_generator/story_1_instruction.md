# Story Instruction: Primary user can perform the core feature action

## Epic
Core User Workflow

## Story Description
As a relevant user, I want to perform the main business action so that the feature delivers its intended value.

## Acceptance Criteria
- The primary workflow is available to the authorized user.
- Required validations are applied based on business rules.
- Resulting status or outcome is visible after completion.

## Priority
High

## Story Points
TBD

## Dependencies
- Business rules clarification, role/access setup

## Story Coordination
- **Coordinator Agent:** Jira Story Generator Agent

## Primary Delivery Agents
- Frontend & UX/UI Agent
- Backend Developer Agent
- QA / Test Engineer Agent

## Supporting Review Agents
- Requirement Analyzer Agent
- Product Owner Agent
- Technical Architect Agent
- Data & Event Architecture Agent
- Security & Compliance Agent
- Documentation Agent

## Delivery Sequence
- 1. Frontend & UX/UI Agent defines UI behavior, user interaction flow, and validation expectations.
- 2. Backend Developer Agent defines business processing, persistence, and integration behavior.
- 3. QA / Test Engineer Agent derives test scenarios and validation coverage from the story and acceptance criteria.
- 4. Supporting review agents validate alignment, risks, architecture impact, data/event impact, and documentation completeness.

## Agent Instructions

### Frontend & UX/UI Agent
- Use FE Notes as the main delivery guidance: Implement input and status visibility aligned to the user workflow.
- Define screens, user interactions, validations, and usability expectations.
- Keep implementation aligned with story acceptance criteria.

### Backend Developer Agent
- Use BE Notes as the main delivery guidance: Implement core workflow processing and result persistence.
- Implement business workflow handling, validations, processing logic, persistence, and integration behavior as needed.
- Keep implementation aligned with story acceptance criteria.

### QA / Test Engineer Agent
- Use QA Notes as the main validation guidance: Validate end-to-end success path, validation rules, and outcome visibility.
- Create positive, negative, and edge-case scenarios based on acceptance criteria.
- Validate dependencies and regression risk where applicable.

### Requirement Analyzer Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Product Owner Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Technical Architect Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Data & Event Architecture Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Security & Compliance Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Documentation Agent
- Provide supporting analysis, review, or guidance relevant to this story.
