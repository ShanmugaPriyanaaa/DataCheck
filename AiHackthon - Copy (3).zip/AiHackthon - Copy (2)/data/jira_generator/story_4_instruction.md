# Story Instruction: System handles cross-cutting feature events and traceability

## Epic
Notifications, Auditability, or Cross-Cutting Functions

## Story Description
As a business or operational stakeholder, I want important events to be traceable and communicated so that the feature remains reliable and auditable.

## Acceptance Criteria
- Important lifecycle events are captured.
- Relevant communications or notifications are triggered where required.
- Audit or traceability information is retained where applicable.

## Priority
Medium

## Story Points
TBD

## Dependencies
- Notification capability, logging/audit capability

## Story Coordination
- **Coordinator Agent:** Jira Story Generator Agent

## Primary Delivery Agents
- Frontend & UX/UI Agent
- Backend Developer Agent
- QA / Test Engineer Agent

## Supporting Review Agents
- Requirement Analyzer Agent
- Product Owner Agent
- Technical Architect Agent
- Data & Event Architecture Agent
- Security & Compliance Agent
- Documentation Agent
- Monitoring & Observability Agent
- DevOps / Release Agent

## Delivery Sequence
- 1. Frontend & UX/UI Agent defines UI behavior, user interaction flow, and validation expectations.
- 2. Backend Developer Agent defines business processing, persistence, and integration behavior.
- 3. QA / Test Engineer Agent derives test scenarios and validation coverage from the story and acceptance criteria.
- 4. Supporting review agents validate alignment, risks, architecture impact, data/event impact, and documentation completeness.

## Agent Instructions

### Frontend & UX/UI Agent
- Use FE Notes as the main delivery guidance: Surface status or traceability information only if required in UI scope.
- Define screens, user interactions, validations, and usability expectations.
- Keep implementation aligned with story acceptance criteria.

### Backend Developer Agent
- Use BE Notes as the main delivery guidance: Trigger lifecycle events, notifications, and audit recording.
- Implement business workflow handling, validations, processing logic, persistence, and integration behavior as needed.
- Keep implementation aligned with story acceptance criteria.

### QA / Test Engineer Agent
- Use QA Notes as the main validation guidance: Validate event generation, notification behavior, and audit consistency.
- Create positive, negative, and edge-case scenarios based on acceptance criteria.
- Validate dependencies and regression risk where applicable.

### Requirement Analyzer Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Product Owner Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Technical Architect Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Data & Event Architecture Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Security & Compliance Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Documentation Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### Monitoring & Observability Agent
- Provide supporting analysis, review, or guidance relevant to this story.

### DevOps / Release Agent
- Provide supporting analysis, review, or guidance relevant to this story.
