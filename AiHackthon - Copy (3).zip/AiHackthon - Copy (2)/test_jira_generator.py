import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.join(BASE_DIR, "app")
AGENTS_DIR = os.path.join(APP_DIR, "agents")

sys.path.insert(0, APP_DIR)
sys.path.insert(0, AGENTS_DIR)

from jira_generator import run_jira_generator

result = run_jira_generator()
print(result["output"])