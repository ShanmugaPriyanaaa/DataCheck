import requests
from app.config import LITELLM_API_KEY, LITELLM_BASE_URL, MODEL_NAME, VERIFY_SSL

def ask_llm(system_prompt: str, user_input: str) -> str:
    if not LITELLM_API_KEY:
        return f"[MOCK RESPONSE]\n\nSystem Prompt:\n{system_prompt[:300]}\n\nUser Input:\n{user_input[:500]}"

    url = f"{LITELLM_BASE_URL}/chat/completions"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "x-litellm-api-key": LITELLM_API_KEY
    }
    payload = {
        "model": MODEL_NAME,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ],
        "temperature": 0.3
    }

    response = requests.post(
        url,
        headers=headers,
        json=payload,
        verify=VERIFY_SSL,
        timeout=120
    )
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"]