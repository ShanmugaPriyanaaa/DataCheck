class PrimaryWorkflowService:
    def validate(self, payload: dict):
        errors = {}
        if not payload.get("field_one"):
            errors["field_one"] = "field_one is required"
        if not payload.get("field_two"):
            errors["field_two"] = "field_two is required"
        return errors

    def process(self, payload: dict):
        errors = self.validate(payload)
        if errors:
            return {"status": "validation_error", "errors": errors}

        return {
            "status": "success",
            "message": "Primary workflow processed successfully",
            "data": payload
        }
