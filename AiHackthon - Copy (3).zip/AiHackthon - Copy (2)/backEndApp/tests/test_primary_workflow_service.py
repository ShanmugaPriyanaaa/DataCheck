from services.primary_workflow_service import PrimaryWorkflowService


def test_validation_fails_for_missing_fields():
    service = PrimaryWorkflowService()
    result = service.process({})
    assert result["status"] == "validation_error"
    assert "field_one" in result["errors"]
    assert "field_two" in result["errors"]


def test_success_for_valid_payload():
    service = PrimaryWorkflowService()
    result = service.process({"field_one": "value1", "field_two": "value2"})
    assert result["status"] == "success"
