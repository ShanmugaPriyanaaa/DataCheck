import os
from dotenv import load_dotenv

load_dotenv()

LITELLM_API_KEY = os.getenv("LITELLM_API_KEY", "")
LITELLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "https://genailab.tcs.in/litellm")
MODEL_NAME = os.getenv("MODEL_NAME", "genailab-maas-gpt-4o")
VERIFY_SSL = os.getenv("VERIFY_SSL", "true").lower() == "true"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROMPTS_DIR = os.path.join(BASE_DIR, "prompts")
OUTPUT_DIR = os.path.join(os.path.dirname(BASE_DIR), "outputs")