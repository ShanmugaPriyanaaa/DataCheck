import os
import subprocess
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    write_agent_subfile,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
    ensure_agent_dir,
)

AGENT_NAME = "qa_agent"
PROMPT_FILE = "qa_agent.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# QA Test Recommendation",
        "## Summary",
        "## Detected Frontend Test Context",
        "## Detected Backend Test Context",
        "## Test Scope",
        "## Functional Test Scenarios",
        "## Negative Test Scenarios",
        "## Edge Case Test Scenarios",
        "## Frontend Test Notes",
        "## Backend Test Notes",
        "## Integration and Event Test Notes",
        "## Build and Test Readiness Notes",
        "## Regression Test Notes",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    sources = [
        ("requirement_analyzer", "Requirement Analysis"),
        ("jira_generator", "Jira Delivery Breakdown"),
        ("frontend_ux_agent", "Frontend Delivery Recommendation"),
        ("backend_developer", "Backend Delivery Recommendation"),
        ("data_event_architect", "Data and Event Architecture Recommendation"),
    ]

    for agent_name, title in sources:
        if agent_file_exists(agent_name, "output", "md"):
            parts.append(f"## {title}\n{read_agent_file(agent_name, 'output', 'md')}")
        else:
            try:
                parts.append(f"## {title}\n{read_agent_subfile(agent_name, 'output.md')}")
            except Exception:
                pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected one or more outputs from requirement_analyzer, jira_generator, frontend_ux_agent, backend_developer, or data_event_architect."
        )

    return "\n\n".join(parts)


def scan_frontend_codebase(path: str):
    if not path or not os.path.exists(path):
        return {
            "exists": False,
            "framework": "Unknown",
            "files": [],
            "notes": ["No valid frontend codebase path was provided."],
            "test_command": None,
            "build_command": None,
        }

    files = []
    framework = "Unknown"
    has_package_json = False
    has_next = False
    has_react = False
    has_vue = False
    has_angular = False

    for root, dirs, filenames in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ["node_modules", ".git", "dist", "build", ".next", "coverage"]]

        for filename in filenames:
            rel = os.path.relpath(os.path.join(root, filename), path)
            files.append(rel)
            lower = rel.lower().replace("\\", "/")

            if "package.json" in lower:
                has_package_json = True
            if "next.config" in lower or "/pages/" in lower or "/app/" in lower:
                has_next = True
            if lower.endswith(".jsx") or lower.endswith(".tsx"):
                has_react = True
            if lower.endswith(".vue"):
                has_vue = True
            if "angular.json" in lower or lower.endswith(".component.ts"):
                has_angular = True

    if has_next:
        framework = "Next.js"
    elif has_angular:
        framework = "Angular"
    elif has_vue:
        framework = "Vue"
    elif has_react or has_package_json:
        framework = "React"

    test_command = "npm test" if has_package_json else None
    build_command = "npm run build" if has_package_json else None

    return {
        "exists": True,
        "framework": framework,
        "files": files[:200],
        "notes": [f"Detected frontend framework hint: {framework}"],
        "test_command": test_command,
        "build_command": build_command,
    }


def scan_backend_codebase(path: str):
    if not path or not os.path.exists(path):
        return {
            "exists": False,
            "framework": "Unknown",
            "files": [],
            "notes": ["No valid backend codebase path was provided."],
            "test_command": None,
            "build_command": None,
        }

    files = []
    framework = "Unknown"

    has_pom = False
    has_java = False
    has_package_json = False
    has_python = False
    has_fastapi = False
    has_flask = False
    has_dotnet = False

    for root, dirs, filenames in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ["node_modules", ".git", "dist", "build", "__pycache__", "target", "bin", "obj", ".venv", "venv"]]

        for filename in filenames:
            rel = os.path.relpath(os.path.join(root, filename), path)
            files.append(rel)
            lower = rel.lower().replace("\\", "/")

            if "pom.xml" in lower:
                has_pom = True
            if lower.endswith(".java"):
                has_java = True
            if "package.json" in lower:
                has_package_json = True
            if lower.endswith(".py"):
                has_python = True
            if "fastapi" in lower or lower.endswith("main.py"):
                has_fastapi = True
            if "flask" in lower:
                has_flask = True
            if lower.endswith(".csproj") or lower.endswith(".sln") or lower.endswith(".cs"):
                has_dotnet = True

    if has_pom or has_java:
        framework = "Spring Boot"
    elif has_dotnet:
        framework = ".NET"
    elif has_fastapi:
        framework = "Python/FastAPI"
    elif has_flask:
        framework = "Python/Flask"
    elif has_python:
        framework = "Python"
    elif has_package_json:
        framework = "Node.js/Express"

    if framework == "Spring Boot":
        test_command = "mvn test"
        build_command = "mvn package"
    elif framework in ["Python/FastAPI", "Python/Flask", "Python"]:
        test_command = "pytest"
        build_command = None
    elif framework == "Node.js/Express":
        test_command = "npm test"
        build_command = None
    elif framework == ".NET":
        test_command = "dotnet test"
        build_command = "dotnet build"
    else:
        test_command = None
        build_command = None

    return {
        "exists": True,
        "framework": framework,
        "files": files[:200],
        "notes": [f"Detected backend framework hint: {framework}"],
        "test_command": test_command,
        "build_command": build_command,
    }


def build_input(input_text: str, frontend_scan: dict, backend_scan: dict) -> str:
    frontend_context = "\n".join(frontend_scan["notes"])
    backend_context = "\n".join(backend_scan["notes"])

    return (
        "You are acting only as the QA / Test Engineer Agent.\n\n"
        "Generate only the required QA test recommendation output.\n\n"
        "Important:\n"
        "- Do not generate product implementation code.\n"
        "- Use the exact required output headings.\n"
        "- Keep the output focused on testing strategy, codebase-aware readiness, and test artifact guidance.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Business Context:\n{input_text}\n\n"
        f"Frontend Codebase Context:\n{frontend_context}\n\n"
        f"Backend Codebase Context:\n{backend_context}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on QA testing guidance, build readiness, and codebase-aware validation\n"
        "- Do not include product implementation code\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str, frontend_scan: dict, backend_scan: dict) -> str:
    frontend_context = (
        f"- Valid frontend codebase path provided\n"
        f"- Likely frontend framework: {frontend_scan['framework']}\n"
        f"- Suggested frontend test command: {frontend_scan['test_command'] or 'Not detected'}\n"
        f"- Suggested frontend build command: {frontend_scan['build_command'] or 'Not detected'}"
        if frontend_scan["exists"]
        else "- No valid frontend codebase path was provided"
    )

    backend_context = (
        f"- Valid backend codebase path provided\n"
        f"- Likely backend framework: {backend_scan['framework']}\n"
        f"- Suggested backend test command: {backend_scan['test_command'] or 'Not detected'}\n"
        f"- Suggested backend build command: {backend_scan['build_command'] or 'Not detected'}"
        if backend_scan["exists"]
        else "- No valid backend codebase path was provided"
    )

    return (
        "# QA Test Recommendation\n\n"
        "## Summary\n"
        "A structured QA approach is recommended to validate end-to-end workflow behavior, frontend interactions, backend processing, integration handling, regression risk, and codebase-level execution readiness. Testing should cover success flows, validation failures, role-based behavior, and operational reliability.\n\n"
        "## Detected Frontend Test Context\n"
        f"{frontend_context}\n\n"
        "## Detected Backend Test Context\n"
        f"{backend_context}\n\n"
        "## Test Scope\n"
        "- Core business workflow behavior\n"
        "- Role-based actions and visibility\n"
        "- Frontend validations and user interaction states\n"
        "- Backend validation, processing, persistence, and authorization behavior\n"
        "- Integration, notification, audit, or event-driven behavior where applicable\n"
        "- Regression-sensitive flows and shared impact areas\n"
        "- Build/test execution readiness across frontend and backend codebases\n\n"
        "## Functional Test Scenarios\n"
        "- Verify the primary workflow completes successfully with valid input\n"
        "- Verify authorized roles can perform allowed actions\n"
        "- Verify status updates are visible after successful actions\n"
        "- Verify supporting information is displayed to the correct stakeholder roles\n"
        "- Verify expected downstream effects such as notifications or audit records are triggered when applicable\n\n"
        "## Negative Test Scenarios\n"
        "- Verify required-field validation prevents invalid submission\n"
        "- Verify unauthorized users cannot access restricted actions or views\n"
        "- Verify invalid state transitions are blocked\n"
        "- Verify dependency failures produce clear and controlled error behavior\n"
        "- Verify invalid or incomplete input does not create inconsistent system state\n\n"
        "## Edge Case Test Scenarios\n"
        "- Verify repeated submissions or repeated actions are handled safely\n"
        "- Verify empty-state behavior when no records are present\n"
        "- Verify boundary or unusual input values are handled correctly\n"
        "- Verify concurrent or near-simultaneous actions do not produce inconsistent outcomes\n"
        "- Verify retry-sensitive flows behave correctly where downstream processing may be delayed or repeated\n\n"
        "## Frontend Test Notes\n"
        "- Validate screen rendering, role-aware visibility, and action availability\n"
        "- Validate form-level and field-level input behavior\n"
        "- Validate loading, empty, error, and confirmation states\n"
        "- Validate accessibility-relevant interaction behaviors where possible\n"
        "- Validate user feedback messages for failed and successful actions\n"
        "- Validate unit/component test coverage for interaction-heavy UI components\n\n"
        "## Backend Test Notes\n"
        "- Validate service-side business rules and validation handling\n"
        "- Validate state transition logic and persistence behavior\n"
        "- Validate error handling for invalid requests and dependency failures\n"
        "- Validate authorization-sensitive backend actions\n"
        "- Validate that backend processing does not create partial or inconsistent outcomes\n"
        "- Validate backend unit test coverage for service and workflow behavior\n\n"
        "## Integration and Event Test Notes\n"
        "- Validate integration triggers for downstream systems or services where applicable\n"
        "- Validate notification, audit, or event-generation behavior\n"
        "- Validate retry or fallback behavior for transient downstream failures\n"
        "- Validate event-driven or asynchronous follow-up handling where relevant\n"
        "- Validate that critical downstream failures are observable and do not silently fail\n\n"
        "## Build and Test Readiness Notes\n"
        "- Confirm frontend test and build commands are available and executable in the selected frontend project\n"
        "- Confirm backend test and build commands are available and executable in the selected backend project\n"
        "- Verify that test framework setup exists for both codebases where applicable\n"
        "- Verify that test data, environment variables, and dependencies are available for execution\n"
        "- Identify missing coverage tooling or missing automated test structure as readiness gaps\n\n"
        "## Regression Test Notes\n"
        "- Re-test the primary workflow after any change affecting shared validation or state logic\n"
        "- Re-test role-based access and visibility after UI or backend changes\n"
        "- Re-test dependent integrations, notifications, or audit behavior after backend or event changes\n"
        "- Re-test common error states and boundary conditions after feature updates\n"
        "- Re-test shared components or services that are reused across multiple stories\n\n"
        "## Assumptions\n"
        "- The feature includes role-aware workflow behavior and validation-sensitive user actions\n"
        "- Both frontend and backend components contribute to the final user-visible result\n"
        "- Some downstream integrations, notifications, or event-driven behavior may be relevant\n"
        "- Frontend and backend projects may already contain test framework setup or build scripts\n\n"
        "## Constraints\n"
        "- Test scope may depend on environment availability and integration readiness\n"
        "- Some end-to-end scenarios may require stable test data or role setup\n"
        "- Observability into downstream systems may affect validation depth for asynchronous flows\n"
        "- Build and test execution may be limited by local environment tooling availability\n\n"
        "## Dependencies\n"
        "- Requirement clarity and acceptance criteria quality\n"
        "- Jira story breakdown and test scope alignment\n"
        "- Frontend delivery recommendations\n"
        "- Backend delivery recommendations\n"
        "- Data and event architecture recommendations\n"
        "- Frontend and backend codebase availability\n"
        "- Test environment, role setup, and dependent service readiness\n\n"
        "## Risks\n"
        "- Missing acceptance detail may create incomplete test coverage\n"
        "- Ambiguous role behavior may cause gaps in access-related testing\n"
        "- Integration or event-driven failures may be difficult to validate if observability is weak\n"
        "- Regression risk increases when shared workflow or validation logic changes\n"
        "- Build or test command readiness gaps may delay test execution and release validation\n\n"
        "## Open Questions\n"
        "- Which scenarios are mandatory for MVP sign-off?\n"
        "- Which integrations or notifications must be validated end-to-end?\n"
        "- Are there required non-functional or performance-sensitive scenarios for QA scope?\n"
        "- What environments and test data are available for validation?\n"
        "- Which defects are considered release blockers versus acceptable deferred issues?\n"
    )


def run_command(command: str, cwd: str):
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=180
        )
        return {
            "command": command,
            "returncode": result.returncode,
            "stdout": result.stdout[-4000:],
            "stderr": result.stderr[-4000:],
            "success": result.returncode == 0
        }
    except Exception as e:
        return {
            "command": command,
            "returncode": -1,
            "stdout": "",
            "stderr": str(e),
            "success": False
        }


def generate_test_assets():
    test_cases_md = (
        "# QA Test Cases\n\n"
        "## Functional\n"
        "- Verify primary workflow succeeds with valid input\n"
        "- Verify authorized role can complete allowed action\n"
        "- Verify status is updated and visible after action\n\n"
        "## Negative\n"
        "- Verify missing required fields block submission\n"
        "- Verify unauthorized access is denied\n"
        "- Verify invalid state transition is rejected\n\n"
        "## Edge Cases\n"
        "- Verify repeated submission handling\n"
        "- Verify empty-state handling\n"
        "- Verify unusual or boundary input handling\n"
    )

    api_test_template = (
        "{\n"
        '  "collection": "QA API Test Template",\n'
        '  "notes": [\n'
        '    "Add endpoint-specific tests here",\n'
        '    "Cover success, validation failure, authorization failure, and dependency failure"\n'
        "  ]\n"
        "}\n"
    )

    ui_test_template = (
        "describe('Primary Workflow UI', () => {\n"
        "  it('should render the primary workflow screen', () => {\n"
        "    // Add UI test implementation\n"
        "  });\n\n"
        "  it('should show validation errors for invalid input', () => {\n"
        "    // Add UI validation test implementation\n"
        "  });\n\n"
        "  it('should complete the primary workflow successfully', () => {\n"
        "    // Add happy path UI test implementation\n"
        "  });\n"
        "});\n"
    )

    backend_test_template = (
        "def test_primary_workflow_happy_path():\n"
        "    # Add backend service/API happy path test implementation\n"
        "    assert True\n\n"
        "def test_primary_workflow_validation_failure():\n"
        "    # Add backend validation failure test implementation\n"
        "    assert True\n"
    )

    return test_cases_md, api_test_template, ui_test_template, backend_test_template


def save_generated_test_assets(write_changes: bool = False):
    agent_dir = ensure_agent_dir(AGENT_NAME)
    generated_dir = os.path.join(agent_dir, "generated_tests")
    os.makedirs(generated_dir, exist_ok=True)

    test_cases_md, api_test_template, ui_test_template, backend_test_template = generate_test_assets()

    files_written = []

    if write_changes:
        test_cases_file = os.path.join(generated_dir, "qa_test_cases.md")
        api_test_file = os.path.join(generated_dir, "api_test_template.json")
        ui_test_file = os.path.join(generated_dir, "ui_test_template.js")
        backend_test_file = os.path.join(generated_dir, "backend_test_template.py")

        with open(test_cases_file, "w", encoding="utf-8") as f:
            f.write(test_cases_md)

        with open(api_test_file, "w", encoding="utf-8") as f:
            f.write(api_test_template)

        with open(ui_test_file, "w", encoding="utf-8") as f:
            f.write(ui_test_template)

        with open(backend_test_file, "w", encoding="utf-8") as f:
            f.write(backend_test_template)

        files_written.extend([test_cases_file, api_test_file, ui_test_file, backend_test_file])

    summary_lines = [
        "# QA Test Asset Generation Summary",
        "",
        f"- Write Mode: {write_changes}",
        f"- Target Directory: {generated_dir}",
        "",
        "## Files Written",
    ]

    if files_written:
        for path in files_written:
            summary_lines.append(f"- {path}")
    else:
        summary_lines.append("- No files written. Run with write_changes=True to generate test assets.")

    write_agent_subfile(AGENT_NAME, "generated_test_summary.md", "\n".join(summary_lines))

    return files_written


def save_command_results(frontend_results, backend_results):
    lines = ["# QA Build and Test Command Results", ""]

    lines.append("## Frontend Command Results")
    if frontend_results:
        for result in frontend_results:
            lines.append(f"### {result['command']}")
            lines.append(f"- Success: {result['success']}")
            lines.append(f"- Return Code: {result['returncode']}")
            if result["stdout"]:
                lines.append("#### Stdout")
                lines.append("```")
                lines.append(result["stdout"])
                lines.append("```")
            if result["stderr"]:
                lines.append("#### Stderr")
                lines.append("```")
                lines.append(result["stderr"])
                lines.append("```")
            lines.append("")
    else:
        lines.append("- No frontend commands executed\n")

    lines.append("## Backend Command Results")
    if backend_results:
        for result in backend_results:
            lines.append(f"### {result['command']}")
            lines.append(f"- Success: {result['success']}")
            lines.append(f"- Return Code: {result['returncode']}")
            if result["stdout"]:
                lines.append("#### Stdout")
                lines.append("```")
                lines.append(result["stdout"])
                lines.append("```")
            if result["stderr"]:
                lines.append("#### Stderr")
                lines.append("```")
                lines.append(result["stderr"])
                lines.append("```")
            lines.append("")
    else:
        lines.append("- No backend commands executed\n")

    write_agent_subfile(AGENT_NAME, "build_test_results.md", "\n".join(lines))


def run_qa_agent(
    input_text: str = None,
    frontend_codebase_path: str = None,
    backend_codebase_path: str = None,
    write_changes: bool = False,
    run_checks: bool = False
):
    system_prompt = load_prompt()

    if not input_text:
        input_text = build_default_input()

    frontend_scan = scan_frontend_codebase(frontend_codebase_path)
    backend_scan = scan_backend_codebase(backend_codebase_path)

    final_input = build_input(input_text, frontend_scan, backend_scan)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input, frontend_scan, backend_scan)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input, frontend_scan, backend_scan)

    if not validate_output(output):
        output = (
            "# QA Test Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required QA format and needs manual review.\n\n"
            "## Detected Frontend Test Context\n"
            "- Manual review required\n\n"
            "## Detected Backend Test Context\n"
            "- Manual review required\n\n"
            "## Test Scope\n"
            "- Manual review required\n\n"
            "## Functional Test Scenarios\n"
            "- Manual review required\n\n"
            "## Negative Test Scenarios\n"
            "- Manual review required\n\n"
            "## Edge Case Test Scenarios\n"
            "- Manual review required\n\n"
            "## Frontend Test Notes\n"
            "- Manual review required\n\n"
            "## Backend Test Notes\n"
            "- Manual review required\n\n"
            "## Integration and Event Test Notes\n"
            "- Manual review required\n\n"
            "## Build and Test Readiness Notes\n"
            "- Manual review required\n\n"
            "## Regression Test Notes\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- Output validation failed\n\n"
            "## Constraints\n"
            "- Output validation failed\n\n"
            "## Dependencies\n"
            "- Output validation failed\n\n"
            "## Risks\n"
            "- Output validation failed\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    generated_files = save_generated_test_assets(write_changes=write_changes)

    frontend_results = []
    backend_results = []

    if run_checks:
        if frontend_scan["exists"]:
            if frontend_scan["test_command"]:
                frontend_results.append(run_command(frontend_scan["test_command"], frontend_codebase_path))
            if frontend_scan["build_command"]:
                frontend_results.append(run_command(frontend_scan["build_command"], frontend_codebase_path))

        if backend_scan["exists"]:
            if backend_scan["test_command"]:
                backend_results.append(run_command(backend_scan["test_command"], backend_codebase_path))
            if backend_scan["build_command"]:
                backend_results.append(run_command(backend_scan["build_command"], backend_codebase_path))

    save_command_results(frontend_results, backend_results)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "frontend_codebase_path": frontend_codebase_path,
        "backend_codebase_path": backend_codebase_path,
        "frontend_framework": frontend_scan["framework"],
        "backend_framework": backend_scan["framework"],
        "write_changes": write_changes,
        "run_checks": run_checks,
        "generated_files": generated_files,
        "frontend_command_results": frontend_results,
        "backend_command_results": backend_results,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }