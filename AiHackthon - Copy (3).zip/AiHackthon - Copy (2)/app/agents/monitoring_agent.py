from base_agent import run_generic_agent

def run_monitoring_agent(input_payload: str):
    return run_generic_agent("monitoring_agent", "monitoring_agent.txt", input_payload)