import os
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
)

AGENT_NAME = "data_event_architect"
PROMPT_FILE = "data_event_architect.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Data and Event Architecture Recommendation",
        "## Summary",
        "## Core Data Entities",
        "## Relationships",
        "## Suggested Logical Data Structure Notes",
        "## Data Lifecycle Notes",
        "## Event Model",
        "## Suggested Topics / Queues",
        "## Producers and Consumers",
        "## Reliability Considerations",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        req_output = read_agent_file("requirement_analyzer", "output", "md")
        parts.append(f"## Requirement Analysis\n{req_output}")
    else:
        try:
            req_output = read_agent_subfile("requirement_analyzer", "output.md")
            parts.append(f"## Requirement Analysis\n{req_output}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        arch_output = read_agent_file("technical_architect", "output", "md")
        parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
    else:
        try:
            arch_output = read_agent_subfile("technical_architect", "output.md")
            parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer or technical_architect."
        )

    return "\n\n".join(parts)


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Data & Event Architecture Agent.\n\n"
        "Generate only the required data and event architecture output.\n\n"
        "Important:\n"
        "- Do not generate physical schema, SQL, DDL, APIs, workflows, or code.\n"
        "- Use the exact required output headings.\n"
        "- Keep the output high-level and suitable for downstream agents.\n"
        "- Include logical entities, relationships, suggested topics/queues, producers/consumers, and reliability considerations.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on high-level data and event architecture\n"
        "- Include logical entities, relationships, suggested topics/queues, producers/consumers, and reliability considerations\n"
        "- Do not include physical schemas, SQL, DDL, APIs, workflows, or code\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return (
        "# Data and Event Architecture Recommendation\n\n"
        "## Summary\n"
        "A high-level data and event architecture is recommended to support the feature through clear logical business entities, state tracking, lifecycle visibility, and optional event-driven processing where updates, notifications, auditability, or downstream consumers are relevant.\n\n"
        "## Core Data Entities\n"
        "- Primary business record representing the core transaction, request, workflow item, or feature object\n"
        "- User or actor entity representing initiating, reviewing, approving, or supporting roles\n"
        "- Status or workflow state entity or tracked state attribute\n"
        "- Reference or policy entity where business rules or classifications apply\n"
        "- Audit or history entity where traceability is required\n"
        "- Notification or event log entity where communication or downstream processing needs to be tracked\n\n"
        "## Relationships\n"
        "- One primary business record may be created or updated by one or more user or actor roles\n"
        "- One primary business record may transition through multiple workflow states over time\n"
        "- One primary business record may have many history or audit records\n"
        "- One primary business record may reference one or more policy or reference data values\n"
        "- One primary business record may produce multiple event or notification records\n\n"
        "## Suggested Logical Data Structure Notes\n"
        "- A primary record is likely needed to represent the core business transaction or workflow item\n"
        "- A child history or status tracking record may be needed to capture state transitions over time\n"
        "- An audit record may be needed to retain key user actions and system-generated changes\n"
        "- Reference or lookup data may be needed for business rules, classifications, or validation inputs\n"
        "- If notifications or event publishing are important, an event tracking or delivery status record may be useful\n\n"
        "## Data Lifecycle Notes\n"
        "- Primary business data is created when the core user workflow is initiated\n"
        "- Data may be updated as the workflow progresses through role-based actions, validations, or decisions\n"
        "- Supporting stakeholders may need read access to current status, history, and associated business context\n"
        "- Historical or audit data may need to be retained for support, compliance, or reporting reasons\n"
        "- Data quality, state consistency, and controlled updates are important for downstream trust and operational stability\n\n"
        "## Event Model\n"
        "- Core business record created\n"
        "- Core business record updated\n"
        "- Workflow state changed\n"
        "- Role-based action completed\n"
        "- Notification trigger event raised\n"
        "- Audit-worthy event captured\n"
        "- Downstream integration event emitted if external processing is needed\n\n"
        "## Suggested Topics / Queues\n"
        "- feature.record.created\n"
        "- feature.record.updated\n"
        "- feature.status.changed\n"
        "- feature.action.completed\n"
        "- feature.notification.triggered\n"
        "- feature.audit.captured\n"
        "- feature.integration.outbound\n"
        "- feature.events.dlq (if dead-letter handling is required)\n\n"
        "## Producers and Consumers\n"
        "- Producers: UI-driven workflow handlers, business workflow services, backend processing components, integration orchestration components\n"
        "- Consumers: Notification services, audit/logging services, monitoring systems, downstream business systems, reporting or analytics consumers, support or compliance review processes\n\n"
        "## Reliability Considerations\n"
        "- Ensure duplicate event handling is considered where retries or repeated user actions may occur\n"
        "- Maintain consistency between business state changes and emitted events\n"
        "- Consider idempotent handling for repeated updates or retried downstream processing\n"
        "- Consider retry and dead-letter handling for failed notification or integration events\n"
        "- Consider ordering requirements where multiple state changes occur in sequence\n"
        "- Retain sufficient traceability to support troubleshooting, reconciliation, and operational review\n\n"
        "## Assumptions\n"
        "- The feature will involve at least one primary business record and one or more actor roles\n"
        "- Workflow state changes are likely important enough to track over time\n"
        "- Event-driven behavior may be useful for notifications, monitoring, auditing, or downstream integration needs\n"
        "- Reference or policy data may influence validation or decision logic\n\n"
        "## Constraints\n"
        "- Data handling may need to align with enterprise standards, access controls, and compliance rules\n"
        "- Retention and audit expectations may affect lifecycle design and history requirements\n"
        "- Integration or eventing choices may depend on available enterprise platforms and messaging capabilities\n"
        "- Some environments may require simpler synchronous flows instead of fully event-driven processing\n\n"
        "## Dependencies\n"
        "- Upstream requirement clarity\n"
        "- Technical architecture direction\n"
        "- Enterprise data or source systems if applicable\n"
        "- Notification, audit, or monitoring capabilities if event-driven behavior is needed\n"
        "- Platform support for messaging, queues, or event routing if asynchronous processing is required\n\n"
        "## Risks\n"
        "- Incomplete business rules may lead to unclear entity, state, or history design\n"
        "- Missing source-of-record clarity may create data ownership ambiguity\n"
        "- Event-driven behavior may introduce consistency, retry, or replay complexity if not handled carefully\n"
        "- Audit or retention requirements may increase data model complexity later\n"
        "- Poorly defined event boundaries may create noisy or low-value downstream processing\n\n"
        "## Open Questions\n"
        "- What is the system of record for the primary business data?\n"
        "- Which business state changes must be tracked historically?\n"
        "- Are asynchronous events mandatory or optional for the feature?\n"
        "- Which downstream systems need to consume business updates or events?\n"
        "- Are there retention, audit, replay, or compliance requirements affecting data design?\n"
    )


def run_data_event_architect(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        input_text = build_default_input()

    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        output = (
            "# Data and Event Architecture Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Data & Event Architecture format and needs manual review.\n\n"
            "## Core Data Entities\n"
            "- Manual review required\n\n"
            "## Relationships\n"
            "- Manual review required\n\n"
            "## Suggested Logical Data Structure Notes\n"
            "- Manual review required\n\n"
            "## Data Lifecycle Notes\n"
            "- Manual review required\n\n"
            "## Event Model\n"
            "- Manual review required\n\n"
            "## Suggested Topics / Queues\n"
            "- Manual review required\n\n"
            "## Producers and Consumers\n"
            "- Manual review required\n\n"
            "## Reliability Considerations\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- Output validation failed\n\n"
            "## Constraints\n"
            "- Output validation failed\n\n"
            "## Dependencies\n"
            "- Output validation failed\n\n"
            "## Risks\n"
            "- Output validation failed\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }