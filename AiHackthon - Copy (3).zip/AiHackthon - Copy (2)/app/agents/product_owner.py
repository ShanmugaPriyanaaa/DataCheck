import os
from file_utils import write_agent_file, read_agent_file, agent_file_exists, save_agent_artifacts

AGENT_NAME = "product_owner"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", "product_owner.txt")

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return """# Product Scope Recommendation

## Summary
A phased delivery approach is recommended to ensure the feature delivers early business value while allowing enhancements to be added in later iterations.

## MVP Scope
- Core user workflow capability
- Essential role-based actions
- Primary visibility and tracking needs
- Required notifications or status updates
- Minimum auditability or control features

## Future Scope
- Advanced workflow extensions
- Optional approval or delegation paths
- Reporting and analytics enhancements
- Additional policy-driven validations
- Operational optimization features

## Priority Order
- Core user workflow first
- Required role-based decisions or actions next
- Supporting visibility or tracking capabilities next
- Notifications and auditability next
- Extended features later

## Sprint Grouping
- Sprint 1: Core business workflow
- Sprint 2: Role-based actions and visibility
- Sprint 3: Notifications, controls, and hardening
- Future Sprints: Extended enhancements

## Business Value Summary
The MVP-first approach helps deliver immediate usable value, reduce manual effort, improve process consistency, and enable early stakeholder feedback before expanding scope.

## Release Recommendation
A phased MVP-first release is recommended to reduce delivery risk and validate adoption before broader rollout.

## Assumptions
- Core business workflow is the highest priority
- Relevant roles already exist or will be defined
- Stakeholders are open to phased delivery

## Constraints
- MVP should remain focused on essential scope
- Business timelines may limit advanced features in the first release
- Scope decisions must align with stakeholder priorities

## Dependencies
- Stakeholder agreement on MVP scope
- User role definitions
- Business process clarification
- Availability of required source systems or capabilities

## Risks
- Scope expansion may delay delivery
- Ambiguous business priorities may affect sequencing
- Missing dependencies may reduce MVP completeness

## Open Questions
- What specific capabilities are mandatory for the first release?
- Which items are explicitly out of MVP scope?
- Is pilot rollout preferred before full release?
- Are there timeline constraints that affect prioritization?
"""


def run_product_owner(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        if agent_file_exists("requirement_analyzer", "output", "md"):
            requirement_output = read_agent_file("requirement_analyzer", "output", "md")
            input_text = f"## Requirement Analysis\n{requirement_output}"
        else:
            raise ValueError("No input provided and requirement_analyzer_output.md not found")

    write_agent_file(AGENT_NAME, "input", input_text, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=input_text)

    output = generate_llm_output(system_prompt, input_text)

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "status": "success",
        "output": output
    }