from base_agent import run_generic_agent

def run_integration_summary_agent(input_payload: str):
    return run_generic_agent("integration_summary_agent", "integration_summary_agent.txt", input_payload)