from base_agent import run_generic_agent

def run_documentation_agent(input_payload: str):
    return run_generic_agent("documentation_agent", "documentation_agent.txt", input_payload)