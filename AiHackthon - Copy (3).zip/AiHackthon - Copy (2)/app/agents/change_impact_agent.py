from base_agent import run_generic_agent

def run_change_impact_agent(input_payload: str):
    return run_generic_agent("change_impact_agent", "change_impact_agent.txt", input_payload)