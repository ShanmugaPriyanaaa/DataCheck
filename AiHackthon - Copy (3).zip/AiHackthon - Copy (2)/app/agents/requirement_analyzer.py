import os
from file_utils import write_agent_file, save_agent_artifacts

AGENT_NAME = "requirement_analyzer"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", "requirement_analyzer.txt")

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return """# Feature Name
Leave Request Management

## Summary
This feature enables employees to submit leave requests, managers to approve or reject them, and HR to track leave balances. It improves transparency, control, and operational efficiency in leave management.

## Functional Requirements
- Employees shall be able to submit leave requests.
- Managers shall be able to approve or reject submitted leave requests.
- HR shall be able to track employee leave balances.
- The system shall send notifications for request submission and approval/rejection updates.
- The system shall maintain an audit trail of key leave request actions.

## Non-Functional Requirements
- The feature should support role-based access control.
- The system should maintain auditability of user actions.
- Notifications should be delivered reliably.
- The feature should be usable and understandable by business users.

## Assumptions
- Employee, manager, and HR roles already exist in the system.
- Leave balance information is available from an existing source or process.
- Notifications are supported by an existing messaging capability.

## Constraints
- Access must be limited based on user role.
- Audit history must be retained for review purposes.
- Leave actions must align with company leave policy.

## Dependencies
- User role management
- Notification service
- Leave balance data source
- HR policy definitions

## Risks
- Incomplete leave balance data may reduce trust in the feature.
- Notification failures may cause missed actions or confusion.
- Approval policy ambiguity may affect consistent usage.

## Business Case
This feature reduces manual effort in leave handling, improves processing speed, provides better visibility to employees and HR, and strengthens accountability through notifications and audit history.

## Open Questions
- What types of leave should be supported?
- Should managers be allowed to delegate approval?
- Can HR override or adjust decisions?
- Are there policy-based validations for leave eligibility?
"""


def run_requirement_analyzer(feature_text: str):
    system_prompt = load_prompt()

    write_agent_file(AGENT_NAME, "input", feature_text, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=feature_text)

    output = generate_llm_output(system_prompt, feature_text)

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "status": "success",
        "output": output
    }