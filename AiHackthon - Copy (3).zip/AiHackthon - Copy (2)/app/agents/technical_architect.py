import os
from datetime import datetime
from file_utils import write_agent_file, save_agent_artifacts

AGENT_NAME = "technical_architect"
PROMPT_FILE = "technical_architect.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Technical Architecture Recommendation",
        "## Summary",
        "## Architecture Style",
        "## Core Components",
        "## System Flow",
        "## Mermaid Diagram",
        "## Integration Considerations",
        "## Security and Scalability Notes",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]

    has_sections = all(section in output for section in required_sections)
    has_mermaid = "```mermaid" in output

    return has_sections and has_mermaid


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Technical Architect Agent.\n\n"
        "Generate only the required technical architecture output.\n\n"
        "Important:\n"
        "- Do not generate product planning, sprint planning, MVP planning, roadmap content, release planning, or implementation planning.\n"
        "- Use the exact required output headings.\n"
        "- The Mermaid Diagram section is mandatory.\n"
        "- The Mermaid diagram must be generated dynamically based on the provided feature context.\n"
        "- Do not use hardcoded domain examples unless they are derived from the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Include the '## Mermaid Diagram' section\n"
        "- Include valid Mermaid syntax using ```mermaid\n"
        "- Keep the output architecture-focused\n"
        "- Do not include sprint plans, MVP plans, product planning, development plans, release plans, or next steps\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return (
        "# Technical Architecture Recommendation\n\n"
        "## Summary\n"
        "A high-level modular architecture is recommended to support the requested feature with clear separation between user interaction, business logic, external integrations, and audit/monitoring concerns. The design should support maintainability, role-based access, and future extensibility.\n\n"
        "## Architecture Style\n"
        "- Modular layered architecture\n"
        "- Separation of presentation, business logic, and integration responsibilities\n"
        "- Support for event or notification-driven interactions where applicable\n"
        "- Integration-friendly enterprise application design\n\n"
        "## Core Components\n"
        "- User interaction layer for relevant user roles\n"
        "- Business workflow/service layer\n"
        "- Access control and authorization component\n"
        "- Notification/integration component\n"
        "- Audit and logging component\n"
        "- External system integration layer\n"
        "- Data management or persistence interaction layer\n\n"
        "## System Flow\n"
        "- A user or upstream system initiates an action through the application interface.\n"
        "- The system validates the request based on business rules and access permissions.\n"
        "- The relevant business service processes the request and coordinates required actions.\n"
        "- If needed, the system interacts with dependent external or internal services.\n"
        "- Notifications, status changes, and audit records are generated based on the processed action.\n"
        "- Authorized stakeholders can view resulting status, history, or related operational information.\n\n"
        "## Mermaid Diagram\n"
        "```mermaid\n"
        "flowchart TD\n"
        "    A[User or Upstream System] --> B[Application UI or Entry Layer]\n"
        "    B --> C[Access Control]\n"
        "    C --> D[Business Workflow Service]\n"
        "    D --> E[Integration or External Service Layer]\n"
        "    D --> F[Notification Component]\n"
        "    D --> G[Audit Logging Component]\n"
        "    D --> H[Data or Persistence Layer]\n"
        "    E --> I[Dependent Enterprise Systems]\n"
        "```\n\n"
        "## Integration Considerations\n"
        "- Existing enterprise identity and access management services\n"
        "- Notification or messaging services\n"
        "- External business systems or source-of-record platforms\n"
        "- Audit or logging infrastructure\n"
        "- Shared enterprise platform capabilities if applicable\n\n"
        "## Security and Scalability Notes\n"
        "- Enforce role-based access control and least-privilege principles\n"
        "- Protect sensitive business and user data appropriately\n"
        "- Ensure important user and system actions are auditable\n"
        "- Design to handle expected concurrent usage and operational load\n"
        "- Consider graceful handling of dependent service failures\n"
        "- Support maintainability and future enhancement without major redesign\n\n"
        "## Assumptions\n"
        "- The feature will be implemented within an existing enterprise application or platform landscape\n"
        "- User roles and access control capabilities already exist or can be integrated\n"
        "- Relevant dependent systems are available for integration where needed\n"
        "- Audit and notification capabilities are expected as part of enterprise standards\n\n"
        "## Constraints\n"
        "- The architecture may need to align with existing enterprise technology standards\n"
        "- Security and compliance expectations may restrict design choices\n"
        "- Integration patterns may depend on available internal platforms and services\n"
        "- Final architecture decisions may depend on organizational hosting and deployment constraints\n\n"
        "## Dependencies\n"
        "- Identity and access management capability\n"
        "- External or internal business systems relevant to the feature\n"
        "- Notification or communication service\n"
        "- Logging/audit capability\n"
        "- Downstream engineering and platform teams\n\n"
        "## Risks\n"
        "- Ambiguity in business workflow may cause architecture rework\n"
        "- Tight coupling with legacy or external systems may reduce maintainability\n"
        "- Missing integration details may delay architecture finalization\n"
        "- Non-functional requirements may evolve after architecture decisions are made\n\n"
        "## Open Questions\n"
        "- Is this feature part of an existing platform or a new module/application?\n"
        "- What systems act as system of record for the business data involved?\n"
        "- Are asynchronous events or notifications required as a core behavior?\n"
        "- Are there enterprise constraints on deployment, hosting, or integration style?\n"
        "- Are there compliance or audit retention requirements that affect architecture decisions?\n"
    )


def run_technical_architect(input_text: str):
    system_prompt = load_prompt()
    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        output = (
            "# Technical Architecture Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Technical Architect format and needs manual review.\n\n"
            "## Architecture Style\n"
            "- Manual review required\n\n"
            "## Core Components\n"
            "- Manual review required\n\n"
            "## System Flow\n"
            "- Manual review required\n\n"
            "## Mermaid Diagram\n"
            "```mermaid\n"
            "flowchart TD\n"
            "    A[Feature Input] --> B[Technical Architect Agent]\n"
            "    B --> C[Architecture Review Required]\n"
            "```\n\n"
            "## Integration Considerations\n"
            "- Manual review required\n\n"
            "## Security and Scalability Notes\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- The model response did not fully comply with the required structure.\n\n"
            "## Constraints\n"
            "- Output validation failed after retry.\n\n"
            "## Dependencies\n"
            "- Prompt adherence\n"
            "- LLM response quality\n\n"
            "## Risks\n"
            "- Downstream outputs may be impacted if this architecture output is used without correction.\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }