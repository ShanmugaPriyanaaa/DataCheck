from base_agent import run_generic_agent

def run_code_review_agent(input_payload: str):
    return run_generic_agent("code_review_agent", "code_review_agent.txt", input_payload)