import os
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    write_agent_subfile,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
    ensure_agent_dir,
)

AGENT_NAME = "frontend_ux_agent"
PROMPT_FILE = "frontend_ux_agent.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def load_story_instruction(story_instruction_path: str) -> str:
    if not story_instruction_path:
        return None

    if not os.path.exists(story_instruction_path):
        raise FileNotFoundError(f"Story instruction file not found: {story_instruction_path}")

    with open(story_instruction_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Frontend Delivery Recommendation",
        "## Summary",
        "## Detected Frontend Context",
        "## User Journey",
        "## Screen List",
        "## UI Components",
        "## Validation Rules",
        "## Accessibility Notes",
        "## Frontend State and Interaction Notes",
        "## Codebase Impact Analysis",
        "## Frontend Implementation Notes",
        "## Unit Test Notes",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        parts.append(f"## Requirement Analysis\n{read_agent_file('requirement_analyzer', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Requirement Analysis\n{read_agent_subfile('requirement_analyzer', 'output.md')}")
        except Exception:
            pass

    if agent_file_exists("jira_generator", "output", "md"):
        parts.append(f"## Jira Delivery Breakdown\n{read_agent_file('jira_generator', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Jira Delivery Breakdown\n{read_agent_subfile('jira_generator', 'output.md')}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        parts.append(f"## Technical Architecture Recommendation\n{read_agent_file('technical_architect', 'output', 'md')}")
    else:
        try:
            parts.append(f"## Technical Architecture Recommendation\n{read_agent_subfile('technical_architect', 'output.md')}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer, jira_generator, or technical_architect."
        )

    return "\n\n".join(parts)


def scan_codebase(codebase_path: str):
    if not codebase_path or not os.path.exists(codebase_path):
        return {
            "exists": False,
            "framework": "Unknown",
            "files": [],
            "notes": ["No valid codebase path was provided."]
        }

    collected_files = []
    framework_hints = {
        "React": 0,
        "Angular": 0,
        "Vue": 0,
        "Next.js": 0,
        "Unknown": 0,
    }

    for root, dirs, files in os.walk(codebase_path):
        dirs[:] = [d for d in dirs if d not in ["node_modules", ".git", "dist", "build", ".next", "coverage"]]

        for file in files:
            rel_path = os.path.relpath(os.path.join(root, file), codebase_path)
            collected_files.append(rel_path)

            lower_path = rel_path.lower().replace("\\", "/")

            if "package.json" in lower_path:
                framework_hints["React"] += 1
                framework_hints["Vue"] += 1
                framework_hints["Angular"] += 1
                framework_hints["Next.js"] += 1

            if "next.config" in lower_path or "/pages/" in lower_path or "/app/" in lower_path:
                framework_hints["Next.js"] += 2

            if lower_path.endswith(".jsx") or lower_path.endswith(".tsx"):
                framework_hints["React"] += 2

            if "angular.json" in lower_path or lower_path.endswith(".component.ts"):
                framework_hints["Angular"] += 2

            if lower_path.endswith(".vue"):
                framework_hints["Vue"] += 2

    framework = max(framework_hints, key=framework_hints.get)
    if framework_hints[framework] == 0:
        framework = "Unknown"

    return {
        "exists": True,
        "framework": framework,
        "files": collected_files[:200],
        "notes": [f"Detected framework hint: {framework}"]
    }


def build_codebase_context(codebase_scan: dict) -> str:
    if not codebase_scan["exists"]:
        return "No valid frontend codebase path was provided."

    file_preview = "\n".join([f"- {f}" for f in codebase_scan["files"][:40]])
    notes_preview = "\n".join([f"- {n}" for n in codebase_scan["notes"]])

    return (
        f"Frontend codebase path is available.\n"
        f"Detected framework hint: {codebase_scan['framework']}\n"
        f"Notes:\n{notes_preview}\n"
        f"Sample files:\n{file_preview}"
    )


def build_input(input_text: str, codebase_scan: dict) -> str:
    return (
        "You are acting only as the Frontend & UX/UI Agent.\n\n"
        "Generate only the required frontend delivery recommendation output.\n\n"
        "Important:\n"
        "- Do not generate backend logic, database schema, or infrastructure setup.\n"
        "- Use the exact required output headings.\n"
        "- Keep the output user-focused, frontend implementation-aware, and suitable for downstream agents.\n"
        "- If codebase context is available, include high-level codebase impact notes.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Business Context:\n{input_text}\n\n"
        f"Codebase Context:\n{build_codebase_context(codebase_scan)}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on frontend and UX/UI delivery guidance\n"
        "- Include codebase impact analysis and unit test notes\n"
        "- Do not include backend logic, database schema, infrastructure setup, or code by default\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str, codebase_scan: dict) -> str:
    if codebase_scan["exists"]:
        detected_context = (
            f"- Valid codebase path provided\n"
            f"- Likely frontend framework: {codebase_scan['framework']}\n"
            f"- Existing file structure was scanned at a high level\n"
            f"- Frontend implementation recommendations should align to the detected codebase layout"
        )
        codebase_impact = (
            "- Existing pages, route modules, or entry points may need updates\n"
            "- Existing reusable components, forms, tables, dialogs, or cards may need reuse or extension\n"
            "- Existing state handling, hooks, services, or frontend data-fetching layers may be impacted\n"
            "- Existing unit test files or test folders should be extended for new behavior\n"
            "- Shared layout, navigation, role-based visibility, and design-system components may need review"
        )
    else:
        detected_context = "- No valid codebase path was provided\n- Frontend recommendations are based only on upstream SDLC outputs"
        codebase_impact = "- Codebase impact analysis is limited because no frontend codebase path was provided"

    return (
        "# Frontend Delivery Recommendation\n\n"
        "## Summary\n"
        "A user-focused frontend approach is recommended with clear workflow visibility, role-aware UI behavior, structured input capture, and strong feedback states. The frontend should prioritize usability, validation clarity, accessibility, implementation fit with the existing codebase where available, and robust unit test coverage.\n\n"
        "## Detected Frontend Context\n"
        f"{detected_context}\n\n"
        "## User Journey\n"
        "- A relevant user enters the feature through an appropriate screen, route, or navigation entry point\n"
        "- The user views current status, available actions, or relevant workflow items\n"
        "- The user provides required inputs or reviews pending items depending on role\n"
        "- The frontend validates inputs and provides feedback before an action is submitted\n"
        "- The user receives confirmation, updated status, or error feedback after processing\n"
        "- Supporting users can review resulting state based on permissions and workflow stage\n\n"
        "## Screen List\n"
        "- Primary workflow entry screen or page\n"
        "- Detail or form screen for viewing or submitting the core business action\n"
        "- Review or action screen for role-based decisions where applicable\n"
        "- Status, tracking, or history view for current workflow progress\n"
        "- Supporting information or summary view for stakeholders\n"
        "- Confirmation, warning, or error dialogs where relevant\n\n"
        "## UI Components\n"
        "- Structured forms with inputs, selections, and action controls\n"
        "- Buttons for create, submit, approve, reject, update, confirm, or cancel actions where applicable\n"
        "- Status indicators, chips, badges, or step progress markers\n"
        "- Tables, cards, accordions, or list views for record visibility\n"
        "- Dialogs or modals for confirmation, comments, secondary actions, or warnings\n"
        "- Loading, empty-state, error-state, and success-state components\n"
        "- Role-aware action visibility controls and conditional rendering behavior\n\n"
        "## Validation Rules\n"
        "- Required fields should be clearly identified and validated before action completion\n"
        "- Invalid inputs should show clear inline messages near the relevant control\n"
        "- Action controls should be disabled or guarded when mandatory input is incomplete or invalid\n"
        "- Validation messaging should be understandable to business users and not overly technical\n"
        "- Frontend validation should complement backend validation and never be the sole enforcement layer\n\n"
        "## Accessibility Notes\n"
        "- Ensure keyboard accessibility for all primary interactions\n"
        "- Use clear labels, instructions, and accessible validation/error messaging\n"
        "- Maintain visible focus states for interactive controls\n"
        "- Ensure status and alerts are not communicated by color alone\n"
        "- Use sufficient contrast and semantic structure for screen readers and assistive technologies\n"
        "- Ensure dialogs and status updates are accessible and properly announced where relevant\n\n"
        "## Frontend State and Interaction Notes\n"
        "- Show loading states during data retrieval and action submission\n"
        "- Show empty states when no workflow items or records are available\n"
        "- Show clear error states when data load or action submission fails\n"
        "- Show confirmation states after successful user actions\n"
        "- Respect role-based visibility so users only see permitted information and actions\n"
        "- Preserve clarity around current workflow status and next available actions\n\n"
        "## Codebase Impact Analysis\n"
        f"{codebase_impact}\n\n"
        "## Frontend Implementation Notes\n"
        "- Reuse or extend existing screens and shared components where possible instead of creating duplicate patterns\n"
        "- Align form handling, route behavior, and conditional rendering with the current codebase conventions if available\n"
        "- Add or update workflow-specific components, form sections, and status presentation logic as needed\n"
        "- Ensure frontend state handling supports loading, success, and failure flows cleanly\n"
        "- Keep component boundaries clear between presentation, interaction handling, and data-fetching concerns\n\n"
        "## Unit Test Notes\n"
        "- Add component-level tests for rendering, conditional visibility, and role-aware interaction behavior\n"
        "- Add validation-focused tests for required fields, invalid inputs, and disabled actions\n"
        "- Add interaction tests for main user actions and expected feedback states\n"
        "- Add tests for loading, error, empty, and success states where relevant\n"
        "- Update existing test suites rather than duplicating behavior if equivalent coverage already exists\n\n"
        "## Assumptions\n"
        "- The feature will involve one or more user-facing workflows and role-aware frontend interactions\n"
        "- UI behavior must reflect current state, permissions, and action outcomes\n"
        "- Shared frontend patterns or component libraries may already exist in the codebase\n\n"
        "## Constraints\n"
        "- Frontend behavior may need to align with enterprise design standards or shared component libraries\n"
        "- Role-based access rules may constrain what is visible or editable in the UI\n"
        "- Existing codebase conventions may limit how new screens or components should be structured\n\n"
        "## Dependencies\n"
        "- Requirement clarity for user roles and actions\n"
        "- Jira story breakdown for implementation scope\n"
        "- Technical architecture context for frontend interaction boundaries\n"
        "- Backend/API readiness for dynamic data and action handling\n"
        "- Existing frontend codebase structure and shared UI components if a codebase path is provided\n\n"
        "## Risks\n"
        "- Incomplete workflow clarity may lead to inconsistent UI behavior\n"
        "- Poor validation messaging may reduce usability and trust\n"
        "- Role-based behavior may become confusing if visibility rules are unclear\n"
        "- Missing unit test coverage may allow regressions in interaction-heavy components\n"
        "- Misalignment with existing frontend structure may increase rework if codebase conventions are ignored\n\n"
        "## Open Questions\n"
        "- Which roles need distinct screens versus shared screens with conditional behavior?\n"
        "- Which actions require confirmation, comments, or additional justification?\n"
        "- What status states must be visible to end users?\n"
        "- Are there existing frontend architectural or design-system constraints that affect implementation?\n"
        "- Which unit testing framework and component test conventions should be followed in the codebase?\n"
    )


def detect_generation_targets(codebase_scan: dict, codebase_path: str = None):
    framework = codebase_scan["framework"]

    if codebase_scan["exists"] and codebase_path:
        base_target = codebase_path
    else:
        agent_dir = ensure_agent_dir(AGENT_NAME)
        base_target = os.path.join(agent_dir, "generated_code")

    os.makedirs(base_target, exist_ok=True)

    if framework in ["React", "Next.js", "Unknown"]:
        component_dir = os.path.join(base_target, "components")
        test_dir = os.path.join(base_target, "__tests__")
        os.makedirs(component_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)

        return {
            "component_file": os.path.join(component_dir, "PrimaryWorkflowForm.jsx"),
            "test_file": os.path.join(test_dir, "PrimaryWorkflowForm.test.jsx"),
            "framework": framework,
            "base_target": base_target,
        }

    if framework == "Vue":
        component_dir = os.path.join(base_target, "components")
        test_dir = os.path.join(base_target, "tests")
        os.makedirs(component_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)

        return {
            "component_file": os.path.join(component_dir, "PrimaryWorkflowForm.vue"),
            "test_file": os.path.join(test_dir, "PrimaryWorkflowForm.spec.js"),
            "framework": framework,
            "base_target": base_target,
        }

    if framework == "Angular":
        component_dir = os.path.join(base_target, "app", "primary-workflow-form")
        os.makedirs(component_dir, exist_ok=True)

        return {
            "component_file": os.path.join(component_dir, "primary-workflow-form.component.ts"),
            "test_file": os.path.join(component_dir, "primary-workflow-form.component.spec.ts"),
            "framework": framework,
            "base_target": base_target,
        }

    component_dir = os.path.join(base_target, "components")
    test_dir = os.path.join(base_target, "__tests__")
    os.makedirs(component_dir, exist_ok=True)
    os.makedirs(test_dir, exist_ok=True)

    return {
        "component_file": os.path.join(component_dir, "PrimaryWorkflowForm.jsx"),
        "test_file": os.path.join(test_dir, "PrimaryWorkflowForm.test.jsx"),
        "framework": "Unknown",
        "base_target": base_target,
    }


def generate_frontend_scaffold(framework: str):
    if framework in ["React", "Next.js", "Unknown"]:
        component_code = """import React, { useState } from 'react';

export default function PrimaryWorkflowForm() {
  const [formData, setFormData] = useState({
    fieldOne: '',
    fieldTwo: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const nextErrors = {};
    if (!formData.fieldOne) nextErrors.fieldOne = 'Field One is required';
    if (!formData.fieldTwo) nextErrors.fieldTwo = 'Field Two is required';
    return nextErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      setStatus('error');
      return;
    }

    setStatus('submitted');
  };

  return (
    <form onSubmit={handleSubmit} aria-label="primary-workflow-form">
      <div>
        <label htmlFor="fieldOne">Field One</label>
        <input
          id="fieldOne"
          name="fieldOne"
          value={formData.fieldOne}
          onChange={handleChange}
        />
        {errors.fieldOne && <span role="alert">{errors.fieldOne}</span>}
      </div>

      <div>
        <label htmlFor="fieldTwo">Field Two</label>
        <input
          id="fieldTwo"
          name="fieldTwo"
          value={formData.fieldTwo}
          onChange={handleChange}
        />
        {errors.fieldTwo && <span role="alert">{errors.fieldTwo}</span>}
      </div>

      <button type="submit">Submit</button>

      {status === 'submitted' && <p>Submitted successfully</p>}
    </form>
  );
}
"""
        test_code = """import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PrimaryWorkflowForm from '../components/PrimaryWorkflowForm';

describe('PrimaryWorkflowForm', () => {
  test('renders form fields and submit button', () => {
    render(<PrimaryWorkflowForm />);
    expect(screen.getByLabelText('Field One')).toBeInTheDocument();
    expect(screen.getByLabelText('Field Two')).toBeInTheDocument();
    expect(screen.getByText('Submit')).toBeInTheDocument();
  });

  test('shows validation errors on empty submit', () => {
    render(<PrimaryWorkflowForm />);
    fireEvent.click(screen.getByText('Submit'));
    expect(screen.getByText('Field One is required')).toBeInTheDocument();
    expect(screen.getByText('Field Two is required')).toBeInTheDocument();
  });

  test('submits successfully with valid input', () => {
    render(<PrimaryWorkflowForm />);
    fireEvent.change(screen.getByLabelText('Field One'), { target: { value: 'value1' } });
    fireEvent.change(screen.getByLabelText('Field Two'), { target: { value: 'value2' } });
    fireEvent.click(screen.getByText('Submit'));
    expect(screen.getByText('Submitted successfully')).toBeInTheDocument();
  });
});
"""
        return component_code, test_code

    if framework == "Vue":
        component_code = """<template>
  <form @submit.prevent="handleSubmit" aria-label="primary-workflow-form">
    <div>
      <label for="fieldOne">Field One</label>
      <input id="fieldOne" v-model="formData.fieldOne" />
      <span v-if="errors.fieldOne">{{ errors.fieldOne }}</span>
    </div>

    <div>
      <label for="fieldTwo">Field Two</label>
      <input id="fieldTwo" v-model="formData.fieldTwo" />
      <span v-if="errors.fieldTwo">{{ errors.fieldTwo }}</span>
    </div>

    <button type="submit">Submit</button>

    <p v-if="status === 'submitted'">Submitted successfully</p>
  </form>
</template>

<script>
export default {
  name: 'PrimaryWorkflowForm',
  data() {
    return {
      formData: {
        fieldOne: '',
        fieldTwo: '',
      },
      errors: {},
      status: 'idle',
    };
  },
  methods: {
    validate() {
      const nextErrors = {};
      if (!this.formData.fieldOne) nextErrors.fieldOne = 'Field One is required';
      if (!this.formData.fieldTwo) nextErrors.fieldTwo = 'Field Two is required';
      return nextErrors;
    },
    handleSubmit() {
      this.errors = this.validate();
      if (Object.keys(this.errors).length > 0) {
        this.status = 'error';
        return;
      }
      this.status = 'submitted';
    },
  },
};
</script>
"""
        test_code = """// Add Vue component unit tests using the project's preferred test framework.
"""
        return component_code, test_code

    if framework == "Angular":
        component_code = """import { Component } from '@angular/core';

@Component({
  selector: 'app-primary-workflow-form',
  template: `
    <form (ngSubmit)="handleSubmit()" aria-label="primary-workflow-form">
      <div>
        <label for="fieldOne">Field One</label>
        <input id="fieldOne" name="fieldOne" [(ngModel)]="fieldOne" />
      </div>

      <div>
        <label for="fieldTwo">Field Two</label>
        <input id="fieldTwo" name="fieldTwo" [(ngModel)]="fieldTwo" />
      </div>

      <button type="submit">Submit</button>
      <p *ngIf="status === 'submitted'">Submitted successfully</p>
    </form>
  `,
})
export class PrimaryWorkflowFormComponent {
  fieldOne = '';
  fieldTwo = '';
  status = 'idle';

  handleSubmit() {
    if (!this.fieldOne || !this.fieldTwo) {
      this.status = 'error';
      return;
    }
    this.status = 'submitted';
  }
}
"""
        test_code = """// Add Angular component unit tests using the project's preferred Angular test setup.
"""
        return component_code, test_code

    return "", ""


def write_generated_code(codebase_scan: dict, codebase_path: str = None, write_changes: bool = False):
    targets = detect_generation_targets(codebase_scan, codebase_path)
    component_code, test_code = generate_frontend_scaffold(targets["framework"])

    if not write_changes:
        return {
            "write_mode": False,
            "target_base": targets["base_target"],
            "component_file": targets["component_file"],
            "test_file": targets["test_file"],
            "files_written": [],
        }

    os.makedirs(os.path.dirname(targets["component_file"]), exist_ok=True)
    os.makedirs(os.path.dirname(targets["test_file"]), exist_ok=True)

    with open(targets["component_file"], "w", encoding="utf-8") as f:
        f.write(component_code)

    with open(targets["test_file"], "w", encoding="utf-8") as f:
        f.write(test_code)

    return {
        "write_mode": True,
        "target_base": targets["base_target"],
        "component_file": targets["component_file"],
        "test_file": targets["test_file"],
        "files_written": [targets["component_file"], targets["test_file"]],
    }


def save_generation_summary(generation_result: dict):
    summary_lines = [
        "# Frontend Code Generation Summary",
        "",
        f"- Write Mode: {generation_result['write_mode']}",
        f"- Target Base: {generation_result['target_base']}",
        f"- Component File: {generation_result['component_file']}",
        f"- Test File: {generation_result['test_file']}",
        "",
        "## Files Written",
    ]

    if generation_result["files_written"]:
        for path in generation_result["files_written"]:
            summary_lines.append(f"- {path}")
    else:
        summary_lines.append("- No files written. Run with write_changes=True to generate files.")

    write_agent_subfile(AGENT_NAME, "generated_code_summary.md", "\n".join(summary_lines))


def run_frontend_ux_agent(
    input_text: str = None,
    story_instruction_path: str = None,
    codebase_path: str = None,
    write_changes: bool = False
):
    system_prompt = load_prompt()

    if story_instruction_path:
        input_text = load_story_instruction(story_instruction_path)
    elif not input_text:
        input_text = build_default_input()

    codebase_scan = scan_codebase(codebase_path)
    final_input = build_input(input_text, codebase_scan)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input, codebase_scan)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input, codebase_scan)

    if not validate_output(output):
        output = (
            "# Frontend Delivery Recommendation\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Frontend Delivery format and needs manual review.\n\n"
            "## Detected Frontend Context\n"
            "- Manual review required\n\n"
            "## User Journey\n"
            "- Manual review required\n\n"
            "## Screen List\n"
            "- Manual review required\n\n"
            "## UI Components\n"
            "- Manual review required\n\n"
            "## Validation Rules\n"
            "- Manual review required\n\n"
            "## Accessibility Notes\n"
            "- Manual review required\n\n"
            "## Frontend State and Interaction Notes\n"
            "- Manual review required\n\n"
            "## Codebase Impact Analysis\n"
            "- Manual review required\n\n"
            "## Frontend Implementation Notes\n"
            "- Manual review required\n\n"
            "## Unit Test Notes\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- Output validation failed\n\n"
            "## Constraints\n"
            "- Output validation failed\n\n"
            "## Dependencies\n"
            "- Output validation failed\n\n"
            "## Risks\n"
            "- Output validation failed\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)

    generation_result = write_generated_code(
        codebase_scan=codebase_scan,
        codebase_path=codebase_path,
        write_changes=write_changes
    )
    save_generation_summary(generation_result)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "story_instruction_path": story_instruction_path,
        "codebase_path": codebase_path,
        "detected_framework": codebase_scan["framework"],
        "write_changes": write_changes,
        "generated_files": generation_result["files_written"],
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }