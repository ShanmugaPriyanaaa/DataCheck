from base_agent import run_generic_agent

def run_rca_incident_agent(input_payload: str):
    return run_generic_agent("rca_incident_agent", "rca_incident_agent.txt", input_payload)