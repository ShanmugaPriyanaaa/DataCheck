from base_agent import run_generic_agent

def run_devops_agent(input_payload: str):
    return run_generic_agent("devops_agent", "devops_agent.txt", input_payload)