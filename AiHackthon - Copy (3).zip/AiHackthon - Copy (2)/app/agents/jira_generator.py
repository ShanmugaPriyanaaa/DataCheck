import os
from datetime import datetime
from file_utils import (
    write_agent_file,
    save_agent_artifacts,
    write_agent_subfile,
    read_agent_file,
    read_agent_subfile,
    agent_file_exists,
)

AGENT_NAME = "jira_generator"
PROMPT_FILE = "jira_generator.txt"


def load_prompt():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_dir = os.path.dirname(current_dir)
    prompt_path = os.path.join(app_dir, "prompts", PROMPT_FILE)

    with open(prompt_path, "r", encoding="utf-8") as f:
        return f.read()


def validate_output(output: str) -> bool:
    required_sections = [
        "# Jira Delivery Breakdown",
        "## Summary",
        "## Epics",
        "## User Stories",
        "## Assumptions",
        "## Constraints",
        "## Dependencies",
        "## Risks",
        "## Open Questions",
    ]
    return all(section in output for section in required_sections)


def build_default_input():
    parts = []

    if agent_file_exists("requirement_analyzer", "output", "md"):
        req_output = read_agent_file("requirement_analyzer", "output", "md")
        parts.append(f"## Requirement Analysis\n{req_output}")
    else:
        try:
            req_output = read_agent_subfile("requirement_analyzer", "output.md")
            parts.append(f"## Requirement Analysis\n{req_output}")
        except Exception:
            pass

    if agent_file_exists("product_owner", "output", "md"):
        po_output = read_agent_file("product_owner", "output", "md")
        parts.append(f"## Product Scope Recommendation\n{po_output}")
    else:
        try:
            po_output = read_agent_subfile("product_owner", "output.md")
            parts.append(f"## Product Scope Recommendation\n{po_output}")
        except Exception:
            pass

    if agent_file_exists("technical_architect", "output", "md"):
        arch_output = read_agent_file("technical_architect", "output", "md")
        parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
    else:
        try:
            arch_output = read_agent_subfile("technical_architect", "output.md")
            parts.append(f"## Technical Architecture Recommendation\n{arch_output}")
        except Exception:
            pass

    if agent_file_exists("data_event_architect", "output", "md"):
        data_event_output = read_agent_file("data_event_architect", "output", "md")
        parts.append(f"## Data and Event Architecture Recommendation\n{data_event_output}")
    else:
        try:
            data_event_output = read_agent_subfile("data_event_architect", "output.md")
            parts.append(f"## Data and Event Architecture Recommendation\n{data_event_output}")
        except Exception:
            pass

    if not parts:
        raise ValueError(
            "No upstream outputs found. Expected output files from requirement_analyzer, product_owner, technical_architect, or data_event_architect."
        )

    return "\n\n".join(parts)


def build_input(input_text: str) -> str:
    return (
        "You are acting only as the Jira Story Generator Agent.\n\n"
        "Generate only the required Jira delivery breakdown output.\n\n"
        "Important:\n"
        "- Do not generate architecture design, low-level implementation, APIs, schemas, or code.\n"
        "- Use the exact required output headings.\n"
        "- Stories must be practical and suitable for Jira.\n"
        "- Include FE Notes, BE Notes, and QA Notes for each user story.\n"
        "- Do not invent unnecessary details beyond the provided context.\n\n"
        f"Context:\n{input_text}"
    )


def build_retry_input(original_input: str, previous_output: str) -> str:
    return (
        "The previous response did not follow the required format correctly.\n\n"
        "Regenerate the answer and correct all issues below:\n"
        "- Include all required sections exactly\n"
        "- Keep the output focused on Jira-ready epics and user stories\n"
        "- Include acceptance criteria, priority, story points, dependencies, FE Notes, BE Notes, and QA Notes\n"
        "- Do not include architecture design, implementation plan, APIs, schemas, or code\n\n"
        "Return only the corrected final output.\n\n"
        f"Original Context:\n{original_input}\n\n"
        f"Previous Invalid Output:\n{previous_output}"
    )


def generate_llm_output(system_prompt: str, user_input: str) -> str:
    return (
        "# Jira Delivery Breakdown\n\n"
        "## Summary\n"
        "The feature can be broken down into delivery epics and executable user stories based on the provided context. The final story details should align to the specific use case, scope, roles, and downstream implementation needs identified in the input.\n\n"
        "## Epics\n"
        "- Epic 1: Core User Workflow\n"
        "- Epic 2: Role-Based Actions and Decision Flow\n"
        "- Epic 3: Supporting Data, Visibility, or Operational Functions\n"
        "- Epic 4: Notifications, Auditability, or Cross-Cutting Functions\n"
        "- Epic 5: Small Targeted Maintenance or Documentation Tasks\n\n"
        "## User Stories\n"
        "- **Epic: Core User Workflow**\n"
        "  - **Story Title:** Primary user can perform the core feature action\n"
        "  - **Story Description:** As a relevant user, I want to perform the main business action so that the feature delivers its intended value.\n"
        "  - **Acceptance Criteria:**\n"
        "    - The primary workflow is available to the authorized user.\n"
        "    - Required validations are applied based on business rules.\n"
        "    - Resulting status or outcome is visible after completion.\n"
        "  - **Priority:** High\n"
        "  - **Story Points:** TBD\n"
        "  - **Dependencies:** Business rules clarification, role/access setup\n"
        "  - **FE Notes:** Implement input and status visibility aligned to the user workflow.\n"
        "  - **BE Notes:** Implement core workflow processing and result persistence.\n"
        "  - **QA Notes:** Validate end-to-end success path, validation rules, and outcome visibility.\n\n"
        "- **Epic: Role-Based Actions and Decision Flow**\n"
        "  - **Story Title:** Authorized role can review or act on submitted workflow items\n"
        "  - **Story Description:** As an authorized role, I want to review and act on submitted items so that the business process can proceed correctly.\n"
        "  - **Acceptance Criteria:**\n"
        "    - Authorized role can view relevant items.\n"
        "    - Authorized role can take allowed actions.\n"
        "    - System records the resulting state change.\n"
        "  - **Priority:** High\n"
        "  - **Story Points:** TBD\n"
        "  - **Dependencies:** Access model, workflow state handling\n"
        "  - **FE Notes:** Build review/action interface for authorized roles.\n"
        "  - **BE Notes:** Support retrieval, action processing, and state transitions.\n"
        "  - **QA Notes:** Validate allowed actions, unauthorized access restrictions, and state updates.\n\n"
        "- **Epic: Supporting Data, Visibility, or Operational Functions**\n"
        "  - **Story Title:** Relevant stakeholders can view supporting business information\n"
        "  - **Story Description:** As a relevant stakeholder, I want access to supporting information so that I can monitor, review, or manage the process effectively.\n"
        "  - **Acceptance Criteria:**\n"
        "    - Supporting information is accessible to authorized roles.\n"
        "    - Displayed information aligns with available business data.\n"
        "    - Access is limited appropriately.\n"
        "  - **Priority:** Medium\n"
        "  - **Story Points:** TBD\n"
        "  - **Dependencies:** Data source availability, stakeholder role definitions\n"
        "  - **FE Notes:** Build view screens for relevant business information.\n"
        "  - **BE Notes:** Retrieve and expose supporting business information.\n"
        "  - **QA Notes:** Validate data visibility, accuracy, and access restrictions.\n\n"
        "- **Epic: Notifications, Auditability, or Cross-Cutting Functions**\n"
        "  - **Story Title:** System handles cross-cutting feature events and traceability\n"
        "  - **Story Description:** As a business or operational stakeholder, I want important events to be traceable and communicated so that the feature remains reliable and auditable.\n"
        "  - **Acceptance Criteria:**\n"
        "    - Important lifecycle events are captured.\n"
        "    - Relevant communications or notifications are triggered where required.\n"
        "    - Audit or traceability information is retained where applicable.\n"
        "  - **Priority:** Medium\n"
        "  - **Story Points:** TBD\n"
        "  - **Dependencies:** Notification capability, logging/audit capability\n"
        "  - **FE Notes:** Surface status or traceability information only if required in UI scope.\n"
        "  - **BE Notes:** Trigger lifecycle events, notifications, and audit recording.\n"
        "  - **QA Notes:** Validate event generation, notification behavior, and audit consistency.\n\n"
        "- **Epic: Small Targeted Maintenance or Documentation Tasks**\n"
        "  - **Story Title:** Update feature documentation for the delivered workflow\n"
        "  - **Story Description:** As a support or delivery stakeholder, I want the feature documentation updated so that the implementation is understandable and maintainable.\n"
        "  - **Acceptance Criteria:**\n"
        "    - Relevant documentation is updated.\n"
        "    - The latest feature behavior is described clearly.\n"
        "    - Support or handover notes are added if needed.\n"
        "  - **Priority:** Low\n"
        "  - **Story Points:** TBD\n"
        "  - **Dependencies:** Finalized feature behavior\n"
        "  - **FE Notes:** No frontend changes expected.\n"
        "  - **BE Notes:** No backend changes expected.\n"
        "  - **QA Notes:** Verify documentation aligns with delivered behavior.\n\n"
        "## Assumptions\n"
        "- The final stories must be tailored to the specific use case provided at runtime.\n"
        "- Relevant user roles and business rules will be available in upstream inputs.\n"
        "- Story point estimates may need team calibration.\n\n"
        "## Constraints\n"
        "- Stories should remain within the scoped feature and not assume unrelated functionality.\n"
        "- Detailed technical implementation should not be included at this stage.\n"
        "- Output should remain suitable for Jira and downstream SDLC agents.\n\n"
        "## Dependencies\n"
        "- Requirement analysis quality\n"
        "- Product scope definition\n"
        "- Technical architecture context\n"
        "- Data and event architecture context\n"
        "- Business rule and role clarification\n\n"
        "## Risks\n"
        "- Incomplete upstream context may lead to generic or oversized stories.\n"
        "- Ambiguous scope may require story refinement later.\n"
        "- Missing acceptance criteria details may impact QA readiness.\n\n"
        "## Open Questions\n"
        "- Which roles are primary actors for the feature?\n"
        "- What actions must be in MVP versus future scope?\n"
        "- Are there mandatory notifications, approvals, or audit requirements?\n"
        "- Are there policy or validation rules that should become separate stories?\n"
    )


def infer_agent_ownership(story_text: str):
    lower_story = story_text.lower()

    if "documentation" in lower_story or "support notes" in lower_story or "handover" in lower_story:
        return {
            "primary_agents": ["Documentation Agent"],
            "supporting_agents": ["Product Owner Agent"]
        }

    if "monitoring" in lower_story or "alert" in lower_story or "observability" in lower_story:
        return {
            "primary_agents": ["Monitoring & Observability Agent"],
            "supporting_agents": ["Backend Developer Agent", "DevOps / Release Agent"]
        }

    if "security" in lower_story or "compliance" in lower_story or "authorization" in lower_story:
        return {
            "primary_agents": ["Security & Compliance Agent"],
            "supporting_agents": ["Backend Developer Agent", "QA / Test Engineer Agent"]
        }

    primary_agents = []
    supporting_agents = [
        "Requirement Analyzer Agent",
        "Product Owner Agent",
        "Technical Architect Agent",
        "Data & Event Architecture Agent",
        "Security & Compliance Agent",
        "Documentation Agent"
    ]

    if "fe notes" in lower_story and "no frontend changes expected" not in lower_story:
        primary_agents.append("Frontend & UX/UI Agent")

    if "be notes" in lower_story and "no backend changes expected" not in lower_story:
        primary_agents.append("Backend Developer Agent")

    if "qa notes" in lower_story:
        primary_agents.append("QA / Test Engineer Agent")

    if "notification" in lower_story or "audit" in lower_story or "event" in lower_story:
        supporting_agents.extend([
            "Monitoring & Observability Agent",
            "DevOps / Release Agent"
        ])

    if "data source" in lower_story or "integration" in lower_story or "persistence" in lower_story:
        supporting_agents.append("Data & Event Architecture Agent")

    if not primary_agents:
        primary_agents = ["Jira Story Generator Agent"]

    primary_agents = list(dict.fromkeys(primary_agents))
    supporting_agents = list(dict.fromkeys(supporting_agents))

    return {
        "primary_agents": primary_agents,
        "supporting_agents": supporting_agents
    }


def extract_story_field(story_text: str, field_name: str):
    lines = story_text.splitlines()
    prefix = f"  - **{field_name}:**"
    for line in lines:
        if line.startswith(prefix):
            return line.replace(prefix, "").strip()
    return "TBD"


def extract_acceptance_criteria(story_text: str):
    lines = story_text.splitlines()
    criteria = []
    capture = False

    for line in lines:
        if line.strip() == "- **Acceptance Criteria:**" or line.strip() == "  - **Acceptance Criteria:**":
            capture = True
            continue

        if capture:
            if line.startswith("  - **") or line.startswith("- **Epic:"):
                break
            if line.strip().startswith("-"):
                criteria.append(line.strip())

    return criteria


def build_delivery_sequence(primary_agents, supporting_agents):
    sequence = []
    step = 1

    if "Frontend & UX/UI Agent" in primary_agents:
        sequence.append(f"{step}. Frontend & UX/UI Agent defines UI behavior, user interaction flow, and validation expectations.")
        step += 1

    if "Backend Developer Agent" in primary_agents:
        sequence.append(f"{step}. Backend Developer Agent defines business processing, persistence, and integration behavior.")
        step += 1

    if "QA / Test Engineer Agent" in primary_agents:
        sequence.append(f"{step}. QA / Test Engineer Agent derives test scenarios and validation coverage from the story and acceptance criteria.")
        step += 1

    if "Documentation Agent" in primary_agents:
        sequence.append(f"{step}. Documentation Agent updates story-level and delivery-level documentation.")
        step += 1

    if "Monitoring & Observability Agent" in primary_agents:
        sequence.append(f"{step}. Monitoring & Observability Agent defines required logs, metrics, and alert considerations.")
        step += 1

    if "Security & Compliance Agent" in primary_agents:
        sequence.append(f"{step}. Security & Compliance Agent performs focused security and compliance review for the story.")
        step += 1

    if supporting_agents:
        sequence.append(f"{step}. Supporting review agents validate alignment, risks, architecture impact, data/event impact, and documentation completeness.")

    return sequence


def build_story_instruction(story_text: str) -> str:
    epic_line = story_text.splitlines()[0].replace("- **Epic:", "").replace("**", "").strip()
    title = extract_story_field(story_text, "Story Title")
    description = extract_story_field(story_text, "Story Description")
    priority = extract_story_field(story_text, "Priority")
    story_points = extract_story_field(story_text, "Story Points")
    dependencies = extract_story_field(story_text, "Dependencies")
    fe_notes = extract_story_field(story_text, "FE Notes")
    be_notes = extract_story_field(story_text, "BE Notes")
    qa_notes = extract_story_field(story_text, "QA Notes")
    acceptance_criteria = extract_acceptance_criteria(story_text)

    ownership = infer_agent_ownership(story_text)
    primary_agents = ownership["primary_agents"]
    supporting_agents = ownership["supporting_agents"]
    delivery_sequence = build_delivery_sequence(primary_agents, supporting_agents)

    coordinator_agent = "Jira Story Generator Agent"

    instruction = []
    instruction.append(f"# Story Instruction: {title}\n")
    instruction.append(f"## Epic\n{epic_line}\n")
    instruction.append(f"## Story Description\n{description}\n")

    instruction.append("## Acceptance Criteria")
    if acceptance_criteria:
        instruction.extend(acceptance_criteria)
    else:
        instruction.append("- TBD")
    instruction.append("")

    instruction.append(f"## Priority\n{priority}\n")
    instruction.append(f"## Story Points\n{story_points}\n")
    instruction.append(f"## Dependencies\n- {dependencies}\n")

    instruction.append("## Story Coordination")
    instruction.append(f"- **Coordinator Agent:** {coordinator_agent}")
    instruction.append("")

    instruction.append("## Primary Delivery Agents")
    for agent in primary_agents:
        instruction.append(f"- {agent}")
    instruction.append("")

    instruction.append("## Supporting Review Agents")
    for agent in supporting_agents:
        instruction.append(f"- {agent}")
    instruction.append("")

    instruction.append("## Delivery Sequence")
    for step in delivery_sequence:
        instruction.append(f"- {step}")
    instruction.append("")

    instruction.append("## Agent Instructions\n")

    for agent in primary_agents:
        instruction.append(f"### {agent}")
        if agent == "Frontend & UX/UI Agent":
            instruction.append(f"- Use FE Notes as the main delivery guidance: {fe_notes}")
            instruction.append("- Define screens, user interactions, validations, and usability expectations.")
            instruction.append("- Keep implementation aligned with story acceptance criteria.")
        elif agent == "Backend Developer Agent":
            instruction.append(f"- Use BE Notes as the main delivery guidance: {be_notes}")
            instruction.append("- Implement business workflow handling, validations, processing logic, persistence, and integration behavior as needed.")
            instruction.append("- Keep implementation aligned with story acceptance criteria.")
        elif agent == "QA / Test Engineer Agent":
            instruction.append(f"- Use QA Notes as the main validation guidance: {qa_notes}")
            instruction.append("- Create positive, negative, and edge-case scenarios based on acceptance criteria.")
            instruction.append("- Validate dependencies and regression risk where applicable.")
        elif agent == "Documentation Agent":
            instruction.append("- Update project, support, or handover documentation relevant to this story.")
            instruction.append("- Ensure documentation reflects the final delivered behavior.")
        elif agent == "Monitoring & Observability Agent":
            instruction.append("- Define required logs, metrics, traces, or alert considerations relevant to this story.")
        elif agent == "Security & Compliance Agent":
            instruction.append("- Review this story for authorization, secure handling, and compliance considerations.")
        elif agent == "Jira Story Generator Agent":
            instruction.append("- Refine this story further if more delivery detail is needed.")
            instruction.append("- Coordinate story routing, ownership clarity, and instruction completeness.")
        else:
            instruction.append("- Execute responsibilities relevant to this story based on agent specialization.")
        instruction.append("")

    for agent in supporting_agents:
        instruction.append(f"### {agent}")
        instruction.append("- Provide supporting analysis, review, or guidance relevant to this story.")
        instruction.append("")

    return "\n".join(instruction)


def save_story_files(output: str):
    story_blocks = output.split("- **Epic:")
    if len(story_blocks) <= 1:
        return

    for index, block in enumerate(story_blocks[1:], start=1):
        story_content = "- **Epic:" + block.strip()
        write_agent_subfile(AGENT_NAME, f"story_{index}.md", story_content)

        instruction_content = build_story_instruction(story_content)
        write_agent_subfile(AGENT_NAME, f"story_{index}_instruction.md", instruction_content)


def run_jira_generator(input_text: str = None):
    system_prompt = load_prompt()

    if not input_text:
        input_text = build_default_input()

    final_input = build_input(input_text)

    write_agent_file(AGENT_NAME, "input", final_input, "txt")
    save_agent_artifacts(AGENT_NAME, input_text=final_input)

    output = generate_llm_output(system_prompt, final_input)

    if not validate_output(output):
        retry_input = build_retry_input(final_input, output)
        write_agent_file(AGENT_NAME, "retry_input", retry_input, "txt")
        save_agent_artifacts(AGENT_NAME, retry_input=retry_input)
        output = generate_llm_output(system_prompt, retry_input)

    if not validate_output(output):
        output = (
            "# Jira Delivery Breakdown\n\n"
            "## Summary\n"
            "The generated output did not fully comply with the required Jira Generator format and needs manual review.\n\n"
            "## Epics\n"
            "- Manual review required\n\n"
            "## User Stories\n"
            "- Manual review required\n\n"
            "## Assumptions\n"
            "- Output validation failed\n\n"
            "## Constraints\n"
            "- Output validation failed\n\n"
            "## Dependencies\n"
            "- Output validation failed\n\n"
            "## Risks\n"
            "- Output validation failed\n\n"
            "## Open Questions\n"
            "- Should invalid outputs be blocked from downstream usage?\n"
        )

    write_agent_file(AGENT_NAME, "output", output, "md")
    save_agent_artifacts(AGENT_NAME, output_text=output)
    save_story_files(output)

    return {
        "agent": AGENT_NAME,
        "prompt_file": PROMPT_FILE,
        "input": final_input,
        "output": output,
        "generated_at": datetime.utcnow().isoformat()
    }