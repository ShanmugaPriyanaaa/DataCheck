import os
import sys
from datetime import datetime

AGENTS_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(AGENTS_DIR)
UTILS_DIR = os.path.join(APP_DIR, "utils")

if UTILS_DIR not in sys.path:
    sys.path.insert(0, UTILS_DIR)

if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from llm_client import ask_llm
from prompt_loader import load_prompt
from file_store import save_output

def run_generic_agent(agent_key: str, prompt_file: str, input_payload: str) -> dict:
    prompt = load_prompt(prompt_file)
    result = ask_llm(prompt, input_payload)

    data = {
        "agent": agent_key,
        "prompt_file": prompt_file,
        "input": input_payload,
        "output": result,
        "generated_at": datetime.utcnow().isoformat()
    }

    save_output(agent_key, data)
    return data