from base_agent import run_generic_agent

def run_security_agent(input_payload: str):
    return run_generic_agent("security_agent", "security_agent.txt", input_payload)