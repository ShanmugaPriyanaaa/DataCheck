from base_agent import run_generic_agent

def run_risk_impact_agent(input_payload: str):
    return run_generic_agent("risk_impact_agent", "risk_impact_agent.txt", input_payload)