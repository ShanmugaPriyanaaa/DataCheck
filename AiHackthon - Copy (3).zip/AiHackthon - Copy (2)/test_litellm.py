import requests
import os
from dotenv import load_dotenv

load_dotenv()

base_url = os.getenv("LITELLM_BASE_URL", "https://genailab.tcs.in/litellm")
api_key = os.getenv("LITELLM_API_KEY", "sk-wqSvHgP9DoiI0BzqUWgU3g")
model = os.getenv("MODEL_NAME", "genailab-maas-gpt-4o")
verify_ssl = os.getenv("VERIFY_SSL", "true").lower() == "true"

url = f"{base_url}/chat/completions"
headers = {
    "accept": "application/json",
    "Content-Type": "application/json",
    "x-litellm-api-key": api_key
}
payload = {
    "model": model,
    "messages": [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Reply with exactly: connection successful"}
    ],
    "temperature": 0
}

print("Testing:", url)
print("Model:", model)

response = requests.post(url, headers=headers, json=payload, verify=verify_ssl, timeout=120)
print("Status:", response.status_code)
print(response.text)